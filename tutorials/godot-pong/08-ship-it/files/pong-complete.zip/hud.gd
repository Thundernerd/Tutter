extends CanvasLayer

@onready var left_score: Label = $LeftScore
@onready var right_score: Label = $RightScore


func update_scores(left: int, right: int) -> void:
	left_score.text = str(left)
	right_score.text = str(right)
