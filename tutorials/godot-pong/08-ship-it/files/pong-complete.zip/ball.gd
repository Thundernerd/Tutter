extends CharacterBody2D

signal hit_paddle
signal hit_wall

@export var start_speed := 300.0
@export var max_speed := 900.0
## Speed multiplier applied on every paddle hit.
@export var speedup := 1.06
## Steepest angle the ball can leave a paddle at, in degrees.
@export var max_bounce_angle := 50.0

var speed := 0.0


func _physics_process(delta: float) -> void:
	var collision := move_and_collide(velocity * delta)
	if collision == null:
		return
	var collider := collision.get_collider()
	if collider.is_in_group("paddles"):
		_bounce_off_paddle(collider)
		hit_paddle.emit()
	else:
		velocity = velocity.bounce(collision.get_normal())
		hit_wall.emit()


func _bounce_off_paddle(paddle: Node2D) -> void:
	# -1 when hitting the paddle's top edge, 0 in the middle, 1 at the bottom.
	var offset := clampf((global_position.y - paddle.global_position.y) / 24.0, -1.0, 1.0)
	var angle := deg_to_rad(max_bounce_angle) * offset
	# Always travel away from the paddle that was hit.
	var direction := signf(global_position.x - paddle.global_position.x)
	speed = minf(speed * speedup, max_speed)
	velocity = Vector2(direction * cos(angle), sin(angle)) * speed
	if paddle.has_method("flash"):
		paddle.flash()


## Put the ball in the middle and launch it left (-1) or right (1).
func serve(direction: float) -> void:
	position = get_viewport_rect().size / 2
	speed = start_speed
	var angle := randf_range(-0.5, 0.5) # radians, roughly ±30°
	velocity = Vector2(direction * cos(angle), sin(angle)) * speed


func reset() -> void:
	position = get_viewport_rect().size / 2
	velocity = Vector2.ZERO
