extends CharacterBody2D

const HALF_HEIGHT := 24.0

@export var speed := 400.0
@export var up_action := &"p1_up"
@export var down_action := &"p1_down"
## When true the paddle follows the ball instead of reading input.
@export var is_cpu := false
## The CPU moves slower than a player so it can be beaten.
@export_range(0.1, 1.0) var cpu_speed_factor := 0.7

## The ball to follow when `is_cpu` is on. Set by the game scene.
var ball: CharacterBody2D


func _physics_process(_delta: float) -> void:
	var direction := _cpu_direction() if is_cpu else Input.get_axis(up_action, down_action)
	velocity = Vector2(0, direction * speed)
	move_and_slide()
	position.y = clampf(position.y, HALF_HEIGHT, get_viewport_rect().size.y - HALF_HEIGHT)


func _cpu_direction() -> float:
	if ball == null:
		return 0.0
	# Chase the ball while it comes towards us, otherwise drift back to the middle.
	var coming_at_us := signf(ball.velocity.x) == signf(global_position.x - ball.global_position.x)
	var target_y := ball.global_position.y if coming_at_us else get_viewport_rect().size.y / 2
	var distance := target_y - global_position.y
	if absf(distance) < 8.0:
		return 0.0 # Close enough: don't jitter.
	return signf(distance) * cpu_speed_factor


## Briefly brighten the paddle. Called by the ball on impact.
func flash() -> void:
	modulate = Color(2.5, 2.5, 2.5)
	create_tween().tween_property(self, "modulate", Color.WHITE, 0.15)
