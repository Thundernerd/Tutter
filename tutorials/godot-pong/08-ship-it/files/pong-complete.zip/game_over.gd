extends CanvasLayer

@onready var winner_label: Label = %WinnerLabel
@onready var rematch_button: Button = %RematchButton


func _ready() -> void:
	hide()


func show_winner(player: int, vs_cpu: bool) -> void:
	if vs_cpu:
		winner_label.text = "You win!" if player == 0 else "The CPU wins"
	else:
		winner_label.text = "Left player wins!" if player == 0 else "Right player wins!"
	show()
	rematch_button.grab_focus()


func _on_rematch_button_pressed() -> void:
	get_tree().reload_current_scene()


func _on_main_menu_button_pressed() -> void:
	get_tree().change_scene_to_file("res://main_menu.tscn")
