extends Node2D

## Index 0 is the left player, 1 is the right player.
var scores := [0, 0]
var serve_direction := 1.0

@onready var ball: CharacterBody2D = $Ball
@onready var right_paddle: CharacterBody2D = $RightPaddle
@onready var hud: CanvasLayer = $HUD
@onready var pause_menu: CanvasLayer = $PauseMenu
@onready var game_over: CanvasLayer = $GameOver
@onready var serve_timer: Timer = $ServeTimer
@onready var camera: Camera2D = $Camera2D


func _ready() -> void:
	right_paddle.is_cpu = Settings.vs_cpu
	right_paddle.ball = ball
	ball.hit_paddle.connect($Sounds/PaddleHit.play)
	ball.hit_wall.connect($Sounds/WallHit.play)
	hud.update_scores(0, 0)
	ball.reset()
	serve_direction = [-1.0, 1.0].pick_random()
	serve_timer.start()


func _on_left_goal_body_entered(body: Node2D) -> void:
	if body == ball:
		_score(1)


func _on_right_goal_body_entered(body: Node2D) -> void:
	if body == ball:
		_score(0)


func _score(player: int) -> void:
	scores[player] += 1
	hud.update_scores(scores[0], scores[1])
	$Sounds/Score.play()
	_shake()
	ball.reset.call_deferred()
	if scores[player] >= Settings.winning_score:
		pause_menu.set_process_unhandled_input(false)
		game_over.show_winner(player, Settings.vs_cpu)
		return
	# Serve towards the player who just conceded.
	serve_direction = -1.0 if player == 1 else 1.0
	serve_timer.start()


func _on_serve_timer_timeout() -> void:
	ball.serve(serve_direction)


func _shake() -> void:
	var tween := create_tween()
	for i in 6:
		var offset := Vector2(randf_range(-4, 4), randf_range(-4, 4))
		tween.tween_property(camera, "offset", offset, 0.03)
	tween.tween_property(camera, "offset", Vector2.ZERO, 0.03)
