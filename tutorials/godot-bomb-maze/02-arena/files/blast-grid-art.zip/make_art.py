"""Generate the pixel art for Blast Grid.

Run with: python3 make_art.py  (needs Pillow: pip install pillow)
Writes every image into an art/ folder next to this script.
"""
from pathlib import Path

from PIL import Image, ImageDraw

T = 24  # tile size in pixels
OUT = Path(__file__).parent / "art"
OUT.mkdir(exist_ok=True)

INK = (27, 27, 47, 255)  # dark outline colour


def tiles() -> None:
    """tiles.png: floor, wall, block, side by side."""
    img = Image.new("RGBA", (T * 3, T), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)

    # Floor: green with a slightly darker edge, so the grid is readable.
    d.rectangle([0, 0, T - 1, T - 1], fill=(58, 125, 68))
    d.line([0, T - 1, T - 1, T - 1], fill=(48, 106, 57))
    d.line([T - 1, 0, T - 1, T - 1], fill=(48, 106, 57))
    for x, y in [(5, 6), (16, 15), (9, 18)]:  # a few specks of grass
        d.point((x, y), fill=(74, 146, 84))

    # Wall: grey stone with a bevel: light top-left, dark bottom-right.
    x0 = T
    d.rectangle([x0, 0, x0 + T - 1, T - 1], fill=(132, 138, 156))
    d.rectangle([x0, 0, x0 + T - 1, 2], fill=(190, 196, 212))
    d.rectangle([x0, 0, x0 + 2, T - 1], fill=(190, 196, 212))
    d.rectangle([x0, T - 3, x0 + T - 1, T - 1], fill=(72, 76, 92))
    d.rectangle([x0 + T - 3, 0, x0 + T - 1, T - 1], fill=(72, 76, 92))
    d.rectangle([x0 + 7, 7, x0 + T - 8, T - 8], outline=(104, 110, 128))

    # Block: orange bricks that look breakable.
    x0 = T * 2
    d.rectangle([x0, 0, x0 + T - 1, T - 1], fill=(196, 112, 52))
    mortar = (120, 62, 30)
    for row in range(4):
        y = row * 6
        d.line([x0, y + 5, x0 + T - 1, y + 5], fill=mortar)
        offset = 0 if row % 2 == 0 else 6
        for bx in range(offset, T, 12):
            d.line([x0 + bx, y, x0 + bx, y + 5], fill=mortar)
        d.line([x0, y, x0 + T - 1, y], fill=(226, 150, 86))
    d.rectangle([x0, 0, x0 + T - 1, T - 1], outline=mortar)
    img.save(OUT / "tiles.png")


def _bomber(d: ImageDraw.ImageDraw, ox: int, oy: int, facing: str, step: int) -> None:
    """One 24x24 bomber frame. White parts are tinted per player in Godot."""
    white = (245, 245, 250, 255)
    shade = (196, 200, 214, 255)
    visor = (40, 46, 84, 255)
    bob = 1 if step != 0 else 0  # bob down a pixel on step frames
    # Feet
    left_foot = 1 if step == 1 else 0
    right_foot = 1 if step == 2 else 0
    d.rectangle([ox + 7, oy + 20 - left_foot, ox + 10, oy + 22 - left_foot], fill=INK)
    d.rectangle([ox + 13, oy + 20 - right_foot, ox + 16, oy + 22 - right_foot], fill=INK)
    # Body
    d.rounded_rectangle([ox + 6, oy + 13 + bob, ox + 17, oy + 20 + bob], 3, fill=white, outline=INK)
    d.line([ox + 7, oy + 17 + bob, ox + 16, oy + 17 + bob], fill=shade)
    # Hands
    d.ellipse([ox + 3, oy + 14 + bob, ox + 6, oy + 17 + bob], fill=white, outline=INK)
    d.ellipse([ox + 17, oy + 14 + bob, ox + 20, oy + 17 + bob], fill=white, outline=INK)
    # Antenna
    d.line([ox + 12, oy + 1 + bob, ox + 12, oy + 3 + bob], fill=INK)
    d.ellipse([ox + 10, oy + 0 + bob, ox + 13, oy + 2 + bob], fill=(230, 70, 80, 255))
    # Head
    d.ellipse([ox + 4, oy + 3 + bob, ox + 19, oy + 15 + bob], fill=white, outline=INK)
    if facing == "down":
        d.rounded_rectangle([ox + 7, oy + 7 + bob, ox + 16, oy + 12 + bob], 2, fill=visor)
        d.rectangle([ox + 9, oy + 8 + bob, ox + 9, oy + 10 + bob], fill=(255, 255, 255, 255))
        d.rectangle([ox + 14, oy + 8 + bob, ox + 14, oy + 10 + bob], fill=(255, 255, 255, 255))
    elif facing == "side":  # drawn facing right; flipped in code for left
        d.rounded_rectangle([ox + 11, oy + 7 + bob, ox + 18, oy + 12 + bob], 2, fill=visor)
        d.rectangle([ox + 15, oy + 8 + bob, ox + 15, oy + 10 + bob], fill=(255, 255, 255, 255))
    else:  # up: the back of the helmet
        d.arc([ox + 7, oy + 6 + bob, ox + 16, oy + 13 + bob], 200, 340, fill=shade)


def bomber() -> None:
    """bomber.png: 3 columns (stand, step, other step) x 3 rows (down, up, side)."""
    img = Image.new("RGBA", (T * 3, T * 3), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    for row, facing in enumerate(["down", "up", "side"]):
        for col in range(3):
            _bomber(d, col * T, row * T, facing, col)
    img.save(OUT / "bomber.png")


def bomb() -> None:
    img = Image.new("RGBA", (T, T), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    d.ellipse([3, 5, 20, 22], fill=(30, 30, 40), outline=(10, 10, 16))
    d.ellipse([7, 9, 11, 13], fill=(110, 110, 130))  # highlight
    d.rectangle([10, 3, 13, 6], fill=(70, 70, 86))  # cap
    d.line([12, 3, 15, 0], fill=(150, 110, 60))  # fuse
    d.point((16, 0), fill=(255, 220, 90))
    d.point((15, 1), fill=(255, 140, 40))
    img.save(OUT / "bomb.png")


def flame() -> None:
    """flame.png: centre, middle (horizontal) and end (pointing right)."""
    img = Image.new("RGBA", (T * 3, T), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    layers = [(10, (232, 72, 36)), (7, (255, 170, 40)), (3, (255, 245, 190))]
    c = T // 2
    for half, colour in layers:
        # Centre: a plus shape.
        d.rectangle([0, c - half, T - 1, c + half - 1], fill=colour)
        d.rectangle([c - half, 0, c + half - 1, T - 1], fill=colour)
        # Middle: straight band.
        d.rectangle([T, c - half, 2 * T - 1, c + half - 1], fill=colour)
        # End: band with a rounded tip on the right.
        d.rectangle([2 * T, c - half, 2 * T + T - half - 3, c + half - 1], fill=colour)
        d.ellipse([3 * T - 2 * half - 2, c - half, 3 * T - 3, c + half - 1], fill=colour)
    img.save(OUT / "flame.png")


def power_ups() -> None:
    """power_ups.png: extra bomb, bigger fire, speed."""
    img = Image.new("RGBA", (T * 3, T), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    backs = [(64, 96, 200), (200, 64, 64), (60, 170, 110)]
    for i, back in enumerate(backs):
        ox = i * T
        d.rounded_rectangle([ox + 1, 1, ox + T - 2, T - 2], 4, fill=back, outline=(250, 250, 255))
    # Bomb
    d.ellipse([5, 7, 17, 19], fill=(30, 30, 40))
    d.line([13, 7, 16, 4], fill=(255, 220, 90))
    d.point((8, 10), fill=(140, 140, 160))
    # Fire
    ox = T
    d.polygon([(ox + 12, 3), (ox + 18, 13), (ox + 16, 20), (ox + 8, 20), (ox + 6, 13)], fill=(255, 170, 40))
    d.polygon([(ox + 12, 9), (ox + 15, 15), (ox + 13, 19), (ox + 10, 19), (ox + 9, 15)], fill=(255, 245, 190))
    # Speed: a winged boot
    ox = T * 2
    boot = [(ox + 9, 4), (ox + 14, 4), (ox + 14, 13), (ox + 19, 15), (ox + 19, 19), (ox + 9, 19)]
    d.polygon(boot, fill=(250, 250, 255))
    d.line([ox + 9, 17, ox + 19, 17], fill=(150, 150, 170))
    d.polygon([(ox + 8, 6), (ox + 3, 5), (ox + 8, 10)], fill=(255, 220, 90))
    d.polygon([(ox + 8, 11), (ox + 3, 11), (ox + 8, 14)], fill=(255, 220, 90))
    img.save(OUT / "power_ups.png")


def monster() -> None:
    """monster.png: two bobbing frames of a grumpy balloon."""
    img = Image.new("RGBA", (T * 2, T), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    body = (170, 110, 230)
    for f in range(2):
        ox = f * T
        y = 1 - f  # frame 1 floats a pixel higher
        d.line([ox + 12, 18 + y, ox + 12 + (1 if f else -1), 23], fill=INK)  # string
        d.polygon([(ox + 10, 19 + y), (ox + 14, 19 + y), (ox + 12, 16 + y)], fill=body, outline=INK)  # knot
        d.ellipse([ox + 3, 1 + y, ox + 20, 18 + y], fill=body, outline=INK)
        d.ellipse([ox + 6, 4 + y, ox + 9, 7 + y], fill=(214, 180, 250))  # shine
        d.rectangle([ox + 7, 9 + y, ox + 10, 12 + y], fill=(255, 255, 255))
        d.rectangle([ox + 13, 9 + y, ox + 16, 12 + y], fill=(255, 255, 255))
        d.rectangle([ox + 9, 10 + y, ox + 10, 12 + y], fill=INK)
        d.rectangle([ox + 13, 10 + y, ox + 14, 12 + y], fill=INK)
        d.line([ox + 6, 7 + y, ox + 10, 9 + y], fill=INK)  # angry brows
        d.line([ox + 17, 7 + y, ox + 13, 9 + y], fill=INK)
        d.line([ox + 10, 15 + y, ox + 13, 15 + y], fill=INK)  # mouth
    img.save(OUT / "monster.png")


def icon() -> None:
    img = Image.new("RGBA", (128, 128), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    d.rounded_rectangle([0, 0, 127, 127], 24, fill=(58, 125, 68))
    d.ellipse([22, 34, 102, 114], fill=(30, 30, 40), outline=(10, 10, 16), width=3)
    d.ellipse([40, 52, 56, 68], fill=(110, 110, 130))
    d.rectangle([54, 24, 70, 38], fill=(70, 70, 86))
    d.line([62, 24, 78, 8], fill=(150, 110, 60), width=4)
    d.ellipse([74, 2, 90, 18], fill=(255, 170, 40))
    d.ellipse([78, 6, 86, 14], fill=(255, 245, 190))
    img.save(OUT.parent / "icon.png")


if __name__ == "__main__":
    tiles()
    bomber()
    bomb()
    flame()
    power_ups()
    monster()
    icon()
    print("Art written to", OUT)
