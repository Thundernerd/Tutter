"""Generate the sound effects for Blast Grid with only the standard library.

Run with: python3 make_sounds.py   (writes .wav files into sounds/)
"""
import math
import random
import struct
import wave
from pathlib import Path

RATE = 22050
OUT = Path(__file__).parent / "sounds"
OUT.mkdir(exist_ok=True)
random.seed(7)


def save(name, samples):
    with wave.open(str(OUT / name), "wb") as f:
        f.setnchannels(1)
        f.setsampwidth(2)
        f.setframerate(RATE)
        f.writeframes(b"".join(struct.pack("<h", int(max(-1, min(1, s)) * 32000)) for s in samples))


def square(freq, t):
    return 1.0 if math.sin(2 * math.pi * freq * t) >= 0 else -1.0


def tone(freqs, length, volume=0.35, wave_fn=square):
    """Play `freqs` one after another, each `length` seconds, with a short fade out."""
    out = []
    for freq in freqs:
        n = int(RATE * length)
        for i in range(n):
            fade = 1 - i / n
            out.append(wave_fn(freq, i / RATE) * volume * fade ** 0.5)
    return out


def place():
    return tone([220, 330], 0.04, 0.3)


def explosion():
    n = int(RATE * 0.6)
    out, low = [], 0.0
    for i in range(n):
        t = i / n
        low += (random.uniform(-1, 1) - low) * (0.25 - 0.2 * t)  # darker as it fades
        out.append(low * 2.2 * (1 - t) ** 2)
    return out


def power_up():
    return tone([523, 659, 784, 1047], 0.06, 0.25)


def death():
    n = int(RATE * 0.7)
    out = []
    for i in range(n):
        t = i / RATE
        freq = 600 * (1 - i / n) + 80
        out.append(square(freq, t) * 0.3 * (1 - i / n))
    return out


def thud():
    n = int(RATE * 0.15)
    return [math.sin(2 * math.pi * (90 - 40 * i / n) * i / RATE) * 0.7 * (1 - i / n) ** 2 for i in range(n)]


def round_end():
    return tone([392, 523, 659, 784, 659, 784], 0.1, 0.25)


if __name__ == "__main__":
    for fn in [place, explosion, power_up, death, thud, round_end]:
        save(fn.__name__ + ".wav", fn())
    print("Sounds written to", OUT)
