extends Node2D
## One round of Blast Grid. The scene reloads for every round; Match keeps score.

const MONSTER_COUNT := 3

@export var bomber_scene: PackedScene
@export var monster_scene: PackedScene
@export var debris_scene: PackedScene

var bombers: Array[Bomber] = []
var round_over := false
## Cells still to be walled up during sudden death, outermost first.
var _closing_cells: Array[Vector2i] = []
var _shake_tween: Tween

@onready var arena: Arena = $Arena
@onready var camera: Camera2D = $Camera2D
@onready var hud: CanvasLayer = $HUD
@onready var pause_menu: CanvasLayer = $PauseMenu
@onready var results: CanvasLayer = $Results
@onready var round_timer: Timer = $RoundTimer
@onready var settle_timer: Timer = $SettleTimer
@onready var sudden_death_timer: Timer = $SuddenDeathTimer


func _ready() -> void:
	arena.generate()
	_spawn_bombers()
	if Settings.monsters:
		_spawn_monsters()
	hud.setup(Match.bombers, Match.wins)
	arena.exploded.connect(_on_arena_exploded)
	arena.block_destroyed.connect(_on_block_destroyed)
	arena.wall_dropped.connect(_on_wall_dropped)
	round_timer.start()


func _process(_delta: float) -> void:
	if not round_timer.is_stopped():
		hud.show_time(round_timer.time_left)


func _spawn_bombers() -> void:
	var spawns := arena.spawn_cells()
	for i in Match.bombers.size():
		var info: Dictionary = Match.bombers[i]
		var bomber: Bomber = bomber_scene.instantiate()
		bomber.arena = arena
		bomber.index = i
		bomber.color = info.color
		bomber.position = arena.cell_center(spawns[i])
		if info.controls == "":
			bomber.is_cpu = true
			var brain := CpuBrain.new()
			bomber.add_child(brain)
			brain.set_level(Settings.cpu_difficulty)
		else:
			bomber.controls = info.controls
		bomber.died.connect(_on_bomber_died)
		bomber.bomb_placed.connect($Sounds/Place.play)
		bomber.powered_up.connect(_on_bomber_powered_up)
		arena.actors.add_child(bomber)
		bombers.append(bomber)


func _spawn_monsters() -> void:
	var cells := arena.free_cells_away_from_spawns(5)
	cells.shuffle()
	for i in mini(MONSTER_COUNT, cells.size()):
		var monster: Monster = monster_scene.instantiate()
		monster.arena = arena
		monster.position = arena.cell_center(cells[i])
		arena.actors.add_child(monster)


func _on_bomber_died(bomber: Bomber) -> void:
	$Sounds/Death.play()
	shake(6.0)
	hud.mark_dead(bomber.index)
	# Wait a moment before deciding: if the last two bombers die in the
	# same blast, that's a draw, not a win for whoever died last.
	settle_timer.start()


func _on_settle_timer_timeout() -> void:
	var alive := bombers.filter(func(bomber: Bomber) -> bool: return bomber.alive)
	if alive.size() <= 1 and not round_over:
		_end_round(alive[0].index if alive.size() == 1 else -1)


func _end_round(winner: int) -> void:
	round_over = true
	round_timer.stop()
	sudden_death_timer.stop()
	# Freeze the arena: no more bombs, flames or deaths.
	arena.process_mode = Node.PROCESS_MODE_DISABLED
	pause_menu.set_process_unhandled_input(false)
	Match.finish_round(winner)
	$Sounds/RoundEnd.play()
	var champion := Match.match_winner()
	if champion >= 0:
		results.show_match(champion)
	else:
		results.show_round(winner)


func _on_round_timer_timeout() -> void:
	if not Settings.sudden_death:
		_end_round(-1) # Time's up: nobody wins.
		return
	hud.show_hurry()
	_closing_cells = arena.spiral_cells()
	sudden_death_timer.start()


func _on_sudden_death_timer_timeout() -> void:
	if _closing_cells.is_empty():
		sudden_death_timer.stop()
		return
	arena.drop_wall(_closing_cells.pop_front())


func _on_arena_exploded(_cells: Array[Vector2i]) -> void:
	$Sounds/Explosion.play()
	shake(2.0)


func _on_block_destroyed(cell: Vector2i) -> void:
	var debris: CPUParticles2D = debris_scene.instantiate()
	debris.position = arena.cell_center(cell)
	arena.add_child(debris)


func _on_wall_dropped(_cell: Vector2i) -> void:
	$Sounds/Thud.play()
	shake(1.0)


func _on_bomber_powered_up(_kind: PowerUp.Kind) -> void:
	$Sounds/PowerUp.play()


func shake(strength: float) -> void:
	if _shake_tween:
		_shake_tween.kill()
	_shake_tween = create_tween()
	for i in 6:
		var offset := Vector2(randf_range(-strength, strength), randf_range(-strength, strength))
		_shake_tween.tween_property(camera, "offset", offset, 0.03)
	_shake_tween.tween_property(camera, "offset", Vector2.ZERO, 0.03)
