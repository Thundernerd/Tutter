extends CanvasLayer
## Round and match results, shown over the frozen arena.

## Seconds before the match buttons respond, so a bomb key still being
## mashed when the match ends doesn't press Rematch by accident.
const INPUT_DELAY := 1.0

@onready var title: Label = %Title
@onready var scoreboard: HBoxContainer = %Scoreboard
@onready var hint: Label = %Hint
@onready var buttons: VBoxContainer = %Buttons
@onready var rematch_button: Button = %RematchButton
@onready var main_menu_button: Button = %MainMenuButton
@onready var next_round_timer: Timer = $NextRoundTimer


func _ready() -> void:
	hide()


## `winner` is a bomber index, or -1 for a draw.
func show_round(winner: int) -> void:
	title.text = "Draw!" if winner < 0 else "%s wins the round!" % Match.bombers[winner].name
	hint.text = "Round %d next…" % Match.round_number
	_fill_scoreboard()
	buttons.hide()
	show()
	next_round_timer.start()


func show_match(winner: int) -> void:
	title.text = "%s wins the match!" % Match.bombers[winner].name
	hint.text = "First to %d wins" % Settings.rounds_to_win
	_fill_scoreboard()
	rematch_button.disabled = true
	main_menu_button.disabled = true
	show()
	create_tween().tween_callback(_enable_buttons).set_delay(INPUT_DELAY)


func _enable_buttons() -> void:
	rematch_button.disabled = false
	main_menu_button.disabled = false
	rematch_button.grab_focus()


func _fill_scoreboard() -> void:
	for i in Match.bombers.size():
		var label := Label.new()
		label.text = "%s\n%d" % [Match.bombers[i].name, Match.wins[i]]
		label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		label.modulate = Match.bombers[i].color
		scoreboard.add_child(label)


func _on_next_round_timer_timeout() -> void:
	get_tree().reload_current_scene()


func _on_rematch_button_pressed() -> void:
	Match.restart()
	get_tree().reload_current_scene()


func _on_main_menu_button_pressed() -> void:
	get_tree().change_scene_to_file("res://main_menu.tscn")
