extends Control

@onready var vs_cpu_button: Button = %VsCpuButton
@onready var monsters_check: CheckButton = %MonstersCheck


func _ready() -> void:
	monsters_check.set_pressed_no_signal(Settings.monsters)
	vs_cpu_button.grab_focus()


func _start(mode: Match.Mode) -> void:
	Match.start(mode)
	get_tree().change_scene_to_file("res://game.tscn")


func _on_vs_cpu_button_pressed() -> void:
	_start(Match.Mode.VS_CPU)


func _on_two_players_button_pressed() -> void:
	_start(Match.Mode.TWO_PLAYERS)


func _on_two_players_cpu_button_pressed() -> void:
	_start(Match.Mode.TWO_PLAYERS_VS_CPU)


func _on_monsters_check_toggled(toggled_on: bool) -> void:
	Settings.monsters = toggled_on
	Settings.save_settings()


func _on_back_button_pressed() -> void:
	get_tree().change_scene_to_file("res://main_menu.tscn")
