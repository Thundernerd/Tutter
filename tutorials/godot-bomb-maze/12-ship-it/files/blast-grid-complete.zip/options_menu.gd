extends Control

## Row labels for the controls grid. Each row has a P1 and a P2 button.
const ACTION_LABELS := {
	&"up": "Up",
	&"down": "Down",
	&"left": "Left",
	&"right": "Right",
	&"bomb": "Bomb",
}

## The action waiting for a new key, or &"" when not rebinding.
var _rebinding := &""
var _key_buttons: Dictionary[StringName, Button] = {}

@onready var master_slider: HSlider = %MasterSlider
@onready var sfx_slider: HSlider = %SfxSlider
@onready var fullscreen_check: CheckButton = %FullscreenCheck
@onready var rounds_spin: SpinBox = %RoundsSpin
@onready var difficulty_option: OptionButton = %DifficultyOption
@onready var sudden_death_check: CheckButton = %SuddenDeathCheck
@onready var controls_grid: GridContainer = %ControlsGrid


func _ready() -> void:
	# The *_no_signal setters avoid triggering our change handlers (and the test sound).
	master_slider.set_value_no_signal(Settings.master_volume)
	sfx_slider.set_value_no_signal(Settings.sfx_volume)
	fullscreen_check.set_pressed_no_signal(Settings.fullscreen)
	rounds_spin.set_value_no_signal(Settings.rounds_to_win)
	for difficulty in Settings.DIFFICULTY_NAMES:
		difficulty_option.add_item(difficulty)
	difficulty_option.selected = Settings.cpu_difficulty
	sudden_death_check.set_pressed_no_signal(Settings.sudden_death)
	_build_controls()
	master_slider.grab_focus()


func _build_controls() -> void:
	for header in ["", "P1", "P2"]:
		var label := Label.new()
		label.text = header
		label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		controls_grid.add_child(label)
	for suffix in ACTION_LABELS:
		var label := Label.new()
		label.text = ACTION_LABELS[suffix]
		controls_grid.add_child(label)
		for player in ["p1", "p2"]:
			var action := StringName(player + "_" + suffix)
			var button := Button.new()
			button.custom_minimum_size.x = 76
			button.pressed.connect(_start_rebind.bind(action))
			controls_grid.add_child(button)
			_key_buttons[action] = button
	_refresh_keys()


func _refresh_keys() -> void:
	for action in _key_buttons:
		_key_buttons[action].text = Settings.key_name(action)


func _start_rebind(action: StringName) -> void:
	_rebinding = action
	_key_buttons[action].text = "Press a key…"


func _input(event: InputEvent) -> void:
	if _rebinding == &"" or not (event is InputEventKey and event.pressed and not event.echo):
		return
	get_viewport().set_input_as_handled()
	if event.physical_keycode != KEY_ESCAPE: # Escape cancels.
		Settings.rebind(_rebinding, event.physical_keycode)
	_rebinding = &""
	_refresh_keys() # A swap may have changed another button too.


func _on_master_slider_value_changed(value: float) -> void:
	Settings.master_volume = value
	Settings.apply()


func _on_sfx_slider_value_changed(value: float) -> void:
	Settings.sfx_volume = value
	Settings.apply()
	$TestSound.play() # Let the player hear the new volume.


func _on_fullscreen_check_toggled(toggled_on: bool) -> void:
	Settings.fullscreen = toggled_on
	Settings.apply()


func _on_rounds_spin_value_changed(value: float) -> void:
	Settings.rounds_to_win = int(value)


func _on_difficulty_option_item_selected(index: int) -> void:
	Settings.cpu_difficulty = index


func _on_sudden_death_check_toggled(toggled_on: bool) -> void:
	Settings.sudden_death = toggled_on


func _on_back_button_pressed() -> void:
	Settings.save_settings()
	get_tree().change_scene_to_file("res://main_menu.tscn")
