class_name Bomb
extends StaticBody2D
## A bomb on the grid. When it goes off, the arena works out the blast.

signal exploded(bomb: Bomb)

const FUSE_TIME := 2.5
## Closer than this (half a tile plus half a bomber) and a bomber is touching us.
const TOUCH_DISTANCE := 21.0

## The cell this bomb sits in, and how far its blast reaches. Set by the arena.
var cell := Vector2i.ZERO
var power := 2

## Bombers still standing on the bomb since it was placed. They may walk off it.
var _passengers: Array[Bomber] = []
var _exploded := false

@onready var fuse: Timer = $Fuse
@onready var sprite: Sprite2D = $Sprite2D


func _ready() -> void:
	fuse.start(FUSE_TIME)
	var tween := create_tween().set_loops()
	tween.tween_property(sprite, "scale", Vector2(1.15, 0.9), 0.25)
	tween.tween_property(sprite, "scale", Vector2.ONE, 0.25)
	for bomber: Bomber in get_tree().get_nodes_in_group("bombers"):
		if _touches(bomber):
			bomber.add_collision_exception_with(self)
			_passengers.append(bomber)


func _physics_process(_delta: float) -> void:
	# Once a passenger has stepped off, the bomb is solid for them too.
	for bomber in _passengers.duplicate():
		if not _touches(bomber):
			bomber.remove_collision_exception_with(self)
			_passengers.erase(bomber)


func _touches(bomber: Bomber) -> bool:
	var gap := (bomber.global_position - global_position).abs()
	return gap.x < TOUCH_DISTANCE and gap.y < TOUCH_DISTANCE


func _on_fuse_timeout() -> void:
	explode()


## Go off now: when the fuse runs out, or when another blast reaches us.
func explode() -> void:
	if _exploded:
		return
	_exploded = true
	for bomber in _passengers:
		bomber.remove_collision_exception_with(self)
	exploded.emit(self)
	queue_free()
