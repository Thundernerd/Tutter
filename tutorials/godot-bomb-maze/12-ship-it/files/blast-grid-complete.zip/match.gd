extends Node
## The match in progress: who is playing, and how many rounds each has won.
## Registered as the "Match" autoload, so it survives the scene reloading every round.

enum Mode { VS_CPU, TWO_PLAYERS, TWO_PLAYERS_VS_CPU }

const COLORS: Array[Color] = [
	Color(1, 1, 1),
	Color(1, 0.45, 0.45),
	Color(0.45, 0.8, 1),
	Color(1, 0.85, 0.3),
]

var mode := Mode.TWO_PLAYERS
## One entry per bomber: {name, color, controls}. Empty controls means CPU.
var bombers: Array[Dictionary] = []
var wins: Array[int] = []
var round_number := 1


func _ready() -> void:
	start(mode) # So the game scene also works when run on its own (F6).


func start(new_mode: Mode) -> void:
	mode = new_mode
	bombers.clear()
	match mode:
		Mode.VS_CPU:
			_add("P1", "p1")
			_add("CPU 1")
			_add("CPU 2")
			_add("CPU 3")
		Mode.TWO_PLAYERS:
			_add("P1", "p1")
			_add("P2", "p2")
		Mode.TWO_PLAYERS_VS_CPU:
			_add("P1", "p1")
			_add("P2", "p2")
			_add("CPU 1")
			_add("CPU 2")
	restart()


## Same players, scores back to zero.
func restart() -> void:
	wins.clear()
	wins.resize(bombers.size())
	wins.fill(0)
	round_number = 1


func _add(bomber_name: String, controls := "") -> void:
	bombers.append({name = bomber_name, color = COLORS[bombers.size()], controls = controls})


## Record a round: the winner's index, or -1 for a draw.
func finish_round(winner: int) -> void:
	if winner >= 0:
		wins[winner] += 1
	round_number += 1


## The index of whoever has won the match, or -1 if it isn't over yet.
func match_winner() -> int:
	for i in wins.size():
		if wins[i] >= Settings.rounds_to_win:
			return i
	return -1
