class_name Explosion
extends Area2D
## The flames of one blast. Burns whatever touches them while they last.

const FLAME_TEXTURE := preload("res://art/flame.png")
const LIFETIME := 0.5
## Flames are narrower than a tile, so grazing one from the next lane is safe.
const THICKNESS := 14.0

## The cells on fire, centre first. Set by the arena before adding us.
var cells: Array[Vector2i] = []
var arena: Arena


func _ready() -> void:
	var origin := cells[0]
	for cell in cells:
		_add_sprite(cell, origin)
	_add_arm_shapes(origin)
	var tween := create_tween()
	tween.tween_property(self, "modulate:a", 0.0, 0.2).set_delay(LIFETIME - 0.2)
	tween.tween_callback(queue_free)


func _add_sprite(cell: Vector2i, origin: Vector2i) -> void:
	var sprite := Sprite2D.new()
	sprite.texture = FLAME_TEXTURE
	sprite.hframes = 3
	sprite.position = arena.cell_center(cell) - position
	var offset := cell - origin
	if offset != Vector2i.ZERO:
		var direction := offset.sign()
		sprite.rotation = Vector2(direction).angle()
		# Frame 2 is the rounded tip, for the last cell of an arm.
		sprite.frame = 1 if cells.has(cell + direction) else 2
	add_child(sprite)


## Two rectangles cover the whole cross: one horizontal, one vertical.
func _add_arm_shapes(origin: Vector2i) -> void:
	var first := origin
	var last := origin
	for cell in cells:
		first = first.min(cell)
		last = last.max(cell)
	# Centres of the outermost cells, relative to the explosion.
	var from := arena.cell_center(first) - position
	var to := arena.cell_center(last) - position
	var tile := Vector2(arena.walls.tile_set.tile_size)
	_add_rect(Vector2(from.x, 0), Vector2(to.x, 0), Vector2(tile.x, THICKNESS))
	_add_rect(Vector2(0, from.y), Vector2(0, to.y), Vector2(THICKNESS, tile.y))


func _add_rect(from: Vector2, to: Vector2, padding: Vector2) -> void:
	var shape := RectangleShape2D.new()
	shape.size = (to - from).abs() + padding
	var collision := CollisionShape2D.new()
	collision.shape = shape
	collision.position = (from + to) / 2
	add_child(collision)


func _on_body_entered(body: Node2D) -> void:
	if body.has_method("burn"):
		body.burn()


func _on_area_entered(area: Area2D) -> void:
	if area.has_method("burn"):
		area.burn()
