class_name PowerUp
extends Area2D
## An upgrade left behind by a destroyed block.

enum Kind { BOMB, FIRE, SPEED }

## A revealed power-up ignores the blast that uncovered it for this long.
const SPAWN_PROTECTION := 0.6

@export var kind := Kind.BOMB

var _age := 0.0

@onready var sprite: Sprite2D = $Sprite2D


func _ready() -> void:
	sprite.frame = kind
	var tween := create_tween().set_loops()
	tween.tween_property(sprite, "position:y", -2.0, 0.4).set_trans(Tween.TRANS_SINE)
	tween.tween_property(sprite, "position:y", 0.0, 0.4).set_trans(Tween.TRANS_SINE)


func _process(delta: float) -> void:
	_age += delta


func _on_body_entered(body: Node2D) -> void:
	if body is Bomber and body.alive and not is_queued_for_deletion():
		body.collect(kind)
		queue_free()


func burn() -> void:
	if _age >= SPAWN_PROTECTION:
		queue_free()
