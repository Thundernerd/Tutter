extends CanvasLayer
## The bar above the arena: every bomber's wins, and the round clock.

const BOMBER_ICON := preload("res://bomber_icon.tres")

var _slots: Array[Control] = []

@onready var left_slots: HBoxContainer = %LeftSlots
@onready var right_slots: HBoxContainer = %RightSlots
@onready var time_label: Label = %TimeLabel


## Build one slot per bomber: even indices on the left, odd on the right.
func setup(bombers: Array[Dictionary], wins: Array[int]) -> void:
	for i in bombers.size():
		var icon := TextureRect.new()
		icon.texture = BOMBER_ICON
		icon.self_modulate = bombers[i].color
		icon.stretch_mode = TextureRect.STRETCH_KEEP_CENTERED
		var label := Label.new()
		label.text = "%s\nWins: %d" % [bombers[i].name, wins[i]]
		var slot := HBoxContainer.new()
		slot.add_child(icon)
		slot.add_child(label)
		(left_slots if i % 2 == 0 else right_slots).add_child(slot)
		_slots.append(slot)


func mark_dead(index: int) -> void:
	_slots[index].modulate.a = 0.35


func show_time(seconds: float) -> void:
	var whole := ceili(seconds)
	time_label.text = "%d:%02d" % [floori(whole / 60.0), whole % 60]


func show_hurry() -> void:
	time_label.text = "HURRY!"
	time_label.modulate = Color(1, 0.4, 0.3)
