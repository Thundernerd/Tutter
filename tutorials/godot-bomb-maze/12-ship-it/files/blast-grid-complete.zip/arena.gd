class_name Arena
extends Node2D
## The playing field. Owns the tile layers and knows what is in every cell.
##
## Every gameplay node lives inside the arena, in containers at its origin,
## so a node's `position` and the tile layers share one coordinate space.

signal block_destroyed(cell: Vector2i)
signal exploded(cells: Array[Vector2i])
signal wall_dropped(cell: Vector2i)

const SOURCE_ID := 0
const WALL_TILE := Vector2i(1, 0)
const BLOCK_TILE := Vector2i(2, 0)
const DIRECTIONS: Array[Vector2i] = [Vector2i.UP, Vector2i.DOWN, Vector2i.LEFT, Vector2i.RIGHT]
## How many of each power-up hide under the blocks.
const POWER_UP_COUNTS := {PowerUp.Kind.BOMB: 8, PowerUp.Kind.FIRE: 8, PowerUp.Kind.SPEED: 4}

## Chance that a free floor cell starts with a block on it.
@export_range(0.0, 1.0) var block_density := 0.7
@export var bomb_scene: PackedScene
@export var explosion_scene: PackedScene
@export var power_up_scene: PackedScene

## Bombs on the field, by cell.
var bombs: Dictionary[Vector2i, Bomb] = {}
## The power-up hidden under each block that has one.
var hidden_power_ups: Dictionary[Vector2i, PowerUp.Kind] = {}

@onready var floor_layer: TileMapLayer = $Floor
@onready var walls: TileMapLayer = $Walls
@onready var blocks: TileMapLayer = $Blocks
@onready var power_ups: Node2D = $PowerUps
@onready var bomb_container: Node2D = $Bombs
@onready var actors: Node2D = $Actors
@onready var flames: Node2D = $Flames


## The cell containing a point in arena coordinates.
func cell_at(point: Vector2) -> Vector2i:
	return walls.local_to_map(point)


## The centre of a cell, in arena coordinates.
func cell_center(cell: Vector2i) -> Vector2:
	return walls.map_to_local(cell)


func is_wall(cell: Vector2i) -> bool:
	return walls.get_cell_source_id(cell) != -1


func is_block(cell: Vector2i) -> bool:
	return blocks.get_cell_source_id(cell) != -1


## Can a bomber or monster walk into this cell?
func is_free(cell: Vector2i) -> bool:
	return not is_wall(cell) and not is_block(cell) and not bombs.has(cell)


## The four corners where bombers start: top-left, bottom-right, top-right, bottom-left.
func spawn_cells() -> Array[Vector2i]:
	var area := floor_layer.get_used_rect()
	var first := area.position
	var last := area.end - Vector2i.ONE
	return [first, last, Vector2i(last.x, first.y), Vector2i(first.x, last.y)]


## Fill the arena with fresh blocks, leaving room around the spawn corners.
func generate() -> void:
	blocks.clear()
	hidden_power_ups.clear()
	var spawns := spawn_cells()
	var block_cells: Array[Vector2i] = []
	for cell in floor_layer.get_used_cells():
		if is_wall(cell) or _near_any(cell, spawns, 1) or randf() > block_density:
			continue
		blocks.set_cell(cell, SOURCE_ID, BLOCK_TILE)
		block_cells.append(cell)
	# Hide the power-ups under random blocks.
	block_cells.shuffle()
	for kind in POWER_UP_COUNTS:
		for i in POWER_UP_COUNTS[kind]:
			if not block_cells.is_empty():
				hidden_power_ups[block_cells.pop_back()] = kind


## Floor cells that are free and at least `distance` steps from every spawn.
func free_cells_away_from_spawns(distance: int) -> Array[Vector2i]:
	var spawns := spawn_cells()
	var result: Array[Vector2i] = []
	for cell in floor_layer.get_used_cells():
		if is_free(cell) and not _near_any(cell, spawns, distance - 1):
			result.append(cell)
	return result


func _near_any(cell: Vector2i, others: Array[Vector2i], steps: int) -> bool:
	for other in others:
		if absi(cell.x - other.x) + absi(cell.y - other.y) <= steps:
			return true
	return false


## Put a bomb in a cell. Returns null when there is already one.
func place_bomb(cell: Vector2i, power: int) -> Bomb:
	if bombs.has(cell):
		return null
	var bomb: Bomb = bomb_scene.instantiate()
	bomb.cell = cell
	bomb.power = power
	bomb.position = cell_center(cell)
	bomb.exploded.connect(_on_bomb_exploded)
	bombs[cell] = bomb
	bomb_container.add_child(bomb)
	return bomb


## Every cell a blast from `origin` reaches: the centre plus four arms of up to
## `power` cells. Arms stop before walls, and at the first block (which burns).
func blast_cells(origin: Vector2i, power: int) -> Array[Vector2i]:
	var cells: Array[Vector2i] = [origin]
	for direction in DIRECTIONS:
		for distance in range(1, power + 1):
			var cell := origin + direction * distance
			if is_wall(cell):
				break
			cells.append(cell)
			if is_block(cell):
				break
	return cells


func _on_bomb_exploded(bomb: Bomb) -> void:
	bombs.erase(bomb.cell)
	var cells := blast_cells(bomb.cell, bomb.power)
	var explosion: Explosion = explosion_scene.instantiate()
	explosion.arena = self
	explosion.cells = cells
	explosion.position = cell_center(bomb.cell)
	flames.add_child(explosion)
	exploded.emit(cells)
	# Set off other bombs first, so their blasts still stop at the blocks
	# this one is about to destroy.
	for cell in cells:
		if bombs.has(cell):
			bombs[cell].explode()
	for cell in cells:
		if is_block(cell):
			destroy_block(cell)


func destroy_block(cell: Vector2i) -> void:
	blocks.erase_cell(cell)
	block_destroyed.emit(cell)
	if hidden_power_ups.has(cell):
		var power_up: PowerUp = power_up_scene.instantiate()
		power_up.kind = hidden_power_ups[cell]
		power_up.position = cell_center(cell)
		hidden_power_ups.erase(cell)
		power_ups.add_child(power_up)


## Seconds until each threatened cell catches fire. Burning cells are 0.
## `extra_bombs` (cell -> power) lets the CPU try out a bomb before placing it.
func danger_map(extra_bombs: Dictionary[Vector2i, int] = {}) -> Dictionary[Vector2i, float]:
	var danger: Dictionary[Vector2i, float] = {}
	for explosion: Explosion in flames.get_children():
		for cell in explosion.cells:
			danger[cell] = 0.0
	# When each bomb goes off, and how far it reaches.
	var fuses: Dictionary[Vector2i, float] = {}
	var powers: Dictionary[Vector2i, int] = {}
	for cell in bombs:
		fuses[cell] = bombs[cell].fuse.time_left
		powers[cell] = bombs[cell].power
	for cell in extra_bombs:
		fuses[cell] = Bomb.FUSE_TIME
		powers[cell] = extra_bombs[cell]
	# Chain reactions: a bomb inside another bomb's blast goes off with it.
	# Repeat until nothing changes, because chains can be any length.
	var changed := true
	while changed:
		changed = false
		for cell in fuses:
			for target in blast_cells(cell, powers[cell]):
				if fuses.has(target) and fuses[target] > fuses[cell]:
					fuses[target] = fuses[cell]
					changed = true
	for cell in fuses:
		for target in blast_cells(cell, powers[cell]):
			danger[target] = minf(danger.get(target, INF), fuses[cell])
	return danger


## Floor cells from the outside in, ring by ring, for sudden death.
func spiral_cells() -> Array[Vector2i]:
	var area := floor_layer.get_used_rect()
	var left := area.position.x
	var top := area.position.y
	var right := area.end.x - 1
	var bottom := area.end.y - 1
	var cells: Array[Vector2i] = []
	while left <= right and top <= bottom:
		for x in range(left, right + 1):
			cells.append(Vector2i(x, top))
		for y in range(top + 1, bottom + 1):
			cells.append(Vector2i(right, y))
		if top < bottom:
			for x in range(right - 1, left - 1, -1):
				cells.append(Vector2i(x, bottom))
		if left < right:
			for y in range(bottom - 1, top, -1):
				cells.append(Vector2i(left, y))
		left += 1
		top += 1
		right -= 1
		bottom -= 1
	return cells.filter(func(cell: Vector2i) -> bool: return not is_wall(cell))


## Sudden death: turn a cell into a wall, crushing whatever is in it.
func drop_wall(cell: Vector2i) -> void:
	blocks.erase_cell(cell)
	hidden_power_ups.erase(cell)
	if bombs.has(cell):
		bombs[cell].explode()
	walls.set_cell(cell, SOURCE_ID, WALL_TILE)
	for power_up in power_ups.get_children():
		if cell_at(power_up.position) == cell:
			power_up.queue_free()
	# Bombers and monsters both have burn(): crushed is as dead as burned.
	for actor: Node2D in actors.get_children():
		if cell_at(actor.position) == cell:
			actor.burn()
	wall_dropped.emit(cell)
