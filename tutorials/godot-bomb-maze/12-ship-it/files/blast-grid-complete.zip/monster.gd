class_name Monster
extends Area2D
## A wandering monster. Walks cell to cell, turns at random, and kills on touch.

@export var speed := 40.0
## Chance of turning at a crossing even when the way ahead is open.
@export_range(0.0, 1.0) var turn_chance := 0.3

## Set by the game before the monster enters the tree.
var arena: Arena
## The cell we're walking to (or standing in), and the way we're heading.
var cell := Vector2i.ZERO
var direction := Vector2i.ZERO
var alive := true

@onready var sprite: AnimatedSprite2D = $AnimatedSprite2D


func _ready() -> void:
	cell = arena.cell_at(position)


func _physics_process(delta: float) -> void:
	var target := arena.cell_center(cell)
	position = position.move_toward(target, speed * delta)
	if position == target:
		_choose_direction()
		cell += direction


func _choose_direction() -> void:
	var options: Array[Vector2i] = []
	for option in Arena.DIRECTIONS:
		# Turning back is a last resort, so monsters don't jitter in place.
		if option != -direction and arena.is_free(cell + option):
			options.append(option)
	if options.is_empty():
		direction = -direction if arena.is_free(cell - direction) else Vector2i.ZERO
	elif not options.has(direction) or randf() < turn_chance:
		direction = options.pick_random()


func _on_body_entered(body: Node2D) -> void:
	if alive and body is Bomber:
		body.die()


func burn() -> void:
	if not alive:
		return
	alive = false
	set_physics_process(false)
	set_deferred("monitoring", false)
	set_deferred("monitorable", false)
	var tween := create_tween()
	tween.tween_property(sprite, "scale", Vector2(1.6, 1.6), 0.15)
	tween.parallel().tween_property(sprite, "modulate:a", 0.0, 0.15)
	tween.tween_callback(queue_free)
