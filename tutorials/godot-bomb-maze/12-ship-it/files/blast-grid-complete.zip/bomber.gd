class_name Bomber
extends CharacterBody2D
## A bomber, steered by the keyboard or by a CpuBrain child.

signal died(bomber: Bomber)
signal bomb_placed
signal powered_up(kind: PowerUp.Kind)

const DIRECTIONS := {&"up": Vector2.UP, &"down": Vector2.DOWN, &"left": Vector2.LEFT, &"right": Vector2.RIGHT}
## How far off-centre (in pixels) you must be to slide around a corner.
const CORNER_SLIDE := 6.0
const MAX_SPEED := 120.0
const MAX_BOMBS := 8
const MAX_POWER := 8

## Prefix of this bomber's input actions: "p1" reads p1_up, p1_bomb and so on.
@export var controls := "p1"
@export var color := Color.WHITE
@export var speed := 72.0

## Set by the game before the bomber enters the tree.
var arena: Arena
## Index into Match.bombers.
var index := 0
var is_cpu := false
## The direction we want to move in. Read from the keyboard, or set by a CpuBrain.
var input_direction := Vector2.ZERO
var alive := true
var max_bombs := 1
var power := 2
var active_bombs := 0

## Held directions, most recently pressed last.
var _held: Array[Vector2] = []

@onready var sprite: AnimatedSprite2D = $AnimatedSprite2D
@onready var collision: CollisionShape2D = $CollisionShape2D


func _ready() -> void:
	sprite.self_modulate = color


func _physics_process(delta: float) -> void:
	if not is_cpu:
		input_direction = _read_direction()
		if Input.is_action_just_pressed(controls + "_bomb"):
			place_bomb()
	velocity = _lane_velocity(input_direction, delta)
	move_and_slide()
	_animate(input_direction)


## The most recently pressed direction wins, so you can hold one direction
## and tap another to turn into a side corridor.
func _read_direction() -> Vector2:
	for action_suffix in DIRECTIONS:
		var direction: Vector2 = DIRECTIONS[action_suffix]
		if Input.is_action_pressed(controls + "_" + action_suffix):
			if not _held.has(direction):
				_held.append(direction)
		else:
			_held.erase(direction)
	return _held.back() if not _held.is_empty() else Vector2.ZERO


## Move along the grid: stay centred in the lane, and slide around corners.
func _lane_velocity(direction: Vector2, delta: float) -> Vector2:
	if direction == Vector2.ZERO:
		return Vector2.ZERO
	var cell := arena.cell_at(position)
	var step := Vector2i(direction)
	# The axis we're not moving along, and how far off-centre we are on it.
	var side_axis := Vector2(absf(direction.y), absf(direction.x))
	var offset := (position - arena.cell_center(cell)).dot(side_axis)
	if arena.is_free(cell + step):
		# The way ahead is open: go, while easing back into the middle of the lane.
		var correction := clampf(-offset / delta, -speed, speed)
		return (direction * speed + side_axis * correction).limit_length(speed)
	if absf(offset) > CORNER_SLIDE:
		# Blocked, but we're leaning towards a lane that is open: slide into it.
		var side := Vector2i(side_axis * signf(offset))
		if arena.is_free(cell + side) and arena.is_free(cell + side + step):
			return Vector2(side) * speed
	# Walk up to the obstacle; move_and_slide stops us there.
	return direction * speed


func _animate(direction: Vector2) -> void:
	if direction == Vector2.ZERO:
		sprite.stop() # Frame 0 of every animation is the standing pose.
	elif direction.x != 0:
		sprite.play(&"walk_side")
		sprite.flip_h = direction.x < 0
	else:
		sprite.play(&"walk_down" if direction.y > 0 else &"walk_up")


func can_place_bomb() -> bool:
	return alive and active_bombs < max_bombs


func place_bomb() -> void:
	if not can_place_bomb():
		return
	var bomb := arena.place_bomb(arena.cell_at(position), power)
	if bomb == null:
		return # Already a bomb here.
	active_bombs += 1
	bomb.exploded.connect(_on_bomb_exploded)
	bomb_placed.emit()


func _on_bomb_exploded(_bomb: Bomb) -> void:
	active_bombs -= 1


func collect(kind: PowerUp.Kind) -> void:
	match kind:
		PowerUp.Kind.BOMB:
			max_bombs = mini(max_bombs + 1, MAX_BOMBS)
		PowerUp.Kind.FIRE:
			power = mini(power + 1, MAX_POWER)
		PowerUp.Kind.SPEED:
			speed = minf(speed + 12.0, MAX_SPEED)
	powered_up.emit(kind)


## Called by flames and falling walls.
func burn() -> void:
	die()


func die() -> void:
	if not alive:
		return
	alive = false
	input_direction = Vector2.ZERO
	set_physics_process(false)
	collision.set_deferred("disabled", true)
	sprite.stop()
	died.emit(self)
	# Flash white, then spin away.
	var tween := create_tween()
	tween.tween_property(sprite, "modulate", Color(4, 4, 4), 0.08)
	tween.tween_property(sprite, "modulate", Color.WHITE, 0.08)
	tween.tween_property(sprite, "modulate", Color(4, 4, 4), 0.08)
	tween.tween_property(sprite, "modulate", Color.WHITE, 0.08)
	tween.tween_property(sprite, "rotation", TAU * 2, 0.5)
	tween.parallel().tween_property(sprite, "scale", Vector2.ZERO, 0.5).set_ease(Tween.EASE_IN)
	tween.tween_callback(hide)
