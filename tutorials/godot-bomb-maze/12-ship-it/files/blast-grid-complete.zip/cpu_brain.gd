class_name CpuBrain
extends Node
## Steers its parent Bomber: escapes danger, bombs blocks and rivals,
## and picks up power-ups.

## Seconds of slack the CPU wants between reaching a cell and it catching fire.
const SAFETY_MARGIN := 0.4
## Settings per difficulty: easy, normal, hard.
const LEVELS := [
	{think_interval = 0.5, aggression = 0.3, hunts_rivals = false},
	{think_interval = 0.25, aggression = 0.6, hunts_rivals = true},
	{think_interval = 0.1, aggression = 0.9, hunts_rivals = true},
]

## Seconds between decisions. Slower thinkers react late to new bombs.
@export var think_interval := 0.25
## Chance of taking a bombing opportunity when one comes up.
@export_range(0.0, 1.0) var aggression := 0.6
## Whether to walk towards other bombers, or only clear blocks.
@export var hunts_rivals := true

## The cells to walk through, next one first.
var path: Array[Vector2i] = []

var _think_timer := 0.0

@onready var bomber: Bomber = get_parent()
@onready var arena: Arena = bomber.arena


func set_level(level: int) -> void:
	var settings: Dictionary = LEVELS[level]
	think_interval = settings.think_interval
	aggression = settings.aggression
	hunts_rivals = settings.hunts_rivals


func _physics_process(delta: float) -> void:
	if not bomber.alive:
		return
	_think_timer -= delta
	if _think_timer <= 0.0:
		_think_timer = think_interval
		_think()
	bomber.input_direction = _steer()


func _think() -> void:
	var danger := arena.danger_map()
	_add_monsters(danger)
	var here := arena.cell_at(bomber.position)
	if danger.has(here):
		path = _find_path(here, danger, _is_safe.bind(danger))
		return
	var targets := _target_cells()
	if bomber.can_place_bomb() and _worth_bombing(here, targets) and randf() < aggression:
		# Pretend the bomb is already there, and only drop it if we can get away.
		var with_bomb := arena.danger_map({here: bomber.power})
		_add_monsters(with_bomb)
		var escape := _find_path(here, with_bomb, _is_safe.bind(with_bomb))
		if not escape.is_empty():
			bomber.place_bomb()
			path = escape
			return
	path = _find_path(here, danger, _is_goal.bind(danger, _power_up_cells(), targets))
	if path.is_empty():
		path = _wander(here, danger)


## Treat monsters, and the cell they just left, as fire that's burning now.
func _add_monsters(danger: Dictionary[Vector2i, float]) -> void:
	for monster: Monster in get_tree().get_nodes_in_group("monsters"):
		if monster.alive:
			danger[monster.cell] = 0.0
			danger[monster.cell - monster.direction] = 0.0


## Cells of rival bombers worth blowing up (none for CPUs that don't hunt).
func _target_cells() -> Array[Vector2i]:
	var cells: Array[Vector2i] = []
	if not hunts_rivals:
		return cells
	for other: Bomber in get_tree().get_nodes_in_group("bombers"):
		if other != bomber and other.alive:
			cells.append(arena.cell_at(other.position))
	return cells


func _power_up_cells() -> Array[Vector2i]:
	var cells: Array[Vector2i] = []
	for power_up in arena.power_ups.get_children():
		cells.append(arena.cell_at(power_up.position))
	return cells


func _is_safe(cell: Vector2i, danger: Dictionary[Vector2i, float]) -> bool:
	return not danger.has(cell)


## A safe cell with a power-up, or a good place to drop a bomb.
func _is_goal(cell: Vector2i, danger: Dictionary[Vector2i, float], pickups: Array[Vector2i], targets: Array[Vector2i]) -> bool:
	if danger.has(cell):
		return false
	return pickups.has(cell) or (bomber.can_place_bomb() and _worth_bombing(cell, targets))


## Would a bomb in this cell hit a block, or one of the targets?
func _worth_bombing(cell: Vector2i, targets: Array[Vector2i]) -> bool:
	for target in arena.blast_cells(cell, bomber.power):
		if arena.is_block(target) or targets.has(target):
			return true
	return false


## Breadth-first search from `start` to the nearest cell where `is_goal` is true,
## avoiding cells that will be on fire by the time we get there.
## Returns the cells to walk through (not including start), or [] if there's no way.
func _find_path(start: Vector2i, danger: Dictionary[Vector2i, float], is_goal: Callable) -> Array[Vector2i]:
	var seconds_per_cell := arena.walls.tile_set.tile_size.x / bomber.speed
	var came_from: Dictionary[Vector2i, Vector2i] = {start: start}
	var steps: Dictionary[Vector2i, int] = {start: 0}
	var queue: Array[Vector2i] = [start]
	while not queue.is_empty():
		var cell: Vector2i = queue.pop_front()
		if cell != start and is_goal.call(cell):
			return _path_to(cell, came_from)
		for direction in Arena.DIRECTIONS:
			var next := cell + direction
			if came_from.has(next) or not arena.is_free(next):
				continue
			var arrival := (steps[cell] + 1) * seconds_per_cell
			if danger.get(next, INF) < arrival + SAFETY_MARGIN:
				continue # It would be burning when we got there.
			came_from[next] = cell
			steps[next] = steps[cell] + 1
			queue.append(next)
	return []


func _path_to(goal: Vector2i, came_from: Dictionary[Vector2i, Vector2i]) -> Array[Vector2i]:
	var result: Array[Vector2i] = []
	var cell := goal
	while came_from[cell] != cell:
		result.push_front(cell)
		cell = came_from[cell]
	return result


## Nothing to do: take a step in a random safe direction.
func _wander(here: Vector2i, danger: Dictionary[Vector2i, float]) -> Array[Vector2i]:
	var options: Array[Vector2i] = []
	for direction in Arena.DIRECTIONS:
		var next := here + direction
		if arena.is_free(next) and not danger.has(next):
			options.append(next)
	if options.is_empty():
		return []
	return [options.pick_random()]


## Turn the path into a direction to hold, like a player pressing keys.
func _steer() -> Vector2:
	while not path.is_empty() and bomber.position.distance_to(arena.cell_center(path[0])) < 2.0:
		path.pop_front()
	# With nowhere to go, finish stepping into the middle of the current cell:
	# a safe cell only keeps us safe once our whole body is inside it.
	var target := arena.cell_center(arena.cell_at(bomber.position))
	if not path.is_empty():
		target = arena.cell_center(path[0])
	var to_target := target - bomber.position
	if to_target.length() < 2.0:
		return Vector2.ZERO
	if absf(to_target.x) > absf(to_target.y):
		return Vector2(signf(to_target.x), 0)
	return Vector2(0, signf(to_target.y))
