extends CanvasLayer

@onready var score_label: Label = %ScoreLabel
@onready var record_label: Label = %RecordLabel
@onready var play_again_button: Button = %PlayAgainButton


func _ready() -> void:
	hide()


func show_result(score: int, new_record: bool) -> void:
	score_label.text = "Score: %d" % score
	record_label.visible = new_record
	show()
	play_again_button.grab_focus()


func _on_play_again_button_pressed() -> void:
	get_tree().reload_current_scene()


func _on_main_menu_button_pressed() -> void:
	get_tree().change_scene_to_file("res://main_menu.tscn")
