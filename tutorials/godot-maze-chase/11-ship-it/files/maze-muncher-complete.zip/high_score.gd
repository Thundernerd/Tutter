extends Node
## The best score so far, saved between sessions. Registered as the "HighScore" autoload.

const SAVE_PATH := "user://highscore.cfg"

var best := 0


func _ready() -> void:
	var config := ConfigFile.new()
	if config.load(SAVE_PATH) == OK:
		best = config.get_value("scores", "best", 0)


## Records `score` if it beats the best. Returns true for a new high score.
func submit(score: int) -> bool:
	if score <= best:
		return false
	best = score
	var config := ConfigFile.new()
	config.set_value("scores", "best", best)
	config.save(SAVE_PATH)
	return true
