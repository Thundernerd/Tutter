class_name Actor
extends Node2D
## Something that moves through the maze from tile centre to tile centre:
## the player and the ghosts both extend this script.

@export var maze: Maze

var direction := Vector2i.ZERO
## The maze cell the actor's centre is in.
var cell: Vector2i:
	get:
		return maze.pos_to_cell(position)


## Moves `distance` pixels along the grid. Stops at every tile centre on the
## way so the actor can decide where to go next.
func move_on_grid(distance: float) -> void:
	while distance > 0.0 and direction != Vector2i.ZERO:
		var target := maze.next_center(position, direction)
		var to_target := position.distance_to(target)
		if to_target > distance:
			position = position.move_toward(target, distance)
			return
		position = maze.wrap_position(target)
		distance -= to_target
		_on_tile_center()


## Called at every tile centre. Override it to turn, stop or eat.
func _on_tile_center() -> void:
	pass
