class_name Player
extends Actor

signal ate_pellet(power: bool)

const INPUT_DIRECTIONS := {
	&"move_up": Vector2i.UP,
	&"move_down": Vector2i.DOWN,
	&"move_left": Vector2i.LEFT,
	&"move_right": Vector2i.RIGHT,
}

@export var speed := 72.0

## The direction the player asked for. We turn as soon as the maze allows it.
var next_direction := Vector2i.LEFT
## The last direction moved in. The ghosts use it, even while we stand still.
var facing := Vector2i.LEFT

@onready var start_position := position
@onready var sprite: AnimatedSprite2D = $Sprite


func _ready() -> void:
	reset()


func reset() -> void:
	position = start_position
	direction = Vector2i.LEFT
	next_direction = Vector2i.LEFT
	facing = Vector2i.LEFT
	sprite.show()
	sprite.play(&"move")
	_update_sprite()


func _physics_process(delta: float) -> void:
	for action in INPUT_DIRECTIONS:
		if Input.is_action_just_pressed(action):
			next_direction = INPUT_DIRECTIONS[action]
	if next_direction == -direction:
		direction = next_direction # Turning around is allowed anywhere.
	elif direction == Vector2i.ZERO and maze.is_open(cell + next_direction):
		direction = next_direction # Start moving again after a stop.
	move_on_grid(speed * delta)
	_update_sprite()


func _on_tile_center() -> void:
	var eaten := maze.eat_pellet(cell)
	if eaten != Maze.Pellet.NONE:
		ate_pellet.emit(eaten == Maze.Pellet.POWER)
	if maze.is_open(cell + next_direction):
		direction = next_direction
	elif not maze.is_open(cell + direction):
		direction = Vector2i.ZERO # Hit a wall: wait here.


func _update_sprite() -> void:
	if direction != Vector2i.ZERO:
		facing = direction
		sprite.play()
	else:
		sprite.pause()
	sprite.rotation = Vector2(facing).angle()


## Plays the death animation. The rest of the world is frozen while it runs.
func die() -> void:
	sprite.process_mode = Node.PROCESS_MODE_PAUSABLE # Animate even though our parent is disabled.
	sprite.rotation = 0.0
	sprite.play(&"die")
	await sprite.animation_finished
	sprite.process_mode = Node.PROCESS_MODE_INHERIT
	sprite.hide()
