extends CanvasLayer

signal next_level_pressed

@onready var title_label: Label = %TitleLabel
@onready var score_label: Label = %ScoreLabel
@onready var next_button: Button = %NextButton


func _ready() -> void:
	hide()


func show_level(level: int, score: int) -> void:
	title_label.text = "Level %d clear!" % level
	score_label.text = "Score: %d" % score
	show()
	next_button.grab_focus()


func _on_next_button_pressed() -> void:
	hide()
	next_level_pressed.emit()


func _on_main_menu_button_pressed() -> void:
	get_tree().change_scene_to_file("res://main_menu.tscn")
