class_name Maze
extends Node2D
## The maze: builds the walls and pellets from text, and answers questions
## about cells (is it open? is it the tunnel?) for the player and the ghosts.

enum Pellet { NONE, NORMAL, POWER }

const TILE := 10
## # wall   . pellet   o power pellet   _ empty floor   t tunnel   - ghost door
const LAYOUT := """
############################
#..........................#
#.####.#.##########.#.####.#
#o####.#.##########.#.####o#
#..........................#
#.##.###.##########.###.##.#
#.##.###.##########.###.##.#
#.##...#.....##.....#...##.#
#.####.#####.##.#####.####.#
#.####.#####.##.#####.####.#
#......#####.##.#####......#
######.##..........##.######
######.##.###--###.##.######
######.##.#______#.##.######
tttttt.___#______#___.tttttt
######.##.#______#.##.######
######.##.########.##.######
######.##.________.##.######
######.##.########.##.######
#......##.########.##......#
#.####.......##.......####.#
#.####.#####.##.#####.####.#
#o..##.####......####.##..o#
###.##...##.####.##...##.###
###.####.##.####.##.####.###
#......#.....##.....#......#
#.####.#.###.##.###.#.####.#
#.####.#.###.##.###.#.####.#
#............##............#
############################
"""
## Atlas coordinates in tiles.png.
const PELLET_TILE := Vector2i(0, 16)
const POWER_TILE := Vector2i(1, 16)
const DOOR_TILE := Vector2i(2, 16)
## The eight neighbours, in the order of the bits in a wall's mask.
const NEIGHBOURS: Array[Vector2i] = [
	Vector2i(0, -1), Vector2i(1, 0), Vector2i(0, 1), Vector2i(-1, 0),
	Vector2i(1, -1), Vector2i(1, 1), Vector2i(-1, 1), Vector2i(-1, -1),
]

var grid_size := Vector2i.ZERO
var pellets_left := 0
var pellets_total := 0
## Just above the ghost door, and the middle of the ghost house (in pixels).
var house_exit := Vector2.ZERO
var house_center := Vector2.ZERO

var _rows: PackedStringArray
var _astar := AStarGrid2D.new()

@onready var walls: TileMapLayer = $Walls
@onready var pellets: TileMapLayer = $Pellets
@onready var power_pellets: TileMapLayer = $PowerPellets


func _ready() -> void:
	_rows = LAYOUT.strip_edges().split("\n")
	grid_size = Vector2i(_rows[0].length(), _rows.size())
	_build_walls()
	_build_astar()
	reset_pellets()


func _build_walls() -> void:
	var door_cells: Array[Vector2i] = []
	for y in grid_size.y:
		for x in grid_size.x:
			var cell := Vector2i(x, y)
			match _char_at(cell):
				"#":
					walls.set_cell(cell, 0, _wall_tile(cell))
				"-":
					walls.set_cell(cell, 0, DOOR_TILE)
					door_cells.append(cell)
	# Ghosts line up on the middle of the (two cells wide) door.
	var door := (cell_center(door_cells[0]) + cell_center(door_cells[-1])) / 2
	house_exit = door + Vector2(0, -TILE)
	house_center = door + Vector2(0, 2 * TILE)


## Picks the wall picture that matches the walls around `cell`.
func _wall_tile(cell: Vector2i) -> Vector2i:
	var mask := 0
	for i in NEIGHBOURS.size():
		if _char_at(cell + NEIGHBOURS[i]) == "#":
			mask |= 1 << i
	return Vector2i(mask & 15, mask >> 4)


func reset_pellets() -> void:
	pellets.clear()
	power_pellets.clear()
	pellets_left = 0
	for y in grid_size.y:
		for x in grid_size.x:
			var cell := Vector2i(x, y)
			match _char_at(cell):
				".":
					pellets.set_cell(cell, 0, PELLET_TILE)
					pellets_left += 1
				"o":
					power_pellets.set_cell(cell, 0, POWER_TILE)
					pellets_left += 1
	pellets_total = pellets_left


## Removes the pellet at `cell`, if there is one, and says what it was.
func eat_pellet(cell: Vector2i) -> Pellet:
	if pellets.get_cell_source_id(cell) != -1:
		pellets.erase_cell(cell)
		pellets_left -= 1
		return Pellet.NORMAL
	if power_pellets.get_cell_source_id(cell) != -1:
		power_pellets.erase_cell(cell)
		pellets_left -= 1
		return Pellet.POWER
	return Pellet.NONE


func _on_blink_timer_timeout() -> void:
	power_pellets.visible = not power_pellets.visible


## Flashes the walls a few times, for the end of a level.
func flash() -> void:
	# The world is frozen when this runs, so the tween must not belong to the maze.
	var tween := get_tree().create_tween()
	for i in 4:
		tween.tween_property(walls, "modulate", Color(4, 4, 4), 0.2)
		tween.tween_property(walls, "modulate", Color.WHITE, 0.2)
	await tween.finished


## The layout character at `cell`. Beyond the left and right edges every row
## repeats its edge character, so the tunnel carries on outside the maze.
func _char_at(cell: Vector2i) -> String:
	if cell.y < 0 or cell.y >= grid_size.y:
		return "#"
	return _rows[cell.y][clampi(cell.x, 0, grid_size.x - 1)]


func is_open(cell: Vector2i) -> bool:
	return _char_at(cell) not in ["#", "-"]


func is_tunnel(cell: Vector2i) -> bool:
	return _char_at(cell) == "t"


func pos_to_cell(pos: Vector2) -> Vector2i:
	return Vector2i((pos / TILE).floor())


func cell_center(cell: Vector2i) -> Vector2:
	return Vector2(cell * TILE) + Vector2(TILE, TILE) / 2


## The next tile centre reached when moving from `pos` in `direction`.
func next_center(pos: Vector2, direction: Vector2i) -> Vector2:
	var center := cell_center(pos_to_cell(pos))
	if (center - pos).dot(Vector2(direction)) <= 0.0:
		# Already at (or past) this tile's centre: aim for the next tile.
		center += Vector2(direction * TILE)
	return center


## Moves a position that left through one end of the tunnel to the other end.
func wrap_position(pos: Vector2) -> Vector2:
	var cell := pos_to_cell(pos)
	if cell.x < -1:
		pos.x += (grid_size.x + 3) * TILE
	elif cell.x > grid_size.x:
		pos.x -= (grid_size.x + 3) * TILE
	return pos


func _build_astar() -> void:
	_astar.region = Rect2i(Vector2i.ZERO, grid_size)
	_astar.diagonal_mode = AStarGrid2D.DIAGONAL_MODE_NEVER
	_astar.update()
	for y in grid_size.y:
		for x in grid_size.x:
			var cell := Vector2i(x, y)
			_astar.set_point_solid(cell, not is_open(cell))


## The shortest route between two open cells, as a list of cells (empty if there's none).
func find_path(from: Vector2i, to: Vector2i) -> Array[Vector2i]:
	from = from.clamp(Vector2i.ZERO, grid_size - Vector2i.ONE)
	to = to.clamp(Vector2i.ZERO, grid_size - Vector2i.ONE)
	if _astar.is_point_solid(from) or _astar.is_point_solid(to):
		return []
	return _astar.get_id_path(from, to)
