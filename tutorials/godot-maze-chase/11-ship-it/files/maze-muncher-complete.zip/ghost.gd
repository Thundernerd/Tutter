class_name Ghost
extends Actor
## A ghost. The four ghosts share this script; each one extends it to choose
## its own target in chase mode.

enum State { IN_HOUSE, LEAVING, ROAMING, EATEN, ENTERING }

## When two directions are equally good, the first one in this list wins.
const DIRECTIONS: Array[Vector2i] = [Vector2i.UP, Vector2i.LEFT, Vector2i.DOWN, Vector2i.RIGHT]
## Frames in ghost_eyes.png for each direction.
const EYE_FRAMES := {Vector2i.RIGHT: 0, Vector2i.DOWN: 1, Vector2i.LEFT: 2, Vector2i.UP: 3}

@export var color := Color.RED
## The cell this ghost heads for in scatter mode, usually outside a corner of the maze.
@export var scatter_target := Vector2i.ZERO
@export var player: Player
@export var start_in_house := true
## Use real paths (A*) instead of straight-line distance when picking a direction.
@export var use_pathfinding := false

@export_group("Speeds")
@export var speed := 67.5
@export var tunnel_speed := 36.0
@export var house_speed := 36.0
@export var fright_speed := 45.0
@export var eyes_speed := 150.0

var state := State.IN_HOUSE
## False in scatter mode, true in chase mode.
var chasing := false
var frightened := false
## True during the last seconds of frightened mode.
var flashing := false

@onready var start_position := position
@onready var body: AnimatedSprite2D = $Body
@onready var eyes: Sprite2D = $Eyes


func _ready() -> void:
	reset()


func reset() -> void:
	position = start_position
	state = State.IN_HOUSE if start_in_house else State.ROAMING
	direction = Vector2i.UP if start_in_house else Vector2i.LEFT
	chasing = false
	frightened = false
	flashing = false
	show()
	_update_sprite()


func _physics_process(delta: float) -> void:
	var step := _current_speed() * delta
	match state:
		State.IN_HOUSE:
			_bob(step)
		State.LEAVING:
			if _walk_to(maze.house_exit, step):
				state = State.ROAMING
				direction = Vector2i.LEFT
		State.ENTERING:
			if _walk_to(maze.house_center, step):
				state = State.LEAVING # Back to life: head straight out again.
		_:
			move_on_grid(step)
	_update_sprite()


func _current_speed() -> float:
	match state:
		State.EATEN, State.ENTERING:
			return eyes_speed
		State.IN_HOUSE, State.LEAVING:
			return house_speed
	if maze.is_tunnel(cell):
		return tunnel_speed
	if frightened:
		return fright_speed
	return speed


func _on_tile_center() -> void:
	if state == State.EATEN and position.distance_to(maze.house_exit) <= Maze.TILE / 2.0:
		state = State.ENTERING
		direction = Vector2i.ZERO # Stop grid movement; _walk_to takes over.
		return
	direction = _choose_direction()


## The classic rule: never turn around, and take the exit closest to the target.
func _choose_direction() -> Vector2i:
	var options: Array[Vector2i] = []
	for dir in DIRECTIONS:
		if dir != -direction and maze.is_open(cell + dir):
			options.append(dir)
	if options.is_empty():
		return -direction # A dead end: the only way out is back.
	if frightened:
		return options.pick_random()
	var target := get_target()
	var best := options[0]
	var best_distance := INF
	for dir in options:
		var distance := _distance(cell + dir, target)
		if distance < best_distance:
			best = dir
			best_distance = distance
	return best


func _distance(from: Vector2i, to: Vector2i) -> float:
	if use_pathfinding:
		var path := maze.find_path(from, to)
		if not path.is_empty():
			return path.size()
	return from.distance_squared_to(to)


## The cell this ghost is heading for right now.
func get_target() -> Vector2i:
	if state == State.EATEN:
		return maze.pos_to_cell(maze.house_exit)
	if chasing:
		return get_chase_target()
	return scatter_target


## Where to go in chase mode. Each ghost's script overrides this.
func get_chase_target() -> Vector2i:
	return player.cell


## Bobs up and down while waiting in the house.
func _bob(step: float) -> void:
	var limit := start_position.y + direction.y * 4.0
	position.y = move_toward(position.y, limit, step)
	if position.y == limit:
		direction = -direction


## Moves towards `point`, first horizontally, then vertically. Returns true on arrival.
func _walk_to(point: Vector2, step: float) -> bool:
	if position.x != point.x:
		direction = Vector2i(signf(point.x - position.x), 0)
		position.x = move_toward(position.x, point.x, step)
	else:
		direction = Vector2i(0, signf(point.y - position.y))
		position.y = move_toward(position.y, point.y, step)
	return position == point


## Lets the ghost out of the house.
func release() -> void:
	if state == State.IN_HOUSE:
		state = State.LEAVING


func set_chasing(value: bool) -> void:
	chasing = value
	reverse()


## Mode changes make ghosts turn around: the player's warning that something changed.
func reverse() -> void:
	if state == State.ROAMING:
		direction = -direction


func frighten() -> void:
	if state == State.EATEN or state == State.ENTERING:
		return # Eyes can't be frightened.
	frightened = true
	flashing = false
	reverse()


func calm() -> void:
	frightened = false
	flashing = false


## Caught by the player while frightened: only the eyes are left, and they go home.
func eat() -> void:
	frightened = false
	flashing = false
	state = State.EATEN


## Whether the player can bump into this ghost (it isn't tucked away in the house).
func can_touch() -> bool:
	return state == State.ROAMING or state == State.LEAVING


func _update_sprite() -> void:
	body.visible = state != State.EATEN and state != State.ENTERING
	eyes.visible = not frightened
	eyes.frame = EYE_FRAMES.get(direction, eyes.frame)
	if frightened:
		body.self_modulate = Color.WHITE
		body.play(&"flashing" if flashing else &"frightened")
	else:
		body.self_modulate = color
		body.play(&"normal")
