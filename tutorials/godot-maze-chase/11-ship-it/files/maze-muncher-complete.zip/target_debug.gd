extends Node2D
## Draws where each ghost is heading. Toggle it with F1 (the toggle_targets action).


func _ready() -> void:
	hide()


func _unhandled_input(event: InputEvent) -> void:
	if event.is_action_pressed(&"toggle_targets"):
		visible = not visible


func _process(_delta: float) -> void:
	if visible:
		queue_redraw()


func _draw() -> void:
	for ghost: Ghost in get_tree().get_nodes_in_group(&"ghosts"):
		if ghost.state != Ghost.State.ROAMING or ghost.frightened:
			continue
		var target := ghost.get_target()
		var square := Rect2(Vector2(target * Maze.TILE), Vector2(Maze.TILE, Maze.TILE))
		draw_rect(square, ghost.color, false, 1.0)
		draw_line(ghost.position, square.get_center(), Color(ghost.color, 0.5), 1.0)
		if ghost.use_pathfinding:
			for path_cell in ghost.maze.find_path(ghost.cell, target):
				draw_circle(ghost.maze.cell_center(path_cell), 1.5, Color.WHITE)
