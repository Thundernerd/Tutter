extends Ghost
## Rosie, the pink ghost: the ambusher. Aims four tiles ahead of the player.


func get_chase_target() -> Vector2i:
	return player.cell + player.facing * 4
