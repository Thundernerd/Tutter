extends CanvasLayer

## The icon shown for every spare life.
@export var life_texture: Texture2D

@onready var score_label: Label = %ScoreLabel
@onready var high_score_label: Label = %HighScoreLabel
@onready var level_label: Label = %LevelLabel
@onready var fruit_icon: TextureRect = %FruitIcon
@onready var lives_box: HBoxContainer = %LivesBox
@onready var ready_label: Label = %ReadyLabel


func update_score(score: int) -> void:
	score_label.text = str(score)
	high_score_label.text = str(maxi(score, HighScore.best))


func update_lives(lives: int) -> void:
	for icon in lives_box.get_children():
		icon.queue_free()
	# The life being played isn't shown, only the spare ones.
	for i in lives - 1:
		var icon := TextureRect.new()
		icon.texture = life_texture
		icon.flip_h = true
		lives_box.add_child(icon)


func update_level(level: int, fruit_frame: int) -> void:
	level_label.text = str(level)
	var atlas := fruit_icon.texture as AtlasTexture
	atlas.region.position.x = fruit_frame * atlas.region.size.x


func show_ready(on: bool) -> void:
	ready_label.visible = on
