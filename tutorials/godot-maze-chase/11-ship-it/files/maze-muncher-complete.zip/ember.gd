extends Ghost
## Ember, the red ghost: the chaser. Always heads straight for the player.


func get_chase_target() -> Vector2i:
	return player.cell
