extends Node2D

## Speed of "100%" in the level table, in pixels per second.
const BASE_SPEED := 90.0
## Per-level tuning. Levels past the end of the list reuse the last entry.
## player/ghost: speed as a fraction of BASE_SPEED. fright: seconds ghosts stay blue.
## fruit: frame in fruit.png. release: pellets each ghost waits for before leaving the house.
const LEVELS := [
	{player = 0.80, ghost = 0.75, fright = 6.0, fruit = 0, release = [0, 0, 30, 60]},
	{player = 0.90, ghost = 0.85, fright = 5.0, fruit = 1, release = [0, 0, 0, 50]},
	{player = 0.90, ghost = 0.85, fright = 4.0, fruit = 2, release = [0, 0, 0, 0]},
	{player = 0.90, ghost = 0.85, fright = 3.0, fruit = 2, release = [0, 0, 0, 0]},
	{player = 1.00, ghost = 0.95, fright = 2.0, fruit = 3, release = [0, 0, 0, 0]},
	{player = 1.00, ghost = 0.95, fright = 2.0, fruit = 4, release = [0, 0, 0, 0]},
]
## Seconds of scatter, chase, scatter, chase... After the last entry, ghosts chase forever.
const MODE_SCHEDULE := [7.0, 20.0, 7.0, 20.0, 5.0, 20.0, 5.0]
const GHOST_POINTS := [200, 400, 800, 1600]
const FRUIT_POINTS := [100, 300, 500, 700, 1000]
## The fruit appears after this many pellets have been eaten in a level.
const FRUIT_AT_PELLETS := [70, 170]
const EXTRA_LIFE_SCORE := 10000
## How close (in pixels) the player and a ghost or fruit must be to touch.
const TOUCH_DISTANCE := 6.0
## Frightened ghosts start flashing when this many seconds are left.
const FLASH_TIME := 2.0

var score := 0
var lives := 3
var level := 1
## False while the world is frozen: before a round, after a death, between levels.
var playing := false
var _mode_index := 0
var _ghosts_eaten := 0
var _pellets_this_life := 0
var _first_round := true

@onready var world: Node2D = $World
@onready var maze: Maze = $World/Maze
@onready var player: Player = $World/Player
@onready var ghosts := $World/Ghosts.get_children()
@onready var fruit: Sprite2D = $World/Fruit
@onready var mode_timer: Timer = $World/ModeTimer
@onready var fright_timer: Timer = $World/FrightTimer
@onready var release_timer: Timer = $World/ReleaseTimer
@onready var fruit_timer: Timer = $World/FruitTimer
@onready var wait_timer: Timer = $WaitTimer
@onready var hud: CanvasLayer = $HUD
@onready var pause_menu: CanvasLayer = $PauseMenu
@onready var level_clear: CanvasLayer = $LevelClear
@onready var game_over: CanvasLayer = $GameOver
@onready var siren: AudioStreamPlayer = $Sounds/Siren
@onready var power_sound: AudioStreamPlayer = $Sounds/Power


func _ready() -> void:
	lives = Settings.starting_lives
	player.ate_pellet.connect(_on_player_ate_pellet)
	hud.update_score(score)
	hud.update_lives(lives)
	_start_round()


## Puts everyone in their starting spot and shows "READY!" for a moment.
func _start_round() -> void:
	_set_world_running(false)
	player.reset()
	for ghost: Ghost in ghosts:
		ghost.reset()
	_apply_level_speeds()
	hud.update_level(level, _level_data().fruit)
	fruit.hide()
	fright_timer.stop()
	_mode_index = 0
	mode_timer.paused = false
	mode_timer.start(MODE_SCHEDULE[0])
	release_timer.start()
	_pellets_this_life = 0
	hud.show_ready(true)
	if _first_round:
		$Sounds/Start.play()
		_first_round = false
	await _wait(2.0)
	hud.show_ready(false)
	_set_world_running(true)
	_release_ghosts()


## Freezes or unfreezes everything in the maze. Freezing disables the World
## node, which stops its children's processing, timers and animations.
func _set_world_running(running: bool) -> void:
	playing = running
	world.process_mode = Node.PROCESS_MODE_INHERIT if running else Node.PROCESS_MODE_DISABLED


## Waits without blocking the game. Timer nodes pause with the game and vanish with the scene.
func _wait(seconds: float) -> void:
	wait_timer.start(seconds)
	await wait_timer.timeout


func _level_data() -> Dictionary:
	return LEVELS[mini(level, LEVELS.size()) - 1]


func _apply_level_speeds() -> void:
	var data := _level_data()
	player.speed = BASE_SPEED * data.player
	for ghost: Ghost in ghosts:
		ghost.speed = BASE_SPEED * data.ghost


func _physics_process(_delta: float) -> void:
	_update_loops()
	if not playing:
		return
	for ghost: Ghost in ghosts:
		if ghost.can_touch() and player.position.distance_to(ghost.position) < TOUCH_DISTANCE:
			if ghost.frightened:
				_eat_ghost(ghost)
			else:
				_lose_life()
			return
	if fruit.visible and player.position.distance_to(fruit.position) < TOUCH_DISTANCE:
		_eat_fruit()
	var ending := not fright_timer.is_stopped() and fright_timer.time_left < FLASH_TIME
	for ghost: Ghost in ghosts:
		ghost.flashing = ghost.frightened and ending


func _on_player_ate_pellet(power: bool) -> void:
	_add_score(50 if power else 10)
	if not $Sounds/Chomp.playing:
		$Sounds/Chomp.play()
	_pellets_this_life += 1
	release_timer.start() # Restart the "player is dawdling" countdown.
	_release_ghosts()
	if power:
		_start_fright()
	if (maze.pellets_total - maze.pellets_left) in FRUIT_AT_PELLETS:
		_show_fruit()
	if maze.pellets_left == 0:
		_clear_level()


func _add_score(points: int) -> void:
	var before := score
	score += points
	if before < EXTRA_LIFE_SCORE and score >= EXTRA_LIFE_SCORE:
		lives += 1
		hud.update_lives(lives)
		$Sounds/ExtraLife.play()
	hud.update_score(score)


## Scatter and chase take turns, following MODE_SCHEDULE.
func _on_mode_timer_timeout() -> void:
	_mode_index += 1
	for ghost: Ghost in ghosts:
		ghost.set_chasing(_mode_index % 2 == 1)
	if _mode_index < MODE_SCHEDULE.size():
		mode_timer.start(MODE_SCHEDULE[_mode_index])


## Ghosts leave the house in order, each once enough pellets have been eaten.
func _release_ghosts() -> void:
	var limits: Array = _level_data().release
	for i in ghosts.size():
		var ghost: Ghost = ghosts[i]
		if ghost.state != Ghost.State.IN_HOUSE:
			continue
		if _pellets_this_life < limits[i]:
			return # The ghosts behind this one wait too.
		ghost.release()


## The player hasn't eaten for a while: send the next ghost out anyway.
func _on_release_timer_timeout() -> void:
	for ghost: Ghost in ghosts:
		if ghost.state == Ghost.State.IN_HOUSE:
			ghost.release()
			return


func _start_fright() -> void:
	_ghosts_eaten = 0
	mode_timer.paused = true # The scatter/chase clock stops while ghosts are frightened.
	fright_timer.start(_level_data().fright)
	player.speed = BASE_SPEED * minf(_level_data().player + 0.1, 1.0)
	for ghost: Ghost in ghosts:
		ghost.frighten()


func _on_fright_timer_timeout() -> void:
	mode_timer.paused = false
	for ghost: Ghost in ghosts:
		ghost.calm()
	_apply_level_speeds()


func _eat_ghost(ghost: Ghost) -> void:
	var points: int = GHOST_POINTS[mini(_ghosts_eaten, GHOST_POINTS.size() - 1)]
	_ghosts_eaten += 1
	_add_score(points)
	ghost.eat()
	$Sounds/EatGhost.play()
	_show_points(points, ghost.position)
	# A short freeze, with the points where the ghost was, makes the catch feel good.
	_set_world_running(false)
	player.hide()
	ghost.hide()
	await _wait(0.6)
	player.show()
	ghost.show()
	_set_world_running(true)


func _lose_life() -> void:
	_set_world_running(false)
	await _wait(1.0)
	for ghost: Ghost in ghosts:
		ghost.hide()
	fruit.hide()
	$Sounds/Death.play()
	await player.die()
	lives -= 1
	hud.update_lives(lives)
	if lives == 0:
		_game_over()
		return
	await _wait(0.5)
	_start_round()


func _show_fruit() -> void:
	fruit.frame = _level_data().fruit
	fruit.show()
	fruit_timer.start()


func _on_fruit_timer_timeout() -> void:
	fruit.hide()


func _eat_fruit() -> void:
	var points: int = FRUIT_POINTS[fruit.frame]
	fruit.hide()
	fruit_timer.stop()
	_add_score(points)
	$Sounds/EatFruit.play()
	_show_points(points, fruit.position)


## A small score label that floats where something was eaten.
func _show_points(points: int, at: Vector2) -> void:
	var label := Label.new()
	label.text = str(points)
	label.add_theme_font_size_override(&"font_size", 9)
	label.add_theme_color_override(&"font_color", Color(0.4, 0.9, 1.0))
	label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	label.size = Vector2(40, 14)
	label.position = at - label.size / 2
	world.add_child(label)
	var tween := get_tree().create_tween()
	tween.tween_interval(1.2)
	tween.tween_callback(label.queue_free)


func _clear_level() -> void:
	_set_world_running(false)
	await _wait(1.0)
	for ghost: Ghost in ghosts:
		ghost.hide()
	fruit.hide()
	await maze.flash()
	pause_menu.set_process_unhandled_input(false)
	level_clear.show_level(level, score)
	await level_clear.next_level_pressed
	pause_menu.set_process_unhandled_input(true)
	level += 1
	maze.reset_pellets()
	_start_round()


func _game_over() -> void:
	pause_menu.set_process_unhandled_input(false)
	var new_record: bool = HighScore.submit(score)
	game_over.show_result(score, new_record)


## Keeps the siren or the power-mode sound looping while the game runs.
func _update_loops() -> void:
	var powered := playing and not fright_timer.is_stopped()
	_play_if(siren, playing and not powered)
	_play_if(power_sound, powered)
	# The siren rises as the maze empties.
	siren.pitch_scale = 1.0 + 0.5 * (1.0 - float(maze.pellets_left) / maze.pellets_total)


func _play_if(sound: AudioStreamPlayer, on: bool) -> void:
	if on and not sound.playing:
		sound.play()
	elif not on and sound.playing:
		sound.stop()
