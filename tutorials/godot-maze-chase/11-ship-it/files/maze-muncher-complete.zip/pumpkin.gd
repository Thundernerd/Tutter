extends Ghost
## Pumpkin, the orange ghost: the shy one. Chases from afar, retreats when close.

## Closer than this (in tiles), Pumpkin loses its nerve and heads for its corner.
@export var shy_distance := 8.0


func get_chase_target() -> Vector2i:
	if Vector2(cell).distance_to(Vector2(player.cell)) > shy_distance:
		return player.cell
	return scatter_target
