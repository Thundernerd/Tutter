extends Ghost
## Frost, the cyan ghost: the flanker. Teams up with Ember to box the player in.

## The ghost Frost works with. Set to Ember in the game scene.
@export var partner: Ghost


func get_chase_target() -> Vector2i:
	var pivot := player.cell + player.facing * 2
	# Double the arrow from Ember to the pivot: Frost ends up on the far side of the player.
	return pivot + (pivot - partner.cell)
