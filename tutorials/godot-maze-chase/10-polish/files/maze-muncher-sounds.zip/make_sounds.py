"""Generate the Maze Muncher sound effects as 8-bit-style WAV files.

Usage: python3 make_sounds.py <output folder>
Only uses the Python standard library.
"""
import math
import os
import struct
import sys
import wave

OUT = sys.argv[1] if len(sys.argv) > 1 else "sounds"
os.makedirs(OUT, exist_ok=True)
RATE = 22050


def square(phase):
    return 1.0 if (phase % 1.0) < 0.5 else -1.0


def triangle(phase):
    p = phase % 1.0
    return 4 * p - 1 if p < 0.5 else 3 - 4 * p


def render(segments, wave_fn=square, volume=0.35):
    """segments: list of (duration, start_freq, end_freq). A frequency of 0 is silence."""
    samples = []
    phase = 0.0
    for duration, f0, f1 in segments:
        n = int(duration * RATE)
        for i in range(n):
            t = i / max(n - 1, 1)
            freq = f0 + (f1 - f0) * t
            if freq <= 0:
                samples.append(0.0)
                continue
            phase += freq / RATE
            # Short fade at both ends of every segment avoids clicks.
            edge = min(i, n - 1 - i) / (RATE * 0.003)
            samples.append(wave_fn(phase) * volume * min(1.0, edge))
    return samples


def save(name, samples, loop=False):
    path = os.path.join(OUT, name)
    with wave.open(path, "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(RATE)
        w.writeframes(b"".join(struct.pack("<h", int(max(-1, min(1, s)) * 32767)) for s in samples))
    if loop:
        add_loop_points(path, 0, len(samples) - 1)


def add_loop_points(path, start, end):
    """Append a 'smpl' chunk so Godot's importer (Loop Mode: Detect From WAV) loops the file."""
    smpl = struct.pack("<9I", 0, 0, int(1e9 / RATE), 60, 0, 0, 0, 1, 0)
    smpl += struct.pack("<6I", 0, 0, start, end, 0, 0)
    with open(path, "r+b") as f:
        data = f.read()
        chunk = b"smpl" + struct.pack("<I", len(smpl)) + smpl
        data = data + chunk
        data = data[:4] + struct.pack("<I", len(data) - 8) + data[8:]
        f.seek(0)
        f.write(data)


# "Waka": one chomp is a quick down-then-up sweep.
save("chomp.wav", render([(0.07, 500, 220), (0.07, 220, 520)], triangle, 0.5))
# Siren: a smooth rise and fall that loops.
save("siren.wav", render([(0.22, 420, 700), (0.22, 700, 420)], triangle, 0.22), loop=True)
# Power mode: a fast, low wobble that loops.
save("power.wav", render([(0.06, 160, 320), (0.06, 320, 160)] * 2, square, 0.16), loop=True)
save("eat_ghost.wav", render([(0.25, 120, 1600)], square, 0.25))
save("eat_fruit.wav", render([(0.06, 900, 900), (0.03, 0, 0), (0.06, 1200, 1200), (0.03, 0, 0), (0.1, 1500, 1500)], square, 0.22))
save("extra_life.wav", render([(0.08, f, f) for f in (523, 659, 784, 1047, 784, 1047)], square, 0.2))
# Death: a descending warble, then two short pops.
death = []
for i in range(10):
    top = 900 - i * 70
    death.append((0.07, top, top - 300))
death += [(0.08, 0, 0), (0.06, 300, 120), (0.05, 0, 0), (0.06, 300, 120)]
save("death.wav", render(death, square, 0.25))
# Start jingle: a short original tune (C major arpeggios), about two seconds.
notes = [(523, 1), (784, 1), (659, 1), (784, 1), (523, 1), (784, 1), (659, 2),
         (587, 1), (880, 1), (698, 1), (880, 1), (587, 1), (880, 1), (698, 2),
         (523, 1), (659, 1), (784, 1), (1047, 3)]
beat = 0.09
save("start.wav", render([seg for f, b in notes for seg in ((beat * b * 0.85, f, f), (beat * b * 0.15, 0, 0))], square, 0.2))
print("Sounds written to", OUT)
