"""Generate the Maze Muncher art: a wall tileset and the sprite sheets.

Usage: python3 make_art.py <output folder>
Needs Pillow (pip install pillow).
"""
import math
import os
import sys

from PIL import Image

OUT = sys.argv[1] if len(sys.argv) > 1 else "art"
os.makedirs(OUT, exist_ok=True)

T = 10  # tile size in pixels
CLEAR = (0, 0, 0, 0)
BAND = (46, 82, 255, 255)
FILL = (14, 20, 70, 255)
PELLET = (255, 206, 170, 255)
DOOR = (255, 184, 222, 255)

# Neighbour bits: N, E, S, W, NE, SE, SW, NW. A set bit means "that neighbour is a wall".
N, E, S, W, NE, SE, SW, NW = (1 << i for i in range(8))
OFFSETS = {N: (0, -1), E: (1, 0), S: (0, 1), W: (-1, 0), NE: (1, -1), SE: (1, 1), SW: (-1, 1), NW: (-1, -1)}
MARGIN = 2  # empty pixels between a corridor and the wall outline
ROUND = 3   # radius of rounded outer corners


def solid_pixels(mask):
    """Which pixels of a 3x3 block of tiles (centred on our wall tile) belong to the wall."""
    walls = {(0, 0)}
    for bit, offset in OFFSETS.items():
        if mask & bit:
            walls.add(offset)

    def is_wall(cx, cy):
        # Cells outside the 3x3 block don't matter for our tile's outline; call them walls.
        if abs(cx) > 1 or abs(cy) > 1:
            return True
        return (cx, cy) in walls

    solid = set()
    for cy in (-1, 0, 1):
        for cx in (-1, 0, 1):
            if not is_wall(cx, cy):
                continue
            open_n = not is_wall(cx, cy - 1)
            open_s = not is_wall(cx, cy + 1)
            open_w = not is_wall(cx - 1, cy)
            open_e = not is_wall(cx + 1, cy)
            for py in range(T):
                for px in range(T):
                    if open_n and py < MARGIN or open_s and py >= T - MARGIN:
                        continue
                    if open_w and px < MARGIN or open_e and px >= T - MARGIN:
                        continue
                    # Inner corners: diagonal open, both sides walls -> cut a notch.
                    notch = False
                    for (dx, dy) in ((-1, -1), (1, -1), (-1, 1), (1, 1)):
                        if is_wall(cx + dx, cy) and is_wall(cx, cy + dy) and not is_wall(cx + dx, cy + dy):
                            in_x = px < MARGIN if dx < 0 else px >= T - MARGIN
                            in_y = py < MARGIN if dy < 0 else py >= T - MARGIN
                            notch = notch or (in_x and in_y)
                    if notch:
                        continue
                    # Outer corners: round them off.
                    rounded = False
                    for (ox, oy, sx, sy) in ((open_w, open_n, -1, -1), (open_e, open_n, 1, -1),
                                             (open_w, open_s, -1, 1), (open_e, open_s, 1, 1)):
                        if ox and oy:
                            # Corner circle centre, ROUND px inside the margin.
                            ccx = MARGIN + ROUND - 0.5 if sx < 0 else T - MARGIN - ROUND - 0.5
                            ccy = MARGIN + ROUND - 0.5 if sy < 0 else T - MARGIN - ROUND - 0.5
                            beyond_x = px < ccx if sx < 0 else px > ccx
                            beyond_y = py < ccy if sy < 0 else py > ccy
                            if beyond_x and beyond_y and math.hypot(px - ccx, py - ccy) > ROUND:
                                rounded = True
                    if rounded:
                        continue
                    solid.add((cx * T + px, cy * T + py))
    return solid


def wall_tile(mask):
    img = Image.new("RGBA", (T, T), CLEAR)
    solid = solid_pixels(mask)
    for py in range(T):
        for px in range(T):
            if (px, py) not in solid:
                continue
            edge = any((px + dx, py + dy) not in solid
                       for dx in range(-2, 3) for dy in range(-2, 3) if dx * dx + dy * dy <= 4)
            img.putpixel((px, py), BAND if edge else FILL)
    return img


def disc(img, cx, cy, r, color):
    for y in range(img.height):
        for x in range(img.width):
            if (x + 0.5 - cx) ** 2 + (y + 0.5 - cy) ** 2 <= r * r:
                img.putpixel((x, y), color)


def make_tiles():
    sheet = Image.new("RGBA", (16 * T, 17 * T), CLEAR)
    for mask in range(256):
        sheet.paste(wall_tile(mask), ((mask & 15) * T, (mask >> 4) * T))
    pellet = Image.new("RGBA", (T, T), CLEAR)
    for y in (4, 5):
        for x in (4, 5):
            pellet.putpixel((x, y), PELLET)
    power = Image.new("RGBA", (T, T), CLEAR)
    disc(power, 5, 5, 4.2, PELLET)
    door = Image.new("RGBA", (T, T), CLEAR)
    for y in (4, 5, 6):
        for x in range(T):
            door.putpixel((x, y), DOOR)
    sheet.paste(pellet, (0, 16 * T))
    sheet.paste(power, (T, 16 * T))
    sheet.paste(door, (2 * T, 16 * T))
    sheet.save(os.path.join(OUT, "tiles.png"))


S = 14  # sprite size
YELLOW = (255, 230, 40, 255)


def muncher(mouth_degrees, facing_up=False):
    """A yellow circle with a wedge cut out, facing right (or up)."""
    img = Image.new("RGBA", (S, S), CLEAR)
    c = S / 2
    for y in range(S):
        for x in range(S):
            dx, dy = x + 0.5 - c, y + 0.5 - c
            if dx * dx + dy * dy > 6.6 ** 2:
                continue
            # Angle from the facing direction, in degrees.
            angle = math.degrees(math.atan2(dx, -dy) if facing_up else math.atan2(dy, dx))
            if abs(angle) < mouth_degrees / 2:
                continue
            img.putpixel((x, y), YELLOW)
    return img


def strip(frames):
    sheet = Image.new("RGBA", (S * len(frames), S), CLEAR)
    for i, frame in enumerate(frames):
        sheet.paste(frame, (i * S, 0))
    return sheet


def make_player():
    strip([muncher(0), muncher(50), muncher(95)]).save(os.path.join(OUT, "player.png"))
    # Death: the mouth opens until nothing is left (drawn facing up, like the classics).
    frames = [muncher(a, facing_up=True) for a in (40, 80, 120, 160, 200, 240, 280, 320, 350)]
    pop = Image.new("RGBA", (S, S), CLEAR)
    for i in range(8):
        a = i * math.pi / 4
        for r in (4, 5, 6):
            pop.putpixel((int(7 + math.cos(a) * r), int(7 + math.sin(a) * r)), YELLOW)
    frames += [pop, Image.new("RGBA", (S, S), CLEAR)]
    strip(frames).save(os.path.join(OUT, "player_death.png"))


def ghost_body(color, wave):
    img = Image.new("RGBA", (S, S), CLEAR)
    for y in range(S):
        for x in range(S):
            cx, cy = x + 0.5, y + 0.5
            inside = False
            if cy < 7:
                inside = (cx - 7) ** 2 + (cy - 7) ** 2 <= 6.5 ** 2
            elif cy < 12:
                inside = 0.5 <= cx <= 13.5
            elif cy < 14:
                # Wavy skirt: three feet that shift every other frame.
                phase = (x + (2 if wave else 0)) % 4
                inside = 0.5 <= cx <= 13.5 and (phase < 2 if cy < 13 else phase == 0)
            if inside:
                img.putpixel((x, y), color)
    return img


def frightened_face(img, eye, mouth):
    for (x, y) in ((4, 5), (5, 5), (4, 6), (5, 6), (8, 5), (9, 5), (8, 6), (9, 6)):
        img.putpixel((x, y), eye)
    for x in range(2, 12):
        img.putpixel((x, 10 if x % 2 == 0 else 9), mouth)
    return img


def make_ghosts():
    white = (255, 255, 255, 255)
    blue = (40, 40, 255, 255)
    pale = (235, 235, 255, 255)
    peach = (255, 200, 160, 255)
    red = (230, 30, 30, 255)
    frames = [ghost_body(white, False), ghost_body(white, True),
              frightened_face(ghost_body(blue, False), peach, peach),
              frightened_face(ghost_body(blue, True), peach, peach),
              frightened_face(ghost_body(pale, False), red, red),
              frightened_face(ghost_body(pale, True), red, red)]
    strip(frames).save(os.path.join(OUT, "ghost.png"))
    # Eyes looking right, down, left, up.
    eyes = []
    for (dx, dy) in ((1, 0), (0, 1), (-1, 0), (0, -1)):
        img = Image.new("RGBA", (S, S), CLEAR)
        for ex in (4, 9):
            for y in range(3, 8):
                for x in range(ex - 2, ex + 2):
                    if (x + 0.5 - ex) ** 2 / 4 + (y + 0.5 - 5.5) ** 2 / 6.25 <= 1:
                        img.putpixel((x + dx, y + dy), white)
            for y in (5, 6):
                for x in (ex - 1, ex):
                    img.putpixel((x + dx * 2, y + dy * 2), (30, 50, 220, 255))
        eyes.append(img)
    strip(eyes).save(os.path.join(OUT, "ghost_eyes.png"))


def make_fruit():
    green = (60, 200, 60, 255)
    brown = (150, 90, 40, 255)
    frames = []
    # Cherries
    img = Image.new("RGBA", (S, S), CLEAR)
    disc(img, 4.5, 10, 3, (230, 20, 40, 255))
    disc(img, 9.5, 10.5, 3, (230, 20, 40, 255))
    for i in range(6):
        img.putpixel((5 + i // 2, 7 - i), brown)
        img.putpixel((9 - i // 3, 7 - i), brown)
    frames.append(img)
    # Strawberry
    img = Image.new("RGBA", (S, S), CLEAR)
    for y in range(4, 13):
        half = 5 - abs(y - 6) * 0.6 if y > 6 else 5
        for x in range(S):
            if abs(x + 0.5 - 7) <= half:
                img.putpixel((x, y), (235, 40, 50, 255))
    for (x, y) in ((4, 6), (8, 6), (6, 8), (10, 8), (7, 10), (5, 9)):
        img.putpixel((x, y), (255, 240, 200, 255))
    for x in range(4, 10):
        img.putpixel((x, 3), green)
    img.putpixel((7, 2), green)
    frames.append(img)
    # Orange
    img = Image.new("RGBA", (S, S), CLEAR)
    disc(img, 7, 8, 5.5, (255, 150, 30, 255))
    for (x, y) in ((7, 2), (8, 2), (9, 1), (6, 2)):
        img.putpixel((x, y), green)
    frames.append(img)
    # Apple
    img = Image.new("RGBA", (S, S), CLEAR)
    disc(img, 5, 8.5, 4.5, (220, 30, 30, 255))
    disc(img, 9, 8.5, 4.5, (220, 30, 30, 255))
    img.putpixel((7, 3), brown)
    img.putpixel((7, 2), brown)
    img.putpixel((8, 2), green)
    img.putpixel((9, 1), green)
    img.putpixel((5, 7), (255, 200, 200, 255))
    frames.append(img)
    # Melon
    img = Image.new("RGBA", (S, S), CLEAR)
    disc(img, 7, 7.5, 6, (90, 200, 90, 255))
    for y in range(S):
        for x in range(S):
            if img.getpixel((x, y))[3] and (x + y) % 4 == 0:
                img.putpixel((x, y), (30, 120, 40, 255))
    frames.append(img)
    strip(frames).save(os.path.join(OUT, "fruit.png"))


make_tiles()
make_player()
make_ghosts()
make_fruit()
print("Art written to", OUT)
