extends Area2D
## A shot that flies straight up or down. The player's and the invaders' shots share this script.

## Pixels per second. Negative flies up, positive flies down.
@export var speed := -420.0


func _physics_process(delta: float) -> void:
	# Offer the hit to everything we overlap. A bunker may refuse it:
	# the shot is passing through a hole that was already blasted.
	for area in get_overlapping_areas():
		if area.has_method("hit") and area.hit(self):
			queue_free()
			return
	position.y += speed * delta
	if position.y < -16.0 or position.y > get_viewport_rect().size.y + 16.0:
		queue_free()


## Shots can hit each other: the player's shot destroys an invader shot it touches.
func hit(_shot: Area2D) -> bool:
	set_physics_process(false) # queue_free() waits for the end of the frame; stop hitting things now.
	queue_free()
	return true
