extends Node2D

const EXPLOSION_SCENE := preload("res://explosion.tscn")
const UFO_SCENE := preload("res://ufo.tscn")
const DEBRIS_SCENE := preload("res://debris.tscn")
const MARCH_NOTES: Array[AudioStream] = [
	preload("res://sounds/march_1.wav"),
	preload("res://sounds/march_2.wav"),
	preload("res://sounds/march_3.wav"),
	preload("res://sounds/march_4.wav"),
]
## Reaching this score earns one extra life.
const EXTRA_LIFE_SCORE := 1500
## The mystery ship only appears while at least this many invaders are left.
const UFO_MIN_INVADERS := 8

var score := 0
var high_score := 0
var lives := 3
var wave := 1
var _extra_life_awarded := false
var _march_note := 0

@onready var player: Area2D = $Player
@onready var formation: Node2D = $Formation
@onready var hud: CanvasLayer = $HUD
@onready var wave_banner: CanvasLayer = $WaveBanner
@onready var pause_menu: CanvasLayer = $PauseMenu
@onready var game_over: CanvasLayer = $GameOver
@onready var wave_timer: Timer = $WaveTimer
@onready var respawn_timer: Timer = $RespawnTimer
@onready var ufo_timer: Timer = $UfoTimer
@onready var camera: Camera2D = $Camera2D
@onready var flash: ColorRect = %Flash


func _ready() -> void:
	lives = Settings.starting_lives
	high_score = HighScore.load_best()
	hud.set_score(score)
	hud.set_high_score(high_score)
	hud.set_lives(lives)
	player.shot_fired.connect($Sounds/Shoot.play)
	_start_wave()


func _start_wave() -> void:
	formation.build(wave)
	get_tree().call_group("bunkers", "reset")
	hud.set_wave(wave)
	wave_banner.show_message("WAVE %d" % wave, "Get ready!")
	wave_timer.start()
	await wave_timer.timeout
	wave_banner.hide()
	formation.start()
	ufo_timer.start()


func _on_formation_invader_killed(invader: Invader) -> void:
	_add_score(invader.get_points())
	_spawn(EXPLOSION_SCENE, invader.global_position)
	_spawn(DEBRIS_SCENE, invader.global_position)
	$Sounds/InvaderKilled.play()


func _on_formation_stepped() -> void:
	# One note per step: as the steps speed up, so does the beat.
	$Sounds/March.stream = MARCH_NOTES[_march_note]
	$Sounds/March.play()
	_march_note = (_march_note + 1) % MARCH_NOTES.size()


func _on_formation_cleared() -> void:
	ufo_timer.stop()
	_clear_shots()
	wave_banner.show_message("WAVE %d CLEARED" % wave, "Here comes the next one...")
	wave_timer.start()
	await wave_timer.timeout
	wave += 1
	_start_wave()


func _on_formation_landed() -> void:
	# Invaders reached the ground: game over, however many lives are left.
	player.explode()
	lives = 0
	hud.set_lives(lives)
	_end_game()


func _on_player_died() -> void:
	lives -= 1
	hud.set_lives(lives)
	formation.stop()
	_clear_shots()
	$Sounds/PlayerExplosion.play()
	_spawn(DEBRIS_SCENE, player.global_position)
	_shake()
	_flash()
	if lives <= 0:
		_end_game()
		return
	respawn_timer.start()
	await respawn_timer.timeout
	player.respawn()
	formation.start()


func _on_ufo_timer_timeout() -> void:
	ufo_timer.start(randf_range(15.0, 25.0))
	if formation.count() < UFO_MIN_INVADERS:
		return
	var ufo: Area2D = UFO_SCENE.instantiate()
	ufo.direction = [-1.0, 1.0].pick_random()
	ufo.position.y = 40
	ufo.destroyed.connect(_on_ufo_destroyed)
	add_child(ufo)


func _on_ufo_destroyed(points: int) -> void:
	_add_score(points)
	_shake(2.0)


func _add_score(points: int) -> void:
	score += points
	hud.set_score(score)
	if score > high_score:
		high_score = score
		hud.set_high_score(high_score)
	if not _extra_life_awarded and score >= EXTRA_LIFE_SCORE:
		_extra_life_awarded = true
		lives += 1
		hud.set_lives(lives)
		$Sounds/ExtraLife.play()


func _end_game() -> void:
	formation.stop()
	ufo_timer.stop()
	pause_menu.set_process_unhandled_input(false)
	var new_high_score := score > HighScore.load_best()
	if new_high_score:
		HighScore.save_best(score)
	# Same delay as a respawn, so the explosion plays out first.
	respawn_timer.start()
	await respawn_timer.timeout
	game_over.show_result(score, new_high_score)


func _clear_shots() -> void:
	get_tree().call_group("shots", "queue_free")


func _spawn(scene: PackedScene, at: Vector2) -> void:
	var node: Node2D = scene.instantiate()
	node.position = at
	add_child(node)


func _shake(strength := 4.0) -> void:
	if not Settings.screen_effects:
		return
	var tween := create_tween()
	for i in 8:
		var offset := Vector2(randf_range(-strength, strength), randf_range(-strength, strength))
		tween.tween_property(camera, "offset", offset, 0.03)
	tween.tween_property(camera, "offset", Vector2.ZERO, 0.03)


func _flash() -> void:
	if not Settings.screen_effects:
		return
	flash.color.a = 0.35
	create_tween().tween_property(flash, "color:a", 0.0, 0.3)
