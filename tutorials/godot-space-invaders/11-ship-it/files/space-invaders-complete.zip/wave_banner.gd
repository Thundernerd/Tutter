extends CanvasLayer
## Big centred text between waves: "WAVE 2", "WAVE 1 CLEARED".

@onready var title: Label = %Title
@onready var subtitle: Label = %Subtitle


func _ready() -> void:
	hide()


func show_message(text: String, detail: String) -> void:
	title.text = text
	subtitle.text = detail
	show()
