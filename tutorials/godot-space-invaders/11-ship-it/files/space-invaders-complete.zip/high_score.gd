class_name HighScore
## Loads and saves the best score. Every function is static, so no instance is needed:
## call HighScore.load_best() from anywhere.

const SAVE_PATH := "user://high_score.cfg"


static func load_best() -> int:
	var config := ConfigFile.new()
	if config.load(SAVE_PATH) != OK:
		return 0 # No file yet: nobody has played.
	return config.get_value("scores", "best", 0)


static func save_best(score: int) -> void:
	var config := ConfigFile.new()
	config.set_value("scores", "best", score)
	config.save(SAVE_PATH)
