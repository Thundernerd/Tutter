extends Area2D
## A destructible shield. Hits erase pixels from the bunker's own copy of its image.

## How far above and below a shot's centre to look for solid pixels.
const SHOT_REACH := 5
## Radius of the hole a hit blasts, in pixels.
const BLAST_RADIUS := 6

var _image: Image
var _texture: ImageTexture

@onready var sprite: Sprite2D = $Sprite2D
@onready var original: Texture2D = sprite.texture


func _ready() -> void:
	reset()


## Restore the undamaged bunker. Called at the start of every wave.
func reset() -> void:
	# get_image() may return the image the renderer keeps for the original texture,
	# shared by every bunker. Copy it, so each bunker damages only its own pixels.
	_image = Image.new()
	_image.copy_from(original.get_image())
	_texture = ImageTexture.create_from_image(_image)
	sprite.texture = _texture


## Called by every shot that overlaps the bunker, every physics tick.
func hit(shot: Area2D) -> bool:
	# Walk along the shot from its tail to its tip; the first solid pixel is where it struck.
	var forward := int(signf(shot.speed))
	var centre := _to_pixel(shot.global_position)
	for i in range(-SHOT_REACH, SHOT_REACH + 1):
		var pixel := centre + Vector2i(0, i * forward)
		if _is_solid(pixel):
			_blast(pixel)
			return true
	return false # Only empty pixels: let the shot fly on.


func _physics_process(_delta: float) -> void:
	# Our mask only sees invaders. Any invader marching through grinds the bunker away.
	for invader in get_overlapping_areas():
		var top_left := _to_pixel(invader.global_position) - Vector2i(12, 8)
		_image.fill_rect(Rect2i(top_left, Vector2i(24, 16)), Color.TRANSPARENT)
		_texture.update(_image)


## The image pixel under a global position. The sprite is centred on the bunker.
func _to_pixel(global_point: Vector2) -> Vector2i:
	return Vector2i((to_local(global_point) + sprite.texture.get_size() / 2).floor())


func _is_solid(pixel: Vector2i) -> bool:
	var bounds := Rect2i(Vector2i.ZERO, _image.get_size())
	return bounds.has_point(pixel) and _image.get_pixelv(pixel).a > 0.5


## Erase a ragged, roughly round hole.
func _blast(centre: Vector2i) -> void:
	# Work in 2×2 blocks so the holes match the chunky art pixels.
	for y in range(-BLAST_RADIUS, BLAST_RADIUS + 1, 2):
		for x in range(-BLAST_RADIUS, BLAST_RADIUS + 1, 2):
			var distance := Vector2(x, y).length()
			# Always clear the middle; towards the edge, only some blocks.
			if distance < 3.0 or (distance <= BLAST_RADIUS and randf() < 0.5):
				var block := (centre + Vector2i(x, y)).snapped(Vector2i(2, 2))
				_image.fill_rect(Rect2i(block, Vector2i(2, 2)), Color.TRANSPARENT)
	_texture.update(_image)
