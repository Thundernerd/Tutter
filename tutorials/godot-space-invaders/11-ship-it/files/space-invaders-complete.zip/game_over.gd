extends CanvasLayer

@onready var score_label: Label = %ScoreLabel
@onready var new_high_score_label: Label = %NewHighScoreLabel
@onready var play_again_button: Button = %PlayAgainButton


func _ready() -> void:
	hide()


func show_result(score: int, new_high_score: bool) -> void:
	score_label.text = "Score: %d" % score
	new_high_score_label.visible = new_high_score
	show()
	play_again_button.grab_focus()


func _on_play_again_button_pressed() -> void:
	get_tree().reload_current_scene()


func _on_main_menu_button_pressed() -> void:
	get_tree().change_scene_to_file("res://main_menu.tscn")
