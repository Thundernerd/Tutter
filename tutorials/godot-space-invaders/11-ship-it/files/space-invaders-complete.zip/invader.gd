class_name Invader
extends Area2D
## One alien in the formation. The formation moves it; it only animates and dies.

signal died(invader: Invader)

enum Kind { SQUID, CRAB, OCTOPUS }

# Both arrays are indexed by Kind.
const ANIMATIONS: Array[StringName] = [&"squid", &"crab", &"octopus"]
const POINTS: Array[int] = [30, 20, 10]

@export var kind := Kind.OCTOPUS

## The formation column this invader stands in. Set by the formation.
var column := 0

@onready var sprite: AnimatedSprite2D = $AnimatedSprite2D
@onready var shape: CollisionShape2D = $CollisionShape2D


func _ready() -> void:
	sprite.animation = ANIMATIONS[kind]
	# Squids are narrower than octopuses: fit the hitbox to this kind's sprite.
	shape.shape.size = sprite.sprite_frames.get_frame_texture(sprite.animation, 0).get_size()


## Show the other animation frame. Called on every formation step.
func step() -> void:
	sprite.frame = 1 - sprite.frame


func get_points() -> int:
	return POINTS[kind]


## Called by the player's shot.
func hit(_shot: Area2D) -> bool:
	died.emit(self)
	queue_free()
	return true
