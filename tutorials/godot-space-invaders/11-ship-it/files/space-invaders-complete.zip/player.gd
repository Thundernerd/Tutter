extends Area2D
## The player's laser cannon. Moves along the bottom and fires one shot at a time.

signal shot_fired
signal died

const SHOT_SCENE := preload("res://player_shot.tscn")
## How close the ship's centre may get to the screen edge.
const MARGIN := 20.0

@export var speed := 160.0

var _shot_in_flight: Area2D
var _alive := true

@onready var ship: Sprite2D = $Ship
@onready var explosion: AnimatedSprite2D = $Explosion
@onready var start_x := position.x


func _physics_process(delta: float) -> void:
	if not _alive:
		return
	var direction := Input.get_axis("move_left", "move_right")
	position.x += direction * speed * delta
	position.x = clampf(position.x, MARGIN, get_viewport_rect().size.x - MARGIN)
	# Like the arcade: no new shot until the last one is gone.
	if Input.is_action_just_pressed("shoot") and not is_instance_valid(_shot_in_flight):
		_shoot()


func _shoot() -> void:
	_shot_in_flight = SHOT_SCENE.instantiate()
	_shot_in_flight.position = position + Vector2(0, -12)
	add_sibling(_shot_in_flight)
	shot_fired.emit()


## Called by an invader shot that touches the ship.
func hit(_shot: Area2D) -> bool:
	if not _alive:
		return false
	explode()
	died.emit()
	return true


func explode() -> void:
	_alive = false
	ship.hide()
	explosion.show()
	explosion.play()


func respawn() -> void:
	_alive = true
	position.x = start_x
	ship.show()
	explosion.hide()
	explosion.stop()
