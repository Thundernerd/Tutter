extends Node2D
## Builds the grid of invaders, marches it across the screen and makes it shoot.

signal invader_killed(invader: Invader)
signal stepped
signal cleared
signal landed

const INVADER_SCENE := preload("res://invader.tscn")
const SHOT_SCENE := preload("res://invader_shot.tscn")
const COLUMNS := 11
## The kind of invader in each row, top to bottom.
const ROWS := [Invader.Kind.SQUID, Invader.Kind.CRAB, Invader.Kind.CRAB, Invader.Kind.OCTOPUS, Invader.Kind.OCTOPUS]
const SPACING := Vector2(32, 24)
const TOP := 64.0
const STEP := 6.0
const DROP := 12.0
## How close an invader's centre may get to the screen edge.
const MARGIN := 24.0
## An invader this low has reached the player: game over.
const LANDING_Y := 300.0

## Seconds between steps with a full formation...
@export var slowest_step := 0.6
## ...and with a single invader left.
@export var fastest_step := 0.03
## Most invader shots allowed on screen at once.
@export var max_shots := 3
## The player. Every third shot comes from the column closest to it.
@export var target: Node2D

var _invaders: Array[Invader] = []
var _total := 0
var _direction := 1.0
var _shots_fired := 0

@onready var step_timer: Timer = $StepTimer
@onready var shoot_timer: Timer = $ShootTimer


## Line up a fresh formation. Each wave starts one drop lower, up to six drops.
func build(wave: int) -> void:
	for invader in _invaders:
		invader.queue_free()
	_invaders.clear()
	position = Vector2.ZERO
	_direction = 1.0
	var width := (COLUMNS - 1) * SPACING.x
	var origin := Vector2((get_viewport_rect().size.x - width) / 2, TOP + DROP * mini(wave - 1, 6))
	for row in ROWS.size():
		for column in COLUMNS:
			var invader: Invader = INVADER_SCENE.instantiate()
			invader.kind = ROWS[row]
			invader.column = column
			invader.position = origin + Vector2(column, row) * SPACING
			invader.died.connect(_on_invader_died)
			add_child(invader)
			_invaders.append(invader)
	_total = _invaders.size()
	_update_speed()


func start() -> void:
	step_timer.start()
	shoot_timer.start()


func stop() -> void:
	step_timer.stop()
	shoot_timer.stop()


func count() -> int:
	return _invaders.size()


func _on_step_timer_timeout() -> void:
	# Measure the formation using only the invaders still alive.
	var left := INF
	var right := -INF
	var bottom := -INF
	for invader in _invaders:
		left = minf(left, invader.global_position.x)
		right = maxf(right, invader.global_position.x)
		bottom = maxf(bottom, invader.global_position.y)
	var next_left := left + STEP * _direction
	var next_right := right + STEP * _direction
	if next_left < MARGIN or next_right > get_viewport_rect().size.x - MARGIN:
		# The next step would cross the edge: drop down and turn around instead.
		position.y += DROP
		_direction = -_direction
		if bottom + DROP >= LANDING_Y:
			landed.emit()
	else:
		position.x += STEP * _direction
	for invader in _invaders:
		invader.step()
	stepped.emit()


func _on_invader_died(invader: Invader) -> void:
	_invaders.erase(invader)
	invader_killed.emit(invader)
	if _invaders.is_empty():
		stop()
		cleared.emit()
	else:
		_update_speed()


## The fewer invaders are left, the shorter the wait between steps.
func _update_speed() -> void:
	# 1.0 with a full formation, 0.0 with one invader left.
	var fraction := float(_invaders.size() - 1) / maxf(_total - 1, 1)
	step_timer.wait_time = lerpf(fastest_step, slowest_step, fraction)


func _on_shoot_timer_timeout() -> void:
	shoot_timer.wait_time = randf_range(0.4, 1.2)
	if get_tree().get_nodes_in_group("invader_shots").size() >= max_shots:
		return
	var shooters := _bottom_invaders()
	if shooters.is_empty():
		return
	var shooter: Invader = shooters.pick_random()
	_shots_fired += 1
	if target and _shots_fired % 3 == 0:
		shooter = _closest_to_target(shooters)
	var shot: Area2D = SHOT_SCENE.instantiate()
	shot.position = shooter.global_position + Vector2(0, 12)
	add_sibling(shot) # Not a child: shots must not march along with the formation.


## The lowest invader in every column. Only these have a clear line of fire.
func _bottom_invaders() -> Array:
	var lowest := {} # column -> invader
	for invader in _invaders:
		var current: Invader = lowest.get(invader.column)
		if current == null or invader.position.y > current.position.y:
			lowest[invader.column] = invader
	return lowest.values()


func _closest_to_target(shooters: Array) -> Invader:
	var best: Invader = shooters[0]
	for invader: Invader in shooters:
		if absf(invader.global_position.x - target.global_position.x) < absf(best.global_position.x - target.global_position.x):
			best = invader
	return best
