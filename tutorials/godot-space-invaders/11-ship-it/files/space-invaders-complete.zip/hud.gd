extends CanvasLayer

@onready var score_label: Label = %ScoreLabel
@onready var high_score_label: Label = %HighScoreLabel
@onready var wave_label: Label = %WaveLabel
@onready var lives_label: Label = %LivesLabel
@onready var life_icons: HBoxContainer = %LifeIcons


func set_score(score: int) -> void:
	score_label.text = "SCORE %05d" % score


func set_high_score(score: int) -> void:
	high_score_label.text = "HI-SCORE %05d" % score


func set_wave(wave: int) -> void:
	wave_label.text = "WAVE %d" % wave


func set_lives(lives: int) -> void:
	lives_label.text = str(lives)
	# Like the arcade, draw one ship per *spare* life: the ship you're flying isn't counted.
	for i in life_icons.get_child_count():
		life_icons.get_child(i).visible = i < lives - 1
