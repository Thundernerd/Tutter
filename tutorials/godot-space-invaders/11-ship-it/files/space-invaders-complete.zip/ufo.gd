extends Area2D
## The mystery ship. Crosses the top of the screen once and is worth a random bonus.

signal destroyed(points: int)

const POINTS: Array[int] = [50, 100, 150, 300]

@export var speed := 80.0

## 1 flies left to right, -1 right to left. Set it before adding the UFO to the tree.
var direction := 1.0
var _dead := false

@onready var sprite: Sprite2D = $Sprite2D
@onready var score_label: Label = $ScoreLabel
@onready var remove_timer: Timer = $RemoveTimer


func _ready() -> void:
	# Start just outside the edge we fly in from.
	position.x = -32.0 if direction > 0 else get_viewport_rect().size.x + 32.0


func _physics_process(delta: float) -> void:
	if _dead:
		return
	position.x += speed * direction * delta
	if position.x < -40.0 or position.x > get_viewport_rect().size.x + 40.0:
		queue_free() # Made it across.


func hit(_shot: Area2D) -> bool:
	if _dead:
		return false # Already showing its score: let the shot pass.
	_dead = true
	var points: int = POINTS.pick_random()
	destroyed.emit(points)
	sprite.hide()
	score_label.text = str(points)
	score_label.show()
	$FlySound.stop()
	$HitSound.play()
	remove_timer.start()
	return true
