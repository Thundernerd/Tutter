class_name BrickType
extends Resource
## One kind of brick: its colour, how tough it is, and what it's worth.

@export var color := Color.WHITE
## Hits needed to break the brick.
@export_range(1, 5) var hit_points := 1
## Score for breaking it.
@export var points := 10
## Unbreakable bricks bounce the ball forever and don't count towards clearing the level.
@export var unbreakable := false
