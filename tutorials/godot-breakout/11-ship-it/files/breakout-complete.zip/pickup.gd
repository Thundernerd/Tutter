class_name Pickup
extends Area2D
## A power-up capsule that falls from a broken brick until the paddle catches it.

signal collected(kind: Kind)

enum Kind { WIDE, MULTI, SLOW }

const LETTERS := {Kind.WIDE: "W", Kind.MULTI: "M", Kind.SLOW: "S"}
const COLORS := {
	Kind.WIDE: Color(0.31, 0.76, 0.97),
	Kind.MULTI: Color(1.0, 0.72, 0.3),
	Kind.SLOW: Color(0.73, 0.41, 0.78),
}

@export var kind := Kind.WIDE
@export var fall_speed := 80.0


func _ready() -> void:
	$ColorRect.color = COLORS[kind]
	$Label.text = LETTERS[kind]


func _physics_process(delta: float) -> void:
	position.y += fall_speed * delta
	if position.y > get_viewport_rect().size.y + 20:
		queue_free() # Missed it.


func _on_body_entered(_body: Node2D) -> void:
	# The mask only contains the paddle layer, so this can only be the paddle.
	collected.emit(kind)
	queue_free()
