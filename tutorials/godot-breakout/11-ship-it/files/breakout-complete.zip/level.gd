class_name Level
extends Resource
## A level: a title and a text map of bricks.
##
## Each character in `layout` is one grid cell. "." is empty; any other
## character is looked up in the brick grid's `brick_types`.

@export var title := ""
@export_multiline var layout := ""
