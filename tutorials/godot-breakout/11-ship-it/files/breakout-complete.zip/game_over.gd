extends CanvasLayer

@onready var title_label: Label = %TitleLabel
@onready var score_label: Label = %ScoreLabel
@onready var high_score_label: Label = %HighScoreLabel
@onready var play_again_button: Button = %PlayAgainButton


func _ready() -> void:
	hide()


func open(won: bool, score: int, new_high_score: bool) -> void:
	title_label.text = "You win!" if won else "Game over"
	score_label.text = "Score: %d" % score
	high_score_label.visible = new_high_score
	show()
	get_tree().paused = true
	play_again_button.grab_focus()


func _on_play_again_button_pressed() -> void:
	get_tree().paused = false
	get_tree().reload_current_scene()


func _on_main_menu_button_pressed() -> void:
	get_tree().paused = false
	get_tree().change_scene_to_file("res://main_menu.tscn")
