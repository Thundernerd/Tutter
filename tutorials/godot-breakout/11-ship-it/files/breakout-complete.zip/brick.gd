extends StaticBody2D

## Emitted when a hit doesn't break the brick (including unbreakable ones).
signal damaged
signal destroyed

@export var type: BrickType

var hit_points := 1

@onready var rect: ColorRect = $ColorRect


func _ready() -> void:
	hit_points = type.hit_points
	rect.color = type.color


## Called by the ball when it bounces off this brick.
func hit() -> void:
	if hit_points <= 0:
		return # Already destroyed by another ball this frame.
	_flash()
	if type.unbreakable:
		damaged.emit()
		return
	hit_points -= 1
	if hit_points > 0:
		# Darker means closer to breaking.
		rect.color = type.color.darkened(0.5 * (1.0 - float(hit_points) / type.hit_points))
		damaged.emit()
	else:
		destroyed.emit()
		queue_free()


func _flash() -> void:
	modulate = Color(2, 2, 2)
	create_tween().tween_property(self, "modulate", Color.WHITE, 0.1)
