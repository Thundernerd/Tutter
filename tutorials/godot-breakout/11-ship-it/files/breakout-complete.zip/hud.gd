extends CanvasLayer

@onready var score_label: Label = %ScoreLabel
@onready var best_label: Label = %BestLabel
@onready var level_label: Label = %LevelLabel
@onready var lives_label: Label = %LivesLabel
@onready var banner: Label = %Banner


func update_score(score: int, best: int) -> void:
	score_label.text = "Score %d" % score
	best_label.text = "Best %d" % best


func update_level(level: int) -> void:
	level_label.text = "Level %d" % level


func update_lives(lives: int) -> void:
	lives_label.text = "Lives %d" % lives


## Show a message in the middle of the screen for a moment, then fade it out.
func show_banner(text: String) -> void:
	banner.text = text
	banner.modulate.a = 1.0
	var tween := create_tween()
	tween.tween_interval(1.5)
	tween.tween_property(banner, "modulate:a", 0.0, 0.5)
