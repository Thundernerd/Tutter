extends Node2D
## Builds a level's bricks from its text layout and reports when they're all gone.

signal brick_damaged(brick: Node2D)
signal brick_destroyed(brick: Node2D)
signal cleared

const BRICK_SCENE := preload("res://brick.tscn")
## Room for each brick: 46×14 plus a 2px gap.
const CELL_SIZE := Vector2(48, 16)

## Which brick type each layout character stands for.
@export var brick_types: Dictionary[String, BrickType] = {}

## Breakable bricks left. The level is cleared when this reaches 0.
var remaining := 0


func build(level: Level) -> void:
	for child in get_children():
		child.queue_free()
	remaining = 0
	var rows := level.layout.strip_edges().split("\n")
	for row in rows.size():
		var line := rows[row].strip_edges()
		for column in line.length():
			var symbol := line[column]
			if symbol == ".":
				continue
			if not brick_types.has(symbol):
				push_warning("Level '%s' uses unknown brick '%s'" % [level.title, symbol])
				continue
			_add_brick(brick_types[symbol], Vector2(column, row) * CELL_SIZE + CELL_SIZE / 2)


func _add_brick(type: BrickType, at: Vector2) -> void:
	var brick := BRICK_SCENE.instantiate()
	brick.type = type
	brick.position = at
	brick.damaged.connect(brick_damaged.emit.bind(brick))
	brick.destroyed.connect(_on_brick_destroyed.bind(brick))
	add_child(brick)
	if not type.unbreakable:
		remaining += 1


func _on_brick_destroyed(brick: Node2D) -> void:
	remaining -= 1
	brick_destroyed.emit(brick)
	if remaining == 0:
		cleared.emit()
