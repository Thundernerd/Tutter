extends CharacterBody2D

signal hit_paddle
signal hit_wall

@export var start_speed := 240.0
@export var max_speed := 480.0
## Speed multiplier applied on every paddle hit.
@export var speedup := 1.03
## Steepest angle the ball can leave the paddle at, measured from straight up.
@export var max_bounce_angle := 60.0

var speed := 0.0
## 1 normally. The slow-ball power-up lowers it for a while.
var speed_scale := 1.0
## While set, the ball rides on this paddle, waiting to be launched.
var held_by: Node2D


func _physics_process(delta: float) -> void:
	if held_by:
		global_position = held_by.global_position + Vector2(0, -10)
		return
	var collision := move_and_collide(velocity * speed_scale * delta)
	if collision == null:
		return
	var collider := collision.get_collider()
	if collider.is_in_group("paddle"):
		_bounce_off_paddle(collider)
		hit_paddle.emit()
		return
	velocity = velocity.bounce(collision.get_normal())
	if collider.has_method("hit"):
		collider.hit()
	else:
		hit_wall.emit()


## Leave the paddle, heading up at a slightly random angle.
func launch() -> void:
	if held_by == null:
		return
	held_by = null
	speed = start_speed
	velocity = Vector2.UP.rotated(deg_to_rad(randf_range(-30.0, 30.0))) * speed


func _bounce_off_paddle(paddle: Node2D) -> void:
	# -1 at the paddle's left end, 0 in the middle, 1 at the right end.
	var offset := clampf((global_position.x - paddle.global_position.x) / (paddle.width / 2), -1.0, 1.0)
	speed = minf(speed * speedup, max_speed)
	velocity = Vector2.UP.rotated(deg_to_rad(max_bounce_angle) * offset) * speed
