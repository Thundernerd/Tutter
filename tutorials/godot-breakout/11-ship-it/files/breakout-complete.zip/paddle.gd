extends CharacterBody2D

const NORMAL_WIDTH := 64.0
const WIDE_WIDTH := 96.0
## The side walls are 8px thick.
const WALL := 8.0

@export var speed := 420.0

var width := NORMAL_WIDTH

@onready var shape: RectangleShape2D = $CollisionShape2D.shape
@onready var rect: ColorRect = $ColorRect
@onready var wide_timer: Timer = $WideTimer


func _physics_process(delta: float) -> void:
	if Settings.control_scheme == Settings.ControlScheme.MOUSE:
		# Cover the distance to the mouse in exactly one physics tick.
		velocity.x = (get_global_mouse_position().x - global_position.x) / delta
	else:
		velocity.x = Input.get_axis(&"move_left", &"move_right") * speed
	move_and_slide()
	var half_width := width / 2
	position.x = clampf(position.x, WALL + half_width, get_viewport_rect().size.x - WALL - half_width)


## Widen the paddle for `duration` seconds. Catching another one restarts the clock.
func widen(duration: float) -> void:
	wide_timer.start(duration)
	_tween_width(WIDE_WIDTH)


## Back to normal straight away, e.g. after losing a life.
func reset_width() -> void:
	wide_timer.stop()
	_set_width(NORMAL_WIDTH)


func _on_wide_timer_timeout() -> void:
	_tween_width(NORMAL_WIDTH)


func _tween_width(target: float) -> void:
	create_tween().tween_method(_set_width, width, target, 0.2)


func _set_width(value: float) -> void:
	width = value
	shape.size.x = value
	rect.size.x = value
	rect.position.x = -value / 2
