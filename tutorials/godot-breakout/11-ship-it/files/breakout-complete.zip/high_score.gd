class_name HighScore
## Loads and saves the best score. Everything is static: call HighScore.load_best().

const SAVE_PATH := "user://high_score.cfg"


static func load_best() -> int:
	var config := ConfigFile.new()
	if config.load(SAVE_PATH) != OK:
		return 0 # No file yet: nobody has played.
	return config.get_value("scores", "best", 0)


## Saves `score` if it beats the best so far. Returns true for a new high score.
static func submit(score: int) -> bool:
	if score <= load_best():
		return false
	var config := ConfigFile.new()
	config.set_value("scores", "best", score)
	config.save(SAVE_PATH)
	return true
