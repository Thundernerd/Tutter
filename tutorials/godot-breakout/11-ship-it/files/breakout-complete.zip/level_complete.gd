extends CanvasLayer

signal next_pressed

@onready var title_label: Label = %TitleLabel
@onready var score_label: Label = %ScoreLabel
@onready var next_button: Button = %NextButton


func _ready() -> void:
	hide()


func open(level: int, score: int) -> void:
	title_label.text = "Level %d cleared!" % level
	score_label.text = "Score: %d" % score
	show()
	get_tree().paused = true
	next_button.grab_focus()


func _on_next_button_pressed() -> void:
	hide()
	get_tree().paused = false
	next_pressed.emit()
