extends Node2D

const BALL_SCENE := preload("res://ball.tscn")
const PICKUP_SCENE := preload("res://pickup.tscn")
const BURST_SCENE := preload("res://brick_burst.tscn")
const START_LIVES := 3
## How fast balls move while the slow-ball power-up is active.
const SLOW_SCALE := 0.6

@export var levels: Array[Level] = []
## Chance that a broken brick drops a power-up.
@export_range(0.0, 1.0) var drop_chance := 0.15
@export var wide_duration := 12.0
@export var slow_duration := 10.0

var level_index := 0
var score := 0
var best := 0
var lives := START_LIVES
var _shake_tween: Tween

@onready var paddle: CharacterBody2D = $Paddle
@onready var bricks: Node2D = $Bricks
@onready var balls: Node2D = $Balls
@onready var pickups: Node2D = $Pickups
@onready var slow_timer: Timer = $SlowTimer
@onready var camera: Camera2D = $Camera2D
@onready var flash: ColorRect = $Flash/ColorRect
@onready var hud: CanvasLayer = $HUD
@onready var level_complete: CanvasLayer = $LevelComplete
@onready var game_over: CanvasLayer = $GameOver


func _ready() -> void:
	best = HighScore.load_best()
	hud.update_score(score, best)
	hud.update_lives(lives)
	_update_cursor()
	_start_level(0)


func _unhandled_input(event: InputEvent) -> void:
	if event.is_action_pressed("launch"):
		for ball in balls.get_children():
			ball.launch()


func _notification(what: int) -> void:
	if what == NOTIFICATION_PAUSED or what == NOTIFICATION_UNPAUSED:
		_update_cursor()


func _exit_tree() -> void:
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE


## Hide the cursor while playing with the mouse. Paused screens need it back.
func _update_cursor() -> void:
	var hide_cursor := Settings.control_scheme == Settings.ControlScheme.MOUSE and not get_tree().paused
	Input.mouse_mode = Input.MOUSE_MODE_HIDDEN if hide_cursor else Input.MOUSE_MODE_VISIBLE


func _start_level(index: int) -> void:
	level_index = index
	bricks.build(levels[index])
	hud.update_level(index + 1)
	hud.show_banner("Level %d: %s" % [index + 1, levels[index].title])
	_reset_round()


## Clear balls, pickups and power-ups, and put a fresh ball on the paddle.
func _reset_round() -> void:
	for ball in balls.get_children():
		ball.queue_free()
	for pickup in pickups.get_children():
		pickup.queue_free()
	paddle.reset_width()
	slow_timer.stop()
	var ball := _spawn_ball()
	ball.held_by = paddle


func _spawn_ball() -> CharacterBody2D:
	var ball: CharacterBody2D = BALL_SCENE.instantiate()
	ball.hit_paddle.connect($Sounds/PaddleHit.play)
	ball.hit_wall.connect($Sounds/WallHit.play)
	balls.add_child(ball)
	return ball


## Balls still in play. A ball that fell out stays a child until the end of the frame.
func _live_balls() -> Array:
	return balls.get_children().filter(func(ball: Node) -> bool: return not ball.is_queued_for_deletion())


func _on_kill_zone_body_entered(body: Node2D) -> void:
	body.queue_free()
	if not _live_balls().is_empty():
		return # Multi-ball: keep playing while any ball is left.
	lives -= 1
	hud.update_lives(lives)
	$Sounds/LoseLife.play()
	_shake(6.0)
	_flash(Color(1, 0.2, 0.2, 0.35))
	if lives == 0:
		_end_game(false)
	else:
		_reset_round.call_deferred()


func _add_points(points: int) -> void:
	score += points
	best = maxi(best, score)
	hud.update_score(score, best)


func _on_bricks_brick_damaged(_brick: Node2D) -> void:
	$Sounds/BrickHit.play()


func _on_bricks_brick_destroyed(brick: Node2D) -> void:
	_add_points(brick.type.points)
	$Sounds/BrickBreak.play()
	_spawn_burst(brick.global_position, brick.type.color)
	_shake(1.5)
	if randf() < drop_chance:
		_spawn_pickup(brick.global_position)


func _on_bricks_cleared() -> void:
	$Sounds/LevelClear.play()
	if level_index + 1 < levels.size():
		level_complete.open(level_index + 1, score)
	else:
		_end_game(true)


func _on_level_complete_next_pressed() -> void:
	_start_level(level_index + 1)


func _end_game(won: bool) -> void:
	var new_high_score := HighScore.submit(score)
	game_over.open(won, score, new_high_score)


func _spawn_pickup(at: Vector2) -> void:
	var pickup := PICKUP_SCENE.instantiate()
	pickup.kind = Pickup.Kind.values().pick_random()
	pickup.position = at
	pickup.collected.connect(_on_pickup_collected, CONNECT_DEFERRED)
	pickups.add_child(pickup)


func _on_pickup_collected(kind: Pickup.Kind) -> void:
	$Sounds/PowerUp.play()
	match kind:
		Pickup.Kind.WIDE:
			paddle.widen(wide_duration)
		Pickup.Kind.MULTI:
			_split_ball()
		Pickup.Kind.SLOW:
			slow_timer.start(slow_duration)
			for ball in balls.get_children():
				ball.speed_scale = SLOW_SCALE


func _on_slow_timer_timeout() -> void:
	for ball in balls.get_children():
		ball.speed_scale = 1.0


## Two extra balls fly off from the first ball in play.
func _split_ball() -> void:
	var live := _live_balls()
	if live.is_empty():
		return
	var source: CharacterBody2D = live[0]
	source.launch() # In case it's still waiting on the paddle.
	for angle in [-30.0, 30.0]:
		var ball := _spawn_ball()
		ball.global_position = source.global_position
		ball.speed = source.speed
		ball.speed_scale = source.speed_scale
		ball.velocity = Vector2.UP.rotated(deg_to_rad(angle)) * ball.speed


func _spawn_burst(at: Vector2, color: Color) -> void:
	var burst := BURST_SCENE.instantiate()
	burst.position = at
	burst.color = color
	add_child(burst)


func _shake(strength: float) -> void:
	if not Settings.screen_shake:
		return
	if _shake_tween:
		_shake_tween.kill() # A new shake replaces the old one.
	_shake_tween = create_tween()
	for i in 5:
		var offset := Vector2(randf_range(-strength, strength), randf_range(-strength, strength))
		_shake_tween.tween_property(camera, "offset", offset, 0.03)
	_shake_tween.tween_property(camera, "offset", Vector2.ZERO, 0.03)


func _flash(color: Color) -> void:
	flash.color = color
	create_tween().tween_property(flash, "color:a", 0.0, 0.3)
