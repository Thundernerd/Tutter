extends Node2D

## Extra moves per second for every piece of food eaten.
const SPEED_STEP := 0.35
## The fastest the snake will ever go, in moves per second.
const MAX_SPEED := 18.0
const START_LENGTH := 3
const START_CELL := Vector2i(8, 10)

var score := 0

@onready var board: Board = $Board
@onready var snake: Snake = $Board/Snake
@onready var food: Food = $Board/Food
@onready var crash_particles: CPUParticles2D = $Board/CrashParticles
@onready var flash: ColorRect = $Flash
@onready var move_timer: Timer = $MoveTimer
@onready var hud: CanvasLayer = $HUD
@onready var pause_menu: CanvasLayer = $PauseMenu
@onready var game_over: CanvasLayer = $GameOver


func _ready() -> void:
	board.walls_solid = not Settings.wrap_around
	snake.reset(START_CELL, START_LENGTH)
	snake.turned.connect($Sounds/Turn.play)
	hud.update_score(score)
	_place_food()
	_update_speed()
	move_timer.start()


func _on_move_timer_timeout() -> void:
	var head := snake.next_head()
	if Settings.wrap_around:
		head = Board.wrap(head)
	elif not Board.is_inside(head):
		_game_over()
		return
	var eating := head == food.cell
	if snake.hits_itself(head, eating):
		_game_over()
		return
	snake.move_to(head, eating)
	if eating:
		_eat()


func _eat() -> void:
	score += 1
	hud.update_score(score)
	$Sounds/Eat.play()
	_update_speed()
	_place_food()


func _place_food() -> void:
	var cells := Board.free_cells(snake.body)
	if cells.is_empty():
		_game_over() # The snake fills the whole board. Nothing left to eat!
		return
	food.place(cells.pick_random())


func _update_speed() -> void:
	var speed := minf(Settings.start_speed() + score * SPEED_STEP, MAX_SPEED)
	move_timer.wait_time = 1.0 / speed


func _game_over() -> void:
	move_timer.stop()
	snake.set_process_unhandled_input(false)
	pause_menu.set_process_unhandled_input(false)
	$Sounds/Crash.play()
	_crash_effects()
	var new_best := HighScore.submit(score)
	await get_tree().create_timer(1.0).timeout
	game_over.show_result(score, HighScore.best, new_best)


func _crash_effects() -> void:
	# Flash the snake white, then fade it to grey.
	snake.modulate = Color(3, 3, 3)
	create_tween().tween_property(snake, "modulate", Color(0.45, 0.45, 0.45), 0.4)
	# Burst where the head hit: the edge between its cell and the next one.
	crash_particles.position = Board.cell_center(snake.body[0]) + Vector2(snake.direction) * Board.CELL_SIZE / 2
	crash_particles.restart()
	flash.modulate.a = 0.35
	create_tween().tween_property(flash, "modulate:a", 0.0, 0.3)
