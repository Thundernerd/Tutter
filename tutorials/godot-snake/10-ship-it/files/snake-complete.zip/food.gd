class_name Food
extends Node2D
## The food the snake is after. Sits in one grid cell.

const COLOR := Color("ff5d73")
const LEAF_COLOR := Color("b4f07a")

## The grid cell the food is in.
var cell := Vector2i.ZERO

var _tween: Tween


func place(new_cell: Vector2i) -> void:
	cell = new_cell
	position = Board.cell_center(cell)
	# Pop in: grow from nothing, overshooting a little before settling.
	if _tween:
		_tween.kill()
	scale = Vector2.ZERO
	_tween = create_tween()
	_tween.tween_property(self, "scale", Vector2.ONE, 0.3) \
			.set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)


func _draw() -> void:
	# Drawn around (0, 0): the node's position is the centre of the cell.
	draw_circle(Vector2(0, 1), 5.5, COLOR)
	draw_rect(Rect2(0, -7, 3, 3), LEAF_COLOR)
