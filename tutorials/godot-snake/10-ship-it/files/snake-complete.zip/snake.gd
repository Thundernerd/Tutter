class_name Snake
extends Node2D
## The snake: a list of grid cells, head first.

## Emitted when a turn is accepted into the queue.
signal turned

## How many turns can wait for the next moves.
const MAX_QUEUED_TURNS := 2
const DIRECTIONS := {
	&"move_up": Vector2i.UP,
	&"move_down": Vector2i.DOWN,
	&"move_left": Vector2i.LEFT,
	&"move_right": Vector2i.RIGHT,
}
const HEAD_COLOR := Color("b4f07a")
const BODY_COLOR := Color("5fcf6a")
const TAIL_COLOR := Color("2f7d5b")
const EYE_COLOR := Color("10121a")

## Grid cells from the head (index 0) to the tail.
var body: Array[Vector2i] = []
## The direction of the last move.
var direction := Vector2i.RIGHT
var _queued_turns: Array[Vector2i] = []


## Lay the snake out horizontally, head at `head`, facing right.
func reset(head: Vector2i, length: int) -> void:
	body.clear()
	for i in length:
		body.append(head - Vector2i(i, 0))
	direction = Vector2i.RIGHT
	_queued_turns.clear()
	queue_redraw()


func _unhandled_input(event: InputEvent) -> void:
	for action in DIRECTIONS:
		if event.is_action_pressed(action):
			turn(DIRECTIONS[action])


## Queue a turn. Repeating the current direction or reversing into the neck is ignored.
func turn(new_direction: Vector2i) -> void:
	# Compare with the last *queued* direction: that's where we'll be heading by then.
	var last: Vector2i = direction if _queued_turns.is_empty() else _queued_turns.back()
	if new_direction == last or new_direction == -last:
		return
	if _queued_turns.size() < MAX_QUEUED_TURNS:
		_queued_turns.append(new_direction)
		turned.emit()


## Take the next queued turn (if any) and return the cell the head moves into.
func next_head() -> Vector2i:
	if not _queued_turns.is_empty():
		direction = _queued_turns.pop_front()
	return body[0] + direction


## Move the head into `cell`. The tail follows, unless the snake is growing.
func move_to(cell: Vector2i, grow: bool) -> void:
	body.push_front(cell)
	if not grow:
		body.pop_back()
	queue_redraw()


## Would moving the head into `cell` bite the body?
func hits_itself(cell: Vector2i, growing: bool) -> bool:
	var index := body.find(cell)
	if index == -1:
		return false
	# The tail moves out of the way this tick, unless the snake is growing.
	return growing or index != body.size() - 1


func _draw() -> void:
	for i in body.size():
		var color := HEAD_COLOR
		if i > 0:
			color = BODY_COLOR.lerp(TAIL_COLOR, float(i) / body.size())
		draw_rect(Board.cell_rect(body[i]).grow(-1), color)
	_draw_eyes()


func _draw_eyes() -> void:
	var center := Board.cell_center(body[0])
	var forward := Vector2(direction) * 3
	var side := Vector2(-direction.y, direction.x) * 3.5
	for eye in [center + forward + side, center + forward - side]:
		draw_rect(Rect2(eye - Vector2(1.5, 1.5), Vector2(3, 3)), EYE_COLOR)
