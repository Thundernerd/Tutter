class_name Board
extends Node2D
## The playing field. Knows the size of the grid and how grid cells map to pixels.

## The size of one cell, in pixels.
const CELL_SIZE := 16
## Number of columns (x) and rows (y).
const GRID_SIZE := Vector2i(36, 20)

const LIGHT_COLOR := Color("1d2233")
const DARK_COLOR := Color("181c2a")
const WALL_COLOR := Color("8a93b8")

## Solid walls are drawn bright. In wrap-around mode they fade, since they don't hurt.
var walls_solid := true:
	set(value):
		walls_solid = value
		queue_redraw()


func _draw() -> void:
	# A checkerboard makes it easy to see the cells.
	for x in GRID_SIZE.x:
		for y in GRID_SIZE.y:
			var color := LIGHT_COLOR if (x + y) % 2 == 0 else DARK_COLOR
			draw_rect(cell_rect(Vector2i(x, y)), color)
	var wall_color := WALL_COLOR if walls_solid else Color(WALL_COLOR, 0.25)
	draw_rect(Rect2(Vector2.ZERO, Vector2(GRID_SIZE * CELL_SIZE)).grow(1), wall_color, false, 2.0)


## The pixel rectangle covered by a cell, relative to the board.
static func cell_rect(cell: Vector2i) -> Rect2:
	return Rect2(Vector2(cell * CELL_SIZE), Vector2(CELL_SIZE, CELL_SIZE))


## The pixel position of a cell's centre, relative to the board.
static func cell_center(cell: Vector2i) -> Vector2:
	return cell_rect(cell).get_center()


static func is_inside(cell: Vector2i) -> bool:
	return Rect2i(Vector2i.ZERO, GRID_SIZE).has_point(cell)


## Brings a cell that left the board back in on the opposite side.
static func wrap(cell: Vector2i) -> Vector2i:
	return Vector2i(posmod(cell.x, GRID_SIZE.x), posmod(cell.y, GRID_SIZE.y))


## Every cell on the board that isn't in `taken`.
static func free_cells(taken: Array[Vector2i]) -> Array[Vector2i]:
	var cells: Array[Vector2i] = []
	for x in GRID_SIZE.x:
		for y in GRID_SIZE.y:
			var cell := Vector2i(x, y)
			if not taken.has(cell):
				cells.append(cell)
	return cells
