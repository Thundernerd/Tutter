extends CanvasLayer

@onready var score_label: Label = %ScoreLabel
@onready var best_label: Label = %BestLabel


func update_score(score: int) -> void:
	score_label.text = "Score: %d" % score
	best_label.text = "Best: %d" % maxi(score, HighScore.best)
	if score > 0:
		_pulse(score_label)


## Briefly enlarge a label, then shrink it back.
func _pulse(label: Label) -> void:
	label.scale = Vector2(1.4, 1.4)
	create_tween().tween_property(label, "scale", Vector2.ONE, 0.2)
