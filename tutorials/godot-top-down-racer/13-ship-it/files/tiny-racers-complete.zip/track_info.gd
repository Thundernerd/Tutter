class_name TrackInfo
extends Resource
## Everything the menus need to know about a track, without loading it.

## Used as the key for lap records, so don't change it once players have records.
@export var id := ""
@export var title := ""
@export_multiline var description := ""
@export var scene: PackedScene
