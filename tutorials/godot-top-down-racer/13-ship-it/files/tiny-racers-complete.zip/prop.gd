@tool
class_name Prop
extends StaticBody2D
## A solid object on the table: a mug, a book, a pool ball. It draws itself to match
## its CollisionShape2D, which can be a circle or a rectangle.

@export var color := Color("f4f1ea"):
	set(value):
		color = value
		queue_redraw()
## Optional second colour drawn inside the shape, like the coffee in a mug.
@export var inner_color := Color.TRANSPARENT:
	set(value):
		inner_color = value
		queue_redraw()
## Extra speed (px/s) pushed into cars that hit it. Bumpers use this.
@export var bounce := 0.0

@onready var collision: CollisionShape2D = $CollisionShape2D


func _ready() -> void:
	if collision.shape:
		collision.shape.changed.connect(queue_redraw)


func _draw() -> void:
	draw_set_transform_matrix(collision.transform)
	var shape := collision.shape
	if shape is CircleShape2D:
		var r: float = shape.radius
		draw_circle(Vector2(3, 3), r, Color(0, 0, 0, 0.25)) # shadow
		draw_circle(Vector2.ZERO, r, color)
		if inner_color.a > 0.0:
			draw_circle(Vector2.ZERO, r * 0.72, inner_color)
		draw_arc(Vector2.ZERO, r, 0.0, TAU, 48, color.darkened(0.3), 2.0)
	elif shape is RectangleShape2D:
		var rect := Rect2(-shape.size / 2.0, shape.size)
		draw_rect(Rect2(rect.position + Vector2(3, 3), rect.size), Color(0, 0, 0, 0.25))
		draw_rect(rect, color)
		if inner_color.a > 0.0:
			draw_rect(rect.grow(-4.0), inner_color)
		draw_rect(rect, color.darkened(0.3), false, 2.0)
