extends Control

const CAR_SCENE := preload("res://car.tscn")
const DEMO_COLORS: Array[Color] = [Color("e23b3b"), Color("3b7be2"), Color("f2c230"), Color("9b59d0")]

@onready var play_button: Button = %PlayButton
@onready var quit_button: Button = %QuitButton
@onready var backdrop: CanvasLayer = $Backdrop


func _ready() -> void:
	# Browsers can't close the tab for us, so hide Quit in web builds.
	quit_button.visible = not OS.has_feature("web")
	play_button.grab_focus()
	_start_demo_race()


## A few CPU cars lapping the first track behind the menu.
func _start_demo_race() -> void:
	var track: Track = Session.TRACKS[0].scene.instantiate()
	backdrop.add_child(track)
	for slot in DEMO_COLORS.size():
		var car: Car = CAR_SCENE.instantiate()
		car.input_prefix = ""
		car.color = DEMO_COLORS[slot]
		car.track = track
		car.transform = track.grid_transform(slot)
		car.ai = AIDriver.new(car, track, 0.8)
		backdrop.add_child(car)


func _on_play_button_pressed() -> void:
	get_tree().change_scene_to_file("res://mode_select.tscn")


func _on_options_button_pressed() -> void:
	get_tree().change_scene_to_file("res://options_menu.tscn")


func _on_quit_button_pressed() -> void:
	get_tree().quit()
