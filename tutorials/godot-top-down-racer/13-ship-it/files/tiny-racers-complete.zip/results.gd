class_name Results
extends CanvasLayer
## The end screen: race results, championship standings, or a head-to-head winner.

@onready var title: Label = %Title
@onready var subtitle: Label = %Subtitle
@onready var table: GridContainer = %Table
@onready var next_button: Button = %NextButton
@onready var again_button: Button = %AgainButton
@onready var menu_button: Button = %MenuButton


func _ready() -> void:
	hide()


func show_race(order: Array[Car]) -> void:
	var championship := Session.mode == Session.Mode.CHAMPIONSHIP
	title.text = "Race results"
	subtitle.text = Session.track().title
	var headers := ["", "Driver", "Time", "Best lap"]
	if championship:
		subtitle.text += "  ·  race %d of %d" % [Session.track_index + 1, Session.TRACKS.size()]
		headers.append("Points")
	_start_table(headers)
	for i in order.size():
		var car := order[i]
		var time := Format.time(car.finish_time) if car.finished else "-"
		var row := [Format.ordinal(i + 1), car.driver_name, time, Format.time(car.best_lap)]
		if championship:
			row.append(str(Session.standings[car.driver_name]))
		_add_row(row, car.color)
	next_button.visible = championship
	next_button.text = "Final standings" if Session.is_last_race() else "Next race"
	again_button.visible = not championship
	again_button.text = "Race again"
	_open(next_button if championship else again_button)


func show_standings() -> void:
	var drivers := Session.standings_order()
	title.text = "%s wins the championship!" % drivers[0]
	subtitle.text = "Final standings"
	_start_table(["", "Driver", "Points"])
	for i in drivers.size():
		var driver: String = drivers[i]
		_add_row([Format.ordinal(i + 1), driver, str(Session.standings[driver])], Session.driver_colors[driver])
	next_button.hide()
	again_button.hide()
	_open(menu_button)


func show_match_winner(winner: Car) -> void:
	title.text = "%s wins the match!" % winner.driver_name
	subtitle.text = "Head-to-head  ·  " + Session.track().title
	_start_table([])
	next_button.hide()
	again_button.show()
	again_button.text = "Rematch"
	_open(again_button)


func _open(focus_button: Button) -> void:
	show()
	focus_button.grab_focus()


func _start_table(headers: Array) -> void:
	for child in table.get_children():
		table.remove_child(child) # Gone right away, not at the end of the frame.
		child.queue_free()
	table.visible = not headers.is_empty()
	table.columns = maxi(headers.size(), 1)
	for header in headers:
		var label := _add_cell(header)
		label.modulate = Color(1, 1, 1, 0.6)


func _add_row(cells: Array, color: Color) -> void:
	for i in cells.size():
		var label := _add_cell(cells[i])
		if i == 1:
			label.add_theme_color_override("font_color", color.lightened(0.2))


func _add_cell(text: String) -> Label:
	var label := Label.new()
	label.text = text
	table.add_child(label)
	return label


func _on_next_button_pressed() -> void:
	if Session.is_last_race():
		show_standings()
	else:
		Session.next_race()
		get_tree().reload_current_scene()


func _on_again_button_pressed() -> void:
	get_tree().reload_current_scene()


func _on_menu_button_pressed() -> void:
	get_tree().change_scene_to_file("res://main_menu.tscn")
