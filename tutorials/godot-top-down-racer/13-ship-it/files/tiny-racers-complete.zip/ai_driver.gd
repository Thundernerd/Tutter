class_name AIDriver
extends RefCounted
## Drives a Car by steering at a point on the track's centre line a little way ahead.

## How far ahead (px) to aim, plus extra per px/s of speed: faster means looking further.
const LOOK_AHEAD := 40.0
const LOOK_AHEAD_PER_SPEED := 0.25
## How far ahead to check for bends, plus extra per px/s of speed.
const BRAKE_LOOK_AHEAD := 60.0
const BRAKE_LOOK_AHEAD_PER_SPEED := 0.5
## Steering per radian of angle to the target. Higher is twitchier.
const STEER_GAIN := 3.0
## Speed through the sharpest bends, as a fraction of top speed.
const CORNER_SPEED := 0.45
## A bend this sharp (radians between the two directions) gets the full slowdown.
const SHARP_BEND := 1.4
## Cars closer than this, in front of us, make us steer around them.
const AVOID_DISTANCE := 50.0

var car: Car
var track: Track
## Fraction of the car's top speed this driver aims for.
var skill := 0.9

var _wander_phase := randf() * TAU
var _wander_speed := randf_range(0.3, 0.7)
var _stuck_time := 0.0
var _reverse_time := 0.0


func _init(driven_car: Car, race_track: Track, driver_skill: float) -> void:
	car = driven_car
	track = race_track
	# A little randomness, so CPU cars don't drive as one perfect train.
	skill = driver_skill * randf_range(0.97, 1.03)


func update(delta: float) -> void:
	if _reverse_time > 0.0:
		_reverse(delta)
		return

	var speed := car.velocity.length()
	var offset := track.offset_at(car.global_position)

	# Steer towards a point ahead on the road, shifted sideways a little.
	_wander_phase += _wander_speed * delta
	var lane := sin(_wander_phase) * track.road_width * 0.2 + _avoidance()
	var aim := track.transform_at(offset + LOOK_AHEAD + speed * LOOK_AHEAD_PER_SPEED)
	var target := aim.origin + aim.y * lane
	var angle := car.to_local(target).angle()
	car.steer = clampf(angle * STEER_GAIN, -1.0, 1.0)

	# Slow down for bends: compare the road's direction here and further ahead.
	var here := track.transform_at(offset).x
	var ahead := track.transform_at(offset + BRAKE_LOOK_AHEAD + speed * BRAKE_LOOK_AHEAD_PER_SPEED).x
	var bend := clampf(absf(here.angle_to(ahead)) / SHARP_BEND, 0.0, 1.0)
	var target_speed := car.max_speed * skill * lerpf(1.0, CORNER_SPEED, bend)
	if car.forward_speed > target_speed + 20.0:
		car.throttle = -1.0
	elif car.forward_speed < target_speed:
		car.throttle = 1.0
	else:
		car.throttle = 0.0

	_check_stuck(delta, speed)


## Sideways nudge (px) away from cars just in front of us.
func _avoidance() -> float:
	var nudge := 0.0
	for other in car.get_tree().get_nodes_in_group(&"cars"):
		if other == car:
			continue
		var local := car.to_local(other.global_position) # x: ahead of us, y: to our right
		if local.x > 0.0 and local.x < AVOID_DISTANCE and absf(local.y) < 20.0:
			# The closer the car, the harder we move to the side it isn't on.
			var away := -1.0 if local.y >= 0.0 else 1.0
			nudge += away * (1.0 - local.x / AVOID_DISTANCE) * track.road_width * 0.4
	return nudge


## Pressing the throttle but not moving means we're against a wall: back off.
func _check_stuck(delta: float, speed: float) -> void:
	if car.throttle > 0.0 and speed < 15.0:
		_stuck_time += delta
	else:
		_stuck_time = 0.0
	if _stuck_time > 0.8:
		_stuck_time = 0.0
		_reverse_time = 0.8


func _reverse(delta: float) -> void:
	_reverse_time -= delta
	var offset := track.offset_at(car.global_position)
	var target := track.transform_at(offset + LOOK_AHEAD).origin
	# Reversing flips steering, so steer the "wrong" way to swing the nose round.
	car.steer = -clampf(car.to_local(target).angle() * STEER_GAIN, -1.0, 1.0)
	car.throttle = -1.0
