class_name RaceCamera
extends Camera2D
## One shared camera for everybody. It follows `focus`, looks ahead in the direction
## of travel, and zooms out to keep every car in `keep_in_view` on screen.

## The car to follow.
var focus: Car
## Cars that must stay visible. Leave empty to keep a fixed zoom (head-to-head).
var keep_in_view: Array[Car] = []

## Seconds of the focus car's velocity to look ahead.
@export var look_ahead := 0.35
## Higher values follow more tightly.
@export var follow_speed := 4.0
@export var zoom_speed := 2.0
## The furthest the camera zooms out (0.5 shows twice as much in each direction).
@export var min_zoom := 0.5
## Screen space (px) kept free around the cars when zooming out to fit them.
@export var margin := Vector2(120, 90)

var _shake := 0.0


func _ready() -> void:
	# Move in step with the physics bodies we follow, which avoids jitter.
	process_callback = Camera2D.CAMERA2D_PROCESS_PHYSICS


## Stop the camera from leaving the table (plus a little border).
func set_bounds(rect: Rect2) -> void:
	limit_left = int(rect.position.x)
	limit_top = int(rect.position.y)
	limit_right = int(rect.end.x)
	limit_bottom = int(rect.end.y)


func _physics_process(delta: float) -> void:
	if focus == null:
		return
	var target := _target_position()
	var weight := 1.0 - exp(-follow_speed * delta)
	global_position = global_position.lerp(target, weight)
	var zoom_weight := 1.0 - exp(-zoom_speed * delta)
	zoom = zoom.lerp(Vector2.ONE * _target_zoom(), zoom_weight)

	_shake = move_toward(_shake, 0.0, 30.0 * delta)
	offset = Vector2(randf_range(-1, 1), randf_range(-1, 1)) * _shake


func _target_position() -> Vector2:
	var target := focus.global_position + focus.velocity * look_ahead
	if keep_in_view.size() > 1:
		target = _cars_rect().get_center()
	return target


func _target_zoom() -> float:
	if keep_in_view.size() < 2:
		return 1.0
	var rect := _cars_rect()
	var room := get_viewport_rect().size - margin * 2.0
	var fit := minf(room.x / maxf(rect.size.x, 1.0), room.y / maxf(rect.size.y, 1.0))
	return clampf(fit, min_zoom, 1.0)


## The smallest rectangle containing every car we must keep in view.
func _cars_rect() -> Rect2:
	var rect := Rect2(keep_in_view[0].global_position, Vector2.ZERO)
	for car in keep_in_view:
		rect = rect.expand(car.global_position)
	return rect


## Jump straight to the target, skipping the smooth follow.
func snap() -> void:
	if focus:
		global_position = _target_position()
		zoom = Vector2.ONE * _target_zoom()
	reset_smoothing()


func shake(amount: float) -> void:
	_shake = maxf(_shake, amount)


## The part of the world currently on screen.
func visible_rect() -> Rect2:
	var size := get_viewport_rect().size / zoom
	return Rect2(get_screen_center_position() - size / 2.0, size)
