@tool
class_name Surface
extends Area2D
## A patch of the table that changes how cars handle: spilled juice, a napkin...
## Draws itself to match its CollisionShape2D (circle or rectangle).

@export var color := Color(1.0, 0.7, 0.2, 0.55):
	set(value):
		color = value
		queue_redraw()
## Multiplies the car's grip. Below 1 is slippery.
@export var grip := 0.25
## Multiplies the car's top speed. Below 1 is sticky.
@export var top_speed := 1.0

@onready var collision: CollisionShape2D = $CollisionShape2D


func _ready() -> void:
	if collision.shape:
		collision.shape.changed.connect(queue_redraw)
	if not Engine.is_editor_hint():
		body_entered.connect(_on_body_entered)
		body_exited.connect(_on_body_exited)


func _on_body_entered(body: Node2D) -> void:
	if body is Car:
		body.enter_surface(self)


func _on_body_exited(body: Node2D) -> void:
	if body is Car:
		body.exit_surface(self)


func _draw() -> void:
	draw_set_transform_matrix(collision.transform)
	var shape := collision.shape
	if shape is CircleShape2D:
		# A blobby puddle: one big circle and a few smaller ones around its edge.
		var r: float = shape.radius
		draw_circle(Vector2.ZERO, r, color)
		for i in 5:
			var direction := Vector2.RIGHT.rotated(i * TAU / 5.0 + 0.4)
			draw_circle(direction * r * 0.75, r * 0.4, color)
	elif shape is RectangleShape2D:
		var rect := Rect2(-shape.size / 2.0, shape.size)
		draw_rect(rect, color)
		# Stitching along the edge, so cloth looks like cloth.
		draw_rect(rect.grow(-4.0), color.lightened(0.3), false, 1.0)
