extends Node
## What the players picked in the menus, plus the running championship.
## Registered as the "Session" autoload. Unlike Settings, nothing here is saved.

enum Mode { RACE, CHAMPIONSHIP, HEAD_TO_HEAD }

const TRACKS: Array[TrackInfo] = [
	preload("res://tracks/breakfast.tres"),
	preload("res://tracks/desk.tres"),
	preload("res://tracks/pool.tres"),
]
## Championship points for 1st, 2nd, 3rd and 4th place.
const POINTS: Array[int] = [10, 6, 3, 1]

var mode := Mode.RACE
var players := 1
var track_index := 0
## Championship points per driver name.
var standings := {}
## Car colour per driver name, for the standings table.
var driver_colors := {}


func track() -> TrackInfo:
	return TRACKS[track_index]


func start_championship() -> void:
	mode = Mode.CHAMPIONSHIP
	track_index = 0
	standings.clear()
	driver_colors.clear()


## Give out points for a finished race. `order` is the result, winner first.
func award_points(order: Array[Car]) -> void:
	for place in order.size():
		var driver := order[place].driver_name
		var earned := POINTS[place] if place < POINTS.size() else 0
		standings[driver] = standings.get(driver, 0) + earned
		driver_colors[driver] = order[place].color


## Driver names sorted by championship points, leader first.
func standings_order() -> Array:
	var drivers := standings.keys()
	drivers.sort_custom(func(a, b): return standings[a] > standings[b])
	return drivers


func is_last_race() -> bool:
	return track_index >= TRACKS.size() - 1


func next_race() -> void:
	track_index += 1
