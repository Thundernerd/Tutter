extends Control

const PLAYERS: Array[String] = ["p1", "p2"]
## Action name without the player prefix, and the label shown for it.
const CONTROLS := {
	"accelerate": "Accelerate",
	"brake": "Brake / reverse",
	"left": "Steer left",
	"right": "Steer right",
}

## The action waiting for a new key, or &"" when not rebinding.
var _rebinding := &""
var _rebind_button: Button

@onready var master_slider: HSlider = %MasterSlider
@onready var sfx_slider: HSlider = %SfxSlider
@onready var fullscreen_check: CheckButton = %FullscreenCheck
@onready var laps_spin: SpinBox = %LapsSpin
@onready var difficulty_option: OptionButton = %DifficultyOption
@onready var clear_records_button: Button = %ClearRecordsButton
@onready var controls_grid: GridContainer = %ControlsGrid


func _ready() -> void:
	# The *_no_signal setters avoid triggering our change handlers (and the test sound).
	master_slider.set_value_no_signal(Settings.master_volume)
	sfx_slider.set_value_no_signal(Settings.sfx_volume)
	fullscreen_check.set_pressed_no_signal(Settings.fullscreen)
	laps_spin.set_value_no_signal(Settings.laps)
	difficulty_option.selected = Settings.cpu_difficulty
	clear_records_button.disabled = Settings.best_laps.is_empty()
	_build_controls()
	master_slider.grab_focus()


func _build_controls() -> void:
	for header in ["", "P1", "P2"]:
		var label := Label.new()
		label.text = header
		label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		controls_grid.add_child(label)
	for control in CONTROLS:
		var label := Label.new()
		label.text = CONTROLS[control]
		controls_grid.add_child(label)
		for player in PLAYERS:
			var action := StringName(player + "_" + control)
			var button := Button.new()
			button.text = Settings.key_name(action)
			button.custom_minimum_size.x = 84
			button.pressed.connect(_start_rebind.bind(action, button))
			controls_grid.add_child(button)


func _start_rebind(action: StringName, button: Button) -> void:
	_rebinding = action
	_rebind_button = button
	button.text = "Press a key…"


func _input(event: InputEvent) -> void:
	if _rebinding == &"" or not (event is InputEventKey and event.pressed and not event.echo):
		return
	get_viewport().set_input_as_handled()
	if event.physical_keycode != KEY_ESCAPE: # Escape cancels.
		Settings.set_key(_rebinding, event.physical_keycode)
	_rebind_button.text = Settings.key_name(_rebinding)
	_rebinding = &""


func _on_master_slider_value_changed(value: float) -> void:
	Settings.master_volume = value
	Settings.apply()


func _on_sfx_slider_value_changed(value: float) -> void:
	Settings.sfx_volume = value
	Settings.apply()
	$TestSound.play() # Let the player hear the new volume.


func _on_fullscreen_check_toggled(toggled_on: bool) -> void:
	Settings.fullscreen = toggled_on
	Settings.apply()


func _on_laps_spin_value_changed(value: float) -> void:
	Settings.laps = int(value)


func _on_difficulty_option_item_selected(index: int) -> void:
	Settings.cpu_difficulty = index


func _on_clear_records_button_pressed() -> void:
	Settings.clear_records()
	clear_records_button.text = "Records cleared"
	clear_records_button.disabled = true


func _on_back_button_pressed() -> void:
	Settings.save_settings()
	get_tree().change_scene_to_file("res://main_menu.tscn")
