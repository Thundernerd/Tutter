@tool
class_name Ramp
extends Area2D
## A ruler propped up on an eraser. Cars that hit it fast enough take off.
## Lay it across the road with its x axis pointing in the racing direction.

@export var air_time := 0.6
## Cars slower than this (px/s) just roll over it.
@export var min_speed := 120.0

@onready var collision: CollisionShape2D = $CollisionShape2D


func _ready() -> void:
	if collision.shape:
		collision.shape.changed.connect(queue_redraw)
	if not Engine.is_editor_hint():
		body_entered.connect(_on_body_entered)


func _on_body_entered(body: Node2D) -> void:
	if body is Car and body.forward_speed > min_speed:
		body.jump(air_time)


func _draw() -> void:
	var shape := collision.shape as RectangleShape2D
	if shape == null:
		return
	draw_set_transform_matrix(collision.transform)
	var rect := Rect2(-shape.size / 2.0, shape.size)
	draw_rect(Rect2(rect.position + Vector2(4, 4), rect.size), Color(0, 0, 0, 0.3))
	draw_rect(rect, Color("e8d9a8"))
	# The raised far edge (cars drive along +x) is darker, so it reads as a slope.
	draw_rect(Rect2(rect.end.x - 6.0, rect.position.y, 6.0, rect.size.y), Color("c9b47a"))
	# Ruler markings every 5 px along the long side, longer every fifth one.
	var y := rect.position.y + 3.0
	var i := 0
	while y < rect.end.y:
		var mark := 10.0 if i % 5 == 0 else 5.0
		draw_line(Vector2(rect.position.x, y), Vector2(rect.position.x + mark, y), Color("6b5a3a"), 1.0)
		y += 5.0
		i += 1
	draw_rect(rect, Color("6b5a3a"), false, 1.0)
