class_name Format
## Helpers that turn race numbers into text.


## 83.456 seconds becomes "1:23.46".
static func time(seconds: float) -> String:
	if is_inf(seconds):
		return "-:--.--"
	var minutes := floori(seconds / 60.0)
	return "%d:%05.2f" % [minutes, seconds - minutes * 60.0]


## 1 becomes "1st", 2 becomes "2nd", and so on.
static func ordinal(place: int) -> String:
	match place:
		1:
			return "1st"
		2:
			return "2nd"
		3:
			return "3rd"
	return "%dth" % place
