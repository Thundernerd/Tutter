class_name Car
extends CharacterBody2D
## A top-down arcade car. Players drive it with input actions; CPU cars get an AIDriver.

## Emitted when the car hits something hard. `strength` is the impact speed in px/s.
signal bumped(strength: float)

const SKID_COLOR := Color(0.1, 0.08, 0.06, 0.35)
## Where the rear wheels are, relative to the car's centre.
const REAR_WHEELS: Array[Vector2] = [Vector2(-7, -6), Vector2(-7, 6)]
## Skid lines kept on the track before the oldest ones are removed.
const MAX_SKID_LINES := 60

@export var driver_name := "P1"
@export var color := Color("e23b3b")
## Prefix of the input actions that drive this car: "p1" reads p1_accelerate and friends.
## Leave empty for CPU cars.
@export var input_prefix := "p1"

@export_group("Engine")
@export var max_speed := 260.0
@export var acceleration := 280.0
@export var braking := 600.0
@export var max_reverse_speed := 100.0
## How quickly the car slows down when you let go of the throttle.
@export var drag := 90.0

@export_group("Handling")
## Turning speed at full lock, in radians per second.
@export var turn_speed := 3.4
## Below this speed steering is weaker: a parked car can't spin on the spot.
@export var full_steer_speed := 90.0
## How quickly sideways sliding dies away. Lower values mean longer drifts.
@export var grip := 9.0
## Sideways speed (px/s) above which the car counts as drifting.
@export var drift_threshold := 45.0

@export_group("Off-road")
## Top speed multiplier off the road.
@export var off_road_speed := 0.45
## Grip multiplier off the road.
@export var off_road_grip := 0.6

## -1 (full brake or reverse) to 1 (full throttle). Set by input or the AI.
var throttle := 0.0
## -1 (left) to 1 (right).
var steer := 0.0
## When false the car ignores its driver, e.g. during the countdown.
var controls_enabled := true
## Drives the car instead of input when set.
var ai: AIDriver
## The track the car is racing on, used for off-road checks and skid marks.
var track: Track

## Speed along the car's nose in px/s. Negative when reversing.
var forward_speed := 0.0
var drifting := false
var off_road := false

# Race bookkeeping, managed by race.gd.
var lap := 1
var next_checkpoint := 1
var lap_start_time := 0.0
var best_lap := INF
var finished := false
var finish_time := 0.0
var progress := 0.0

var _surfaces: Array[Surface] = []
var _air_time := 0.0
var _skid_lines: Array[Line2D] = []

@onready var visuals: Node2D = $Visuals
@onready var shadow: Polygon2D = $Shadow
@onready var tyre_smoke: CPUParticles2D = $TyreSmoke
@onready var engine_sound: AudioStreamPlayer2D = $EngineSound
@onready var skid_sound: AudioStreamPlayer2D = $SkidSound
@onready var bump_sound: AudioStreamPlayer2D = $BumpSound


func _ready() -> void:
	$Visuals/Body.color = color
	bumped.connect(_on_bumped)
	# Only players get engine noise: four engines at once is a lot of buzzing.
	if is_player():
		engine_sound.play()


func is_player() -> bool:
	return input_prefix != ""


func _physics_process(delta: float) -> void:
	if not controls_enabled:
		throttle = 0.0
		steer = 0.0
	elif ai:
		ai.update(delta)
	else:
		_read_input()
	_drive(delta)
	var impact_velocity := velocity
	move_and_slide()
	_handle_collisions(impact_velocity)
	_update_effects()


func _read_input() -> void:
	throttle = Input.get_axis(input_prefix + "_brake", input_prefix + "_accelerate")
	steer = Input.get_axis(input_prefix + "_left", input_prefix + "_right")


func _drive(delta: float) -> void:
	if _air_time > 0.0:
		_air_time -= delta
		return # In the air: no grip, no steering, the car keeps its momentum.

	var surface := _surface_factors()
	var top_speed := max_speed * surface.x

	# 1. Steering rotates the car. It's weak at low speed and flips when reversing.
	var steer_strength := clampf(absf(forward_speed) / full_steer_speed, 0.0, 1.0)
	rotation += steer * turn_speed * steer_strength * signf(forward_speed) * delta

	# 2. Split the velocity along the car's (new) forward and sideways directions.
	var forward := transform.x
	var right := transform.y
	forward_speed = velocity.dot(forward)
	var side_speed := velocity.dot(right)

	# 3. Engine, brakes and drag only change the forward part.
	if throttle > 0.0:
		forward_speed = move_toward(forward_speed, top_speed * throttle, acceleration * delta)
	elif throttle < 0.0 and forward_speed > 0.0:
		forward_speed = move_toward(forward_speed, 0.0, braking * delta)
	elif throttle < 0.0:
		forward_speed = move_toward(forward_speed, -max_reverse_speed * surface.x, acceleration * delta)
	else:
		forward_speed = move_toward(forward_speed, 0.0, drag * delta)
	# Going faster than this surface allows (just ran off the road)? Scrub speed off.
	if absf(forward_speed) > top_speed:
		forward_speed = move_toward(forward_speed, signf(forward_speed) * top_speed, braking * 0.5 * delta)

	# 4. Grip kills the sideways part. Whatever survives is the drift.
	side_speed *= exp(-grip * surface.y * delta)
	drifting = absf(side_speed) > drift_threshold

	velocity = forward * forward_speed + right * side_speed


## How the ground under the car changes it: x multiplies top speed, y multiplies grip.
func _surface_factors() -> Vector2:
	off_road = false
	if not _surfaces.is_empty():
		var surface: Surface = _surfaces.back()
		return Vector2(surface.top_speed, surface.grip)
	if track and track.is_off_road(global_position):
		off_road = true
		return Vector2(off_road_speed, off_road_grip)
	return Vector2.ONE


func _handle_collisions(impact_velocity: Vector2) -> void:
	for i in get_slide_collision_count():
		var collision := get_slide_collision(i)
		var normal := collision.get_normal()
		# How fast we were moving into whatever we hit.
		var impact := -impact_velocity.dot(normal)
		if impact <= 0.0:
			continue
		var other := collision.get_collider()
		if other is Car:
			# Shove the other car; we keep some of the knock ourselves.
			other.velocity -= normal * impact * 0.6
			velocity += normal * impact * 0.15
		else:
			velocity += normal * impact * 0.3 # A small bounce off walls and props.
			if other is Prop:
				velocity += normal * other.bounce
		if impact > 60.0:
			bumped.emit(impact)


## Called by Surface areas when the car drives onto or off them.
func enter_surface(surface: Surface) -> void:
	_surfaces.append(surface)


func exit_surface(surface: Surface) -> void:
	_surfaces.erase(surface)


## Launch the car into the air for `duration` seconds. Called by ramps.
func jump(duration: float) -> void:
	if _air_time > 0.0:
		return
	_air_time = duration
	var tween := create_tween().set_trans(Tween.TRANS_SINE)
	tween.tween_property(visuals, "scale", Vector2(1.4, 1.4), duration / 2).set_ease(Tween.EASE_OUT)
	tween.parallel().tween_property(shadow, "position", Vector2(8, 8), duration / 2)
	tween.tween_property(visuals, "scale", Vector2.ONE, duration / 2).set_ease(Tween.EASE_IN)
	tween.parallel().tween_property(shadow, "position", Vector2(2, 2), duration / 2)


func is_airborne() -> bool:
	return _air_time > 0.0


## Put the car somewhere new, standing still. Used to line cars up between rounds.
func place(new_transform: Transform2D) -> void:
	transform = new_transform
	velocity = Vector2.ZERO
	forward_speed = 0.0
	_air_time = 0.0
	visuals.scale = Vector2.ONE
	shadow.position = Vector2(2, 2)
	_skid_lines.clear()


func _update_effects() -> void:
	var speed := velocity.length()
	var skidding := drifting and not is_airborne()
	tyre_smoke.emitting = skidding or (off_road and speed > 60.0)
	tyre_smoke.color = Color(0.9, 0.9, 0.9, 0.6) if skidding else Color(0.55, 0.42, 0.3, 0.5)
	_update_skid_marks(skidding)
	if is_player():
		engine_sound.pitch_scale = 0.7 + 1.3 * clampf(speed / max_speed, 0.0, 1.2)
		if skidding and not skid_sound.playing:
			skid_sound.play()
		elif not skidding and skid_sound.playing:
			skid_sound.stop()


func _update_skid_marks(skidding: bool) -> void:
	if not skidding or track == null:
		_skid_lines.clear() # The next skid starts fresh lines.
		return
	if _needs_new_skid_lines():
		_skid_lines.clear()
		for i in REAR_WHEELS.size():
			var line := Line2D.new()
			line.width = 2.5
			line.default_color = SKID_COLOR
			track.skid_marks.add_child(line)
			_skid_lines.append(line)
		while track.skid_marks.get_child_count() > MAX_SKID_LINES:
			var oldest := track.skid_marks.get_child(0)
			track.skid_marks.remove_child(oldest)
			oldest.queue_free()
	for i in REAR_WHEELS.size():
		var point := to_global(REAR_WHEELS[i])
		var line := _skid_lines[i]
		if line.get_point_count() == 0 or line.points[-1].distance_to(point) > 4.0:
			line.add_point(point)


func _needs_new_skid_lines() -> bool:
	if _skid_lines.is_empty():
		return true
	for line in _skid_lines:
		# Very long lines are split up, and old lines may have been removed.
		if not is_instance_valid(line) or line.get_point_count() > 100:
			return true
	return false


## A knock sound and a short flash. The race also listens to `bumped` to shake the camera.
func _on_bumped(strength: float) -> void:
	bump_sound.pitch_scale = randf_range(0.8, 1.2)
	bump_sound.volume_db = linear_to_db(clampf(strength / 200.0, 0.3, 1.0))
	bump_sound.play()
	visuals.modulate = Color(1.8, 1.8, 1.8)
	create_tween().tween_property(visuals, "modulate", Color.WHITE, 0.15)
