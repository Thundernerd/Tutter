extends Node2D
## Runs one race, or one head-to-head match, on the track picked in Session.

enum State { COUNTDOWN, RACING, ROUND_OVER, FINISHED }

const CAR_SCENE := preload("res://car.tscn")
const PLAYER_COLORS: Array[Color] = [Color("e23b3b"), Color("3b7be2")]
const CPU_NAMES: Array[String] = ["Rusty", "Zippy", "Bolt"]
const CPU_COLORS: Array[Color] = [Color("f2c230"), Color("9b59d0"), Color("f08a24")]
## Cars in a race, players included.
const RACE_CARS := 4
## Head-to-head: both cars start with this many points. Take all of them to win.
const START_POINTS := 4

var track: Track
var cars: Array[Car] = []
var players: Array[Car] = []
## Every car in race order, leader first. Updated every physics frame.
var standings: Array[Car] = []
var finish_order: Array[Car] = []
var state := State.COUNTDOWN
var race_time := 0.0
var head_to_head := false
## Head-to-head points, one entry per car.
var points: Array[int] = []

var _count := 0

@onready var cars_node: Node2D = $Cars
@onready var camera: RaceCamera = %RaceCamera
@onready var hud: HUD = $HUD
@onready var results: Results = $Results
@onready var pause_menu: CanvasLayer = $PauseMenu
@onready var countdown_timer: Timer = $CountdownTimer
@onready var round_timer: Timer = $RoundTimer
@onready var end_timer: Timer = $EndTimer


func _ready() -> void:
	head_to_head = Session.mode == Session.Mode.HEAD_TO_HEAD
	track = Session.track().scene.instantiate()
	add_child(track)
	move_child(track, 0) # Draw the track below the cars.
	track.checkpoint_entered.connect(_on_checkpoint_entered)
	_spawn_cars()
	_update_standings()

	camera.set_bounds(Rect2(Vector2.ZERO, track.table_size).grow(40))
	camera.focus = players[0]
	if not head_to_head:
		camera.keep_in_view = players # Zoom out so every player stays on screen.
	camera.snap()

	hud.setup(players, Settings.laps, head_to_head)
	if head_to_head:
		points = [START_POINTS, START_POINTS]
		hud.update_points(cars, points)
	_start_countdown()


func _spawn_cars() -> void:
	var cpu_count := (2 if head_to_head else RACE_CARS) - Session.players
	# CPU cars line up at the front of the grid, players behind them.
	for slot in cpu_count + Session.players:
		var car: Car = CAR_SCENE.instantiate()
		if slot < cpu_count:
			car.driver_name = CPU_NAMES[slot]
			car.color = CPU_COLORS[slot]
			car.input_prefix = ""
			car.ai = AIDriver.new(car, track, Settings.cpu_skill())
		else:
			var player := slot - cpu_count
			car.driver_name = "P%d" % (player + 1)
			car.color = PLAYER_COLORS[player]
			car.input_prefix = "p%d" % (player + 1)
			car.bumped.connect(_on_player_bumped)
			players.append(car)
		car.track = track
		car.transform = track.grid_transform(slot)
		car.controls_enabled = false
		cars_node.add_child(car)
		cars.append(car)


func _physics_process(delta: float) -> void:
	if state == State.RACING or state == State.FINISHED:
		race_time += delta
	_update_standings()
	camera.focus = _camera_focus()
	if head_to_head and state == State.RACING:
		_check_off_screen()
	hud.update_race(race_time, standings)


func _update_standings() -> void:
	for car in cars:
		car.progress = _progress(car)
	standings = cars.duplicate()
	standings.sort_custom(_is_ahead)


## How far a car has driven in total: completed laps plus distance into this lap.
func _progress(car: Car) -> float:
	var offset := track.offset_at(car.global_position)
	# Just behind the start line, the closest point is near the *end* of the curve.
	if car.next_checkpoint == 1 and offset > track.length / 2.0:
		offset -= track.length
	# Past the last checkpoint but over the line already, the offset restarted at 0.
	elif car.next_checkpoint == 0 and offset < track.length / 2.0:
		offset += track.length
	return (car.lap - 1) * track.length + offset


## Sort order for standings: finished cars by finishing order, then by progress.
func _is_ahead(a: Car, b: Car) -> bool:
	if a.finished and b.finished:
		return finish_order.find(a) < finish_order.find(b)
	if a.finished != b.finished:
		return a.finished
	return a.progress > b.progress


## Head-to-head follows the leader. A race follows the leading player.
func _camera_focus() -> Car:
	for car in standings:
		if head_to_head or car in players:
			return car
	return players[0]


func _start_countdown() -> void:
	state = State.COUNTDOWN
	_count = 3
	hud.show_message(str(_count), 0.8)
	$Sounds/Beep.play()
	countdown_timer.start()


func _on_countdown_timer_timeout() -> void:
	_count -= 1
	if _count > 0:
		hud.show_message(str(_count), 0.8)
		$Sounds/Beep.play()
		return
	countdown_timer.stop()
	hud.show_message("GO!", 0.8)
	$Sounds/Go.play()
	state = State.RACING
	for car in cars:
		car.controls_enabled = true


func _on_checkpoint_entered(car: Car, index: int) -> void:
	if state == State.COUNTDOWN or state == State.ROUND_OVER or car.finished:
		return
	if index != car.next_checkpoint:
		return # Skipped part of the track (or going backwards): doesn't count.
	car.next_checkpoint = (index + 1) % track.checkpoint_count
	if index == 0:
		_complete_lap(car)


func _complete_lap(car: Car) -> void:
	var lap_time := race_time - car.lap_start_time
	car.lap_start_time = race_time
	car.best_lap = minf(car.best_lap, lap_time)
	car.lap += 1
	if car.is_player():
		$Sounds/Lap.play()
		if Settings.submit_lap(Session.track().id, lap_time):
			hud.show_message("Lap record!", 1.5)
	if not head_to_head and car.lap > Settings.laps:
		_finish(car)


func _finish(car: Car) -> void:
	car.finished = true
	car.finish_time = race_time
	finish_order.append(car)
	if not car.is_player():
		return
	$Sounds/Finish.play()
	hud.show_message("%s finished %s!" % [car.driver_name, Format.ordinal(finish_order.size())], 2.0)
	# Let the car cruise on by itself after the flag.
	car.ai = AIDriver.new(car, track, 0.6)
	if players.all(func(p: Car) -> bool: return p.finished):
		state = State.FINISHED
		end_timer.start()


func _on_end_timer_timeout() -> void:
	pause_menu.set_process_unhandled_input(false)
	if head_to_head:
		results.show_match_winner(standings[0])
		return
	if Session.mode == Session.Mode.CHAMPIONSHIP:
		Session.award_points(standings)
	results.show_race(standings)


## Head-to-head: whoever falls off the leader's screen loses the round.
func _check_off_screen() -> void:
	var view := camera.visible_rect().grow(12.0)
	var leader := standings[0]
	for car in cars:
		if car != leader and not view.has_point(car.global_position):
			_end_round(leader)
			return


func _end_round(winner: Car) -> void:
	state = State.ROUND_OVER
	var w := cars.find(winner)
	points[w] += 1
	points[1 - w] -= 1
	hud.update_points(cars, points)
	for car in cars:
		car.controls_enabled = false
	if points[w] == START_POINTS * 2:
		state = State.FINISHED
		hud.show_message("%s wins!" % winner.driver_name, 2.0)
		$Sounds/Finish.play()
		end_timer.start()
	else:
		hud.show_message("%s takes the point" % winner.driver_name, 2.0)
		$Sounds/Lap.play()
		round_timer.start()


## Line both cars up again where the leader was, and count down.
func _on_round_timer_timeout() -> void:
	var leader := standings[0]
	var offset := track.offset_at(leader.global_position)
	for i in cars.size():
		var start := track.transform_at(offset)
		var side := -1.0 if i == 0 else 1.0
		start.origin += start.y * side * track.road_width * 0.22
		cars[i].place(start)
		cars[i].lap = leader.lap
		cars[i].next_checkpoint = leader.next_checkpoint
	camera.snap()
	_start_countdown()


func _on_player_bumped(strength: float) -> void:
	camera.shake(minf(strength / 40.0, 6.0))
