class_name HUD
extends CanvasLayer
## Lap, position and time read-outs, the head-to-head lights, and big messages.

var _players: Array[Car] = []
var _laps := 0
var _lights: Array[ColorRect] = []

@onready var panels: Array[VBoxContainer] = [%P1Panel, %P2Panel]
@onready var time_label: Label = %TimeLabel
@onready var lights: HBoxContainer = %Lights
@onready var message: Label = %Message
@onready var message_timer: Timer = $MessageTimer


func _ready() -> void:
	message.hide()


## One panel per player. Head-to-head shows the points lights instead of laps and time.
func setup(players: Array[Car], laps: int, head_to_head: bool) -> void:
	_players = players
	_laps = laps
	for i in panels.size():
		panels[i].visible = i < players.size() and not head_to_head
	time_label.visible = not head_to_head
	lights.visible = head_to_head


func update_race(race_time: float, standings: Array[Car]) -> void:
	time_label.text = Format.time(race_time)
	for i in _players.size():
		var car := _players[i]
		var panel := panels[i]
		var place := Format.ordinal(standings.find(car) + 1)
		panel.get_node("Position").text = "%s  %s" % [car.driver_name, place]
		if car.finished:
			panel.get_node("Lap").text = "Finished"
		else:
			panel.get_node("Lap").text = "Lap %d/%d" % [car.lap, _laps]
		panel.get_node("Best").text = "Best " + Format.time(car.best_lap)


## Head-to-head: show `points[i]` lights in the colour of `cars[i]`.
func update_points(cars: Array[Car], points: Array[int]) -> void:
	if _lights.is_empty():
		for i in points[0] + points[1]:
			var light := ColorRect.new()
			light.custom_minimum_size = Vector2(16, 16)
			lights.add_child(light)
			_lights.append(light)
	for i in _lights.size():
		_lights[i].color = cars[0].color if i < points[0] else cars[1].color


func show_message(text: String, duration := 1.5) -> void:
	message.text = text
	message.show()
	message_timer.start(duration)


func _on_message_timer_timeout() -> void:
	message.hide()
