@tool
class_name Track
extends Node2D
## A race track built around a closed Path2D centre line.
## Draws the tabletop, road, kerbs and finish line. Keep the Track and its Path
## at (0, 0): the curve's coordinates are then world coordinates.

signal checkpoint_entered(car: Car, index: int)

@export var table_size := Vector2(1200, 700):
	set(value):
		table_size = value
		queue_redraw()
@export var table_color := Color("d9b98c"):
	set(value):
		table_color = value
		queue_redraw()
## Distance between the plank lines on the table. 0 draws none (good for felt).
@export var plank_spacing := 90.0:
	set(value):
		plank_spacing = value
		queue_redraw()
@export var road_width := 60.0
@export var kerb_width := 6.0
@export var road_color := Color("4a4e57")
@export var kerb_color := Color("d23c3c")
@export var checkpoint_count := 8

var curve: Curve2D
var length := 0.0
## Skid marks are added here, above the road but below cars and props.
var skid_marks: Node2D

var _road_nodes: Array[Node] = []

@onready var path: Path2D = $Path


func _ready() -> void:
	curve = path.curve
	length = curve.get_baked_length()
	_build_road()
	if Engine.is_editor_hint():
		# Redraw while the curve is edited, so the editor shows the real road.
		curve.changed.connect(_build_road)
		return
	_build_checkpoints()
	_build_table_edges()


func _draw() -> void:
	var table := Rect2(Vector2.ZERO, table_size)
	draw_rect(table.grow(12), table_color.darkened(0.45)) # The table's edge.
	draw_rect(table, table_color)
	if plank_spacing > 0.0:
		var y := plank_spacing
		while y < table_size.y:
			draw_line(Vector2(0, y), Vector2(table_size.x, y), table_color.darkened(0.1), 2.0)
			y += plank_spacing


func _build_road() -> void:
	for node in _road_nodes:
		node.queue_free()
	_road_nodes.clear()
	length = curve.get_baked_length()
	var points := curve.get_baked_points()
	if points.size() < 3:
		return
	points.remove_at(points.size() - 1) # Same as the first point; `closed` joins them.

	var kerb := _add_line(points, road_width + kerb_width * 2.0, Color.WHITE)
	kerb.texture = _stripe_texture(kerb.width)
	kerb.texture_mode = Line2D.LINE_TEXTURE_TILE
	_add_line(points, road_width, road_color)

	# A chequered line across the road at offset 0.
	var start := transform_at(0.0)
	var half := start.y * (road_width / 2.0)
	var finish := _add_line(PackedVector2Array([start.origin - half, start.origin + half]), 8.0, Color.WHITE)
	finish.closed = false
	finish.texture = _checker_texture()
	finish.texture_mode = Line2D.LINE_TEXTURE_TILE

	if not Engine.is_editor_hint():
		skid_marks = Node2D.new()
		skid_marks.name = "SkidMarks"
		add_child(skid_marks)
		move_child(skid_marks, _road_nodes.size())


func _add_line(points: PackedVector2Array, width: float, color: Color) -> Line2D:
	var line := Line2D.new()
	line.points = points
	line.closed = true
	line.width = width
	line.default_color = color
	line.joint_mode = Line2D.LINE_JOINT_ROUND
	line.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	line.texture_repeat = CanvasItem.TEXTURE_REPEAT_ENABLED
	add_child(line)
	# Children drawn first appear underneath: keep the road below props and surfaces.
	move_child(line, _road_nodes.size())
	_road_nodes.append(line)
	return line


## Alternating kerb stripes. In tile mode a texture is stretched to the line's
## width, so the image height decides how long each stripe is.
func _stripe_texture(width: float) -> ImageTexture:
	var image := Image.create(2, maxi(1, roundi(width / 12.0)), false, Image.FORMAT_RGBA8)
	image.fill(Color.WHITE)
	for y in image.get_height():
		image.set_pixel(0, y, kerb_color)
	return ImageTexture.create_from_image(image)


func _checker_texture() -> ImageTexture:
	var image := Image.create(2, 2, false, Image.FORMAT_RGBA8)
	image.fill(Color.WHITE)
	image.set_pixel(0, 0, Color.BLACK)
	image.set_pixel(1, 1, Color.BLACK)
	return ImageTexture.create_from_image(image)


func _build_checkpoints() -> void:
	for i in checkpoint_count:
		var shape := RectangleShape2D.new()
		# Thin along the road, and wider than the road so cutting a corner still counts.
		shape.size = Vector2(16, road_width + kerb_width * 2.0 + 40.0)
		var collision := CollisionShape2D.new()
		collision.shape = shape
		var area := Area2D.new()
		area.name = "Checkpoint%d" % i
		area.collision_layer = 0
		area.collision_mask = 0
		area.set_collision_layer_value(3, true) # checkpoints
		area.set_collision_mask_value(2, true) # cars
		area.monitorable = false
		area.transform = transform_at(length * i / checkpoint_count)
		area.add_child(collision)
		area.body_entered.connect(_on_checkpoint_body_entered.bind(i))
		add_child(area)


func _on_checkpoint_body_entered(body: Node2D, index: int) -> void:
	if body is Car:
		checkpoint_entered.emit(body, index)


## Invisible walls just outside the table, so nobody drives off the edge.
func _build_table_edges() -> void:
	var edges := StaticBody2D.new()
	edges.name = "TableEdges"
	edges.collision_mask = 0
	var thickness := 100.0
	var rects: Array[Rect2] = [
		Rect2(-thickness, -thickness, table_size.x + thickness * 2.0, thickness), # top
		Rect2(-thickness, table_size.y, table_size.x + thickness * 2.0, thickness), # bottom
		Rect2(-thickness, 0, thickness, table_size.y), # left
		Rect2(table_size.x, 0, thickness, table_size.y), # right
	]
	for rect in rects:
		var shape := RectangleShape2D.new()
		shape.size = rect.size
		var collision := CollisionShape2D.new()
		collision.shape = shape
		collision.position = rect.get_center()
		edges.add_child(collision)
	add_child(edges)


## Distance along the centre line (0 to `length`) of the point closest to `point`.
func offset_at(point: Vector2) -> float:
	return curve.get_closest_offset(point)


## Position and direction on the centre line: `origin` is the point, `x` points
## along the road in the racing direction and `y` points to its right-hand side.
func transform_at(offset: float) -> Transform2D:
	return curve.sample_baked_with_rotation(wrapf(offset, 0.0, length), true)


func distance_from_centre(point: Vector2) -> float:
	return point.distance_to(curve.get_closest_point(point))


func is_off_road(point: Vector2) -> bool:
	return distance_from_centre(point) > road_width / 2.0 + kerb_width


## Where car number `slot` starts: a staggered two-wide grid behind the line.
func grid_transform(slot: int) -> Transform2D:
	var start := transform_at(-36.0 - slot * 22.0)
	var side := -1.0 if slot % 2 == 0 else 1.0
	start.origin += start.y * side * road_width * 0.22
	return start
