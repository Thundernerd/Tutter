extends Node
## Global game settings and lap records. Registered as the "Settings" autoload.

signal changed

const SAVE_PATH := "user://settings.cfg"
const REBINDABLE_ACTIONS: Array[StringName] = [
	&"p1_accelerate", &"p1_brake", &"p1_left", &"p1_right",
	&"p2_accelerate", &"p2_brake", &"p2_left", &"p2_right",
]
## CPU top speed as a fraction of the player's, for easy, normal and hard.
const CPU_SKILL: Array[float] = [0.82, 0.9, 0.97]

var master_volume := 0.8
var sfx_volume := 0.8
var fullscreen := false
var laps := 3
## 0 = easy, 1 = normal, 2 = hard.
var cpu_difficulty := 1
## Best lap time per track id, in seconds.
var best_laps := {}


func _ready() -> void:
	load_settings()
	apply()


## Push the current values to the audio server and the window.
func apply() -> void:
	_set_bus_volume(&"Master", master_volume)
	_set_bus_volume(&"SFX", sfx_volume)
	var mode := DisplayServer.WINDOW_MODE_FULLSCREEN if fullscreen else DisplayServer.WINDOW_MODE_WINDOWED
	DisplayServer.window_set_mode(mode)
	changed.emit()


func _set_bus_volume(bus_name: StringName, value: float) -> void:
	var index := AudioServer.get_bus_index(bus_name)
	AudioServer.set_bus_volume_db(index, linear_to_db(value))
	AudioServer.set_bus_mute(index, value <= 0.0)


func cpu_skill() -> float:
	return CPU_SKILL[cpu_difficulty]


func get_best_lap(track_id: String) -> float:
	return best_laps.get(track_id, INF)


## Remember a lap time if it beats the record. Returns true for a new record.
func submit_lap(track_id: String, time: float) -> bool:
	if time >= get_best_lap(track_id):
		return false
	best_laps[track_id] = time
	save_settings()
	return true


func clear_records() -> void:
	best_laps.clear()
	save_settings()


func get_key(action: StringName) -> Key:
	for event in InputMap.action_get_events(action):
		if event is InputEventKey:
			return event.physical_keycode
	return KEY_NONE


func set_key(action: StringName, keycode: Key) -> void:
	InputMap.action_erase_events(action)
	var event := InputEventKey.new()
	event.physical_keycode = keycode
	InputMap.action_add_event(action, event)


func key_name(action: StringName) -> String:
	return OS.get_keycode_string(get_key(action))


func save_settings() -> void:
	var config := ConfigFile.new()
	config.set_value("audio", "master_volume", master_volume)
	config.set_value("audio", "sfx_volume", sfx_volume)
	config.set_value("video", "fullscreen", fullscreen)
	config.set_value("race", "laps", laps)
	config.set_value("race", "cpu_difficulty", cpu_difficulty)
	for action in REBINDABLE_ACTIONS:
		config.set_value("controls", action, get_key(action))
	for track_id in best_laps:
		config.set_value("records", track_id, best_laps[track_id])
	config.save(SAVE_PATH)


func load_settings() -> void:
	var config := ConfigFile.new()
	if config.load(SAVE_PATH) != OK:
		return # First launch: keep the defaults.
	master_volume = config.get_value("audio", "master_volume", master_volume)
	sfx_volume = config.get_value("audio", "sfx_volume", sfx_volume)
	fullscreen = config.get_value("video", "fullscreen", fullscreen)
	laps = config.get_value("race", "laps", laps)
	cpu_difficulty = config.get_value("race", "cpu_difficulty", cpu_difficulty)
	for action in REBINDABLE_ACTIONS:
		var keycode: Key = config.get_value("controls", action, KEY_NONE)
		if keycode != KEY_NONE:
			set_key(action, keycode)
	best_laps.clear()
	if config.has_section("records"):
		for track_id in config.get_section_keys("records"):
			best_laps[track_id] = config.get_value("records", track_id)
