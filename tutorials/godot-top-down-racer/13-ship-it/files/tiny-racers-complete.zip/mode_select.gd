extends Control

@onready var mode_option: OptionButton = %ModeOption
@onready var players_option: OptionButton = %PlayersOption
@onready var track_option: OptionButton = %TrackOption
@onready var record_label: Label = %RecordLabel
@onready var description_label: Label = %DescriptionLabel
@onready var start_button: Button = %StartButton


func _ready() -> void:
	for info in Session.TRACKS:
		track_option.add_item(info.title)
	# Start from whatever was picked last time.
	mode_option.selected = Session.mode
	players_option.selected = Session.players - 1
	track_option.selected = Session.track_index
	_refresh()
	start_button.grab_focus()


func _refresh() -> void:
	var mode := mode_option.selected as Session.Mode
	var info := Session.TRACKS[track_option.selected]
	# A championship always runs every track, in order.
	track_option.disabled = mode == Session.Mode.CHAMPIONSHIP
	record_label.text = Format.time(Settings.get_best_lap(info.id))
	var opponent := "the CPU" if players_option.selected == 0 else "each other"
	match mode:
		Session.Mode.RACE:
			description_label.text = "%d laps against %s. %s" % [Settings.laps, opponent, info.description]
		Session.Mode.CHAMPIONSHIP:
			description_label.text = "Every track in a row, against %s. Points for each race: 10, 6, 3 and 1." % opponent
		Session.Mode.HEAD_TO_HEAD:
			description_label.text = "Two cars, one screen. Fall off the leader's screen and you lose a point. Take all eight to win."


func _on_option_item_selected(_index: int) -> void:
	_refresh()


func _on_start_button_pressed() -> void:
	Session.players = players_option.selected + 1
	Session.track_index = track_option.selected
	var mode := mode_option.selected as Session.Mode
	if mode == Session.Mode.CHAMPIONSHIP:
		Session.start_championship()
	else:
		Session.mode = mode
	get_tree().change_scene_to_file("res://race.tscn")


func _on_back_button_pressed() -> void:
	get_tree().change_scene_to_file("res://main_menu.tscn")
