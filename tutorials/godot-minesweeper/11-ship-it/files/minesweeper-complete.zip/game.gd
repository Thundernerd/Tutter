extends Node
## Runs one game: builds the board, keeps time, and reacts to the board's signals.

## Small boards stop growing at this cell size.
const MAX_CELL_SIZE := 32

var model: BoardModel
var elapsed := 0.0
var _won := false
var _new_record := false

@onready var board: Control = %Board
@onready var board_area: CenterContainer = %BoardArea
@onready var explosion: CPUParticles2D = %Explosion
@onready var hud: CanvasLayer = $HUD
@onready var pause_menu: CanvasLayer = $PauseMenu
@onready var result_screen: CanvasLayer = $ResultScreen
@onready var result_timer: Timer = $ResultTimer


func _ready() -> void:
	var config := Settings.board_config()
	model = BoardModel.new(config.width, config.height, config.mines)
	board.setup(model, fit_cell_size(board_area.size, model.width, model.height))
	hud.set_mines_left(model.flags_left())
	hud.set_time(0.0)


func _process(delta: float) -> void:
	if model.state == BoardModel.GameState.PLAYING:
		elapsed += delta
		hud.set_time(elapsed)


func _unhandled_input(event: InputEvent) -> void:
	if event.is_action_pressed("restart"):
		get_viewport().set_input_as_handled() # Before restarting: that frees this node.
		restart()


## The biggest whole-pixel cell size at which the board fits in `area`.
static func fit_cell_size(area: Vector2, columns: int, rows: int) -> int:
	var fit := floori(minf(area.x / columns, area.y / rows))
	return mini(fit, MAX_CELL_SIZE)


func restart() -> void:
	get_tree().reload_current_scene()


func _end_game(won: bool) -> void:
	_won = won
	pause_menu.set_process_unhandled_input(false)
	result_timer.start() # A moment to look at the board before the result screen.


func _on_board_cells_revealed(count: int) -> void:
	if count > 1:
		$Sounds/Cascade.play()
	else:
		$Sounds/Reveal.play()


func _on_board_flags_changed(flags_left: int) -> void:
	hud.set_mines_left(flags_left)
	if not model.is_finished():
		$Sounds/Flag.play()


func _on_board_held_changed(held: bool) -> void:
	if not model.is_finished():
		hud.set_face(SmileyButton.Face.WORRIED if held else SmileyButton.Face.SMILE)


func _on_board_game_lost(cell: Vector2i) -> void:
	hud.set_face(SmileyButton.Face.DEAD)
	$Sounds/Boom.play()
	explosion.position = board.cell_center(cell)
	explosion.restart()
	_end_game(false)


func _on_board_game_won() -> void:
	hud.set_face(SmileyButton.Face.COOL)
	$Sounds/Win.play()
	_new_record = Records.submit(Settings.difficulty, elapsed)
	_end_game(true)


func _on_result_timer_timeout() -> void:
	if _won:
		result_screen.show_win(elapsed, Records.get_best(Settings.difficulty), _new_record)
	else:
		result_screen.show_loss()
