extends Node
## Best times per difficulty. Registered as the "Records" autoload.

const SAVE_PATH := "user://records.cfg"

## Difficulty key → best time in seconds.
var best_times: Dictionary[String, float] = {}


func _ready() -> void:
	load_records()


## The best time for a difficulty, or -1 if there isn't one yet.
func get_best(difficulty: String) -> float:
	return best_times.get(difficulty, -1.0)


## Record a win. Returns true if it's a new best time.
func submit(difficulty: String, seconds: float) -> bool:
	if not Settings.PRESETS.has(difficulty):
		return false # Custom boards come in too many sizes to compare.
	var best := get_best(difficulty)
	if best >= 0.0 and seconds >= best:
		return false
	best_times[difficulty] = seconds
	save_records()
	return true


func format_time(seconds: float) -> String:
	return "%.1f s" % seconds


func save_records() -> void:
	var config := ConfigFile.new()
	for difficulty in best_times:
		config.set_value("best_times", difficulty, best_times[difficulty])
	config.save(SAVE_PATH)


func load_records() -> void:
	var config := ConfigFile.new()
	if config.load(SAVE_PATH) != OK or not config.has_section("best_times"):
		return
	for difficulty in config.get_section_keys("best_times"):
		best_times[difficulty] = config.get_value("best_times", difficulty)
