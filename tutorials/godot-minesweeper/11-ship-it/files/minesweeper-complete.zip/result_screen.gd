extends CanvasLayer
## Shown a moment after the game ends: the result, the time, and what to do next.

@onready var dim: ColorRect = $Dim
@onready var title_label: Label = %TitleLabel
@onready var detail_label: Label = %DetailLabel
@onready var play_again_button: Button = %PlayAgainButton


func _ready() -> void:
	hide()


func show_win(seconds: float, best: float, new_record: bool) -> void:
	title_label.text = "Cleared!"
	var details := "Time: " + Records.format_time(seconds)
	if new_record:
		details += "\nNew best time!"
	elif best >= 0.0:
		details += "\nBest: " + Records.format_time(best)
	else:
		details += "\nCustom boards don't keep records."
	detail_label.text = details
	_open()


func show_loss() -> void:
	title_label.text = "Boom!"
	detail_label.text = "You stepped on a mine."
	_open()


func _open() -> void:
	show()
	play_again_button.grab_focus()
	dim.modulate.a = 0.0
	create_tween().tween_property(dim, "modulate:a", 1.0, 0.3)


func _on_play_again_button_pressed() -> void:
	get_tree().reload_current_scene()


func _on_new_game_button_pressed() -> void:
	get_tree().change_scene_to_file("res://difficulty_menu.tscn")


func _on_main_menu_button_pressed() -> void:
	get_tree().change_scene_to_file("res://main_menu.tscn")
