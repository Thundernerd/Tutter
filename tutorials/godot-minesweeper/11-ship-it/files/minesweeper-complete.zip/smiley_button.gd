class_name SmileyButton
extends Button
## The restart button. Draws its own face on top of the normal button.

enum Face { SMILE, WORRIED, DEAD, COOL }

const COLOR_SKIN := Color("ffd23f")
const COLOR_INK := Color("20232e")

var face := Face.SMILE:
	set(value):
		face = value
		queue_redraw()


func _draw() -> void:
	var center := size / 2
	var radius := minf(size.x, size.y) * 0.36
	draw_circle(center, radius, COLOR_SKIN)
	draw_circle(center, radius, COLOR_INK, false, 1.5, true)
	var left_eye := center + Vector2(-0.35, -0.25) * radius
	var right_eye := center + Vector2(0.35, -0.25) * radius
	match face:
		Face.SMILE:
			_draw_eyes(left_eye, right_eye, radius)
			draw_arc(center, radius * 0.55, PI * 0.2, PI * 0.8, 12, COLOR_INK, 1.5, true)
		Face.WORRIED:
			_draw_eyes(left_eye, right_eye, radius)
			draw_circle(center + Vector2(0, 0.4) * radius, radius * 0.18, COLOR_INK, false, 1.5, true)
		Face.DEAD:
			for eye in [left_eye, right_eye]:
				var d := Vector2(radius, radius) * 0.14
				draw_line(eye - d, eye + d, COLOR_INK, 1.5, true)
				draw_line(eye + Vector2(-d.x, d.y), eye + Vector2(d.x, -d.y), COLOR_INK, 1.5, true)
			# The top of a circle below the face makes a frown.
			draw_arc(center + Vector2(0, 0.85) * radius, radius * 0.45, PI * 1.25, PI * 1.75, 12, COLOR_INK, 1.5, true)
		Face.COOL:
			for eye in [left_eye, right_eye]:
				draw_circle(eye + Vector2(0, 0.05) * radius, radius * 0.26, COLOR_INK, true, -1.0, true)
			draw_line(left_eye, right_eye, COLOR_INK, 1.5, true)
			draw_arc(center, radius * 0.55, PI * 0.2, PI * 0.8, 12, COLOR_INK, 1.5, true)


func _draw_eyes(left_eye: Vector2, right_eye: Vector2, radius: float) -> void:
	draw_circle(left_eye, radius * 0.1, COLOR_INK, true, -1.0, true)
	draw_circle(right_eye, radius * 0.1, COLOR_INK, true, -1.0, true)
