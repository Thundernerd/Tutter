extends Control
## Draws a BoardModel and turns clicks and key presses into moves.

signal cells_revealed(count: int)
signal flags_changed(flags_left: int)
signal game_won
signal game_lost(cell: Vector2i)
## True while the left mouse button is held down on the board.
signal held_changed(held: bool)

const NO_CELL := Vector2i(-1, -1)
## How long one cell takes to pop open, and the extra delay per cell of distance.
const REVEAL_TIME := 0.15
const RIPPLE_DELAY := 0.03

const COLOR_HIDDEN := Color("3d4663")
const COLOR_HIDDEN_EDGE := Color("56618a")
const COLOR_REVEALED := Color("1d2130")
const COLOR_EXPLODED := Color("c0392b")
const COLOR_CURSOR := Color("ffd166")
const COLOR_FLAG := Color("ff5252")
const COLOR_POLE := Color("e8e8e8")
const COLOR_MINE := Color("c9cede")
## Text colours for 1 to 8 (index 0 is unused).
const NUMBER_COLORS: Array[Color] = [
	Color.TRANSPARENT,
	Color("5b9bff"), Color("5fd35f"), Color("ff6b6b"), Color("b48cff"),
	Color("ffa94d"), Color("3fd0c9"), Color("e6e6e6"), Color("9aa0a6"),
]

var model: BoardModel
var cell_size := 32

var _hover := NO_CELL
var _held := false
var _anim_clock := 0.0
## Cell → the value of _anim_clock at which its reveal animation starts.
var _anim_start: Dictionary[Vector2i, float] = {}
var _anim_tween: Tween


func setup(board_model: BoardModel, new_cell_size: int) -> void:
	model = board_model
	cell_size = new_cell_size
	custom_minimum_size = Vector2(model.width, model.height) * cell_size
	queue_redraw()


## The centre of a cell in the board's own coordinates.
func cell_center(pos: Vector2i) -> Vector2:
	return (Vector2(pos) + Vector2(0.5, 0.5)) * cell_size


func _cell_at(point: Vector2) -> Vector2i:
	var pos := Vector2i((point / cell_size).floor())
	return pos if model.is_inside(pos) else NO_CELL


# --- Input -----------------------------------------------------------------

func _gui_input(event: InputEvent) -> void:
	if event is InputEventMouseMotion:
		_set_hover(_cell_at(event.position))
	elif event is InputEventMouseButton:
		var pos := _cell_at(event.position)
		if event.button_index == MOUSE_BUTTON_LEFT:
			if event.pressed:
				_reveal(pos)
			_set_held(event.pressed and not model.is_finished())
		elif event.button_index == MOUSE_BUTTON_RIGHT and event.pressed:
			_toggle_flag(pos)
		elif event.button_index == MOUSE_BUTTON_MIDDLE and event.pressed:
			_reveal(pos)
		accept_event()


func _notification(what: int) -> void:
	if what == NOTIFICATION_MOUSE_EXIT:
		_set_hover(NO_CELL)


func _unhandled_input(event: InputEvent) -> void:
	var step := Vector2i.ZERO
	if event.is_action_pressed("cursor_left", true):
		step = Vector2i.LEFT
	elif event.is_action_pressed("cursor_right", true):
		step = Vector2i.RIGHT
	elif event.is_action_pressed("cursor_up", true):
		step = Vector2i.UP
	elif event.is_action_pressed("cursor_down", true):
		step = Vector2i.DOWN
	elif event.is_action_pressed("reveal"):
		_reveal(_hover)
	elif event.is_action_pressed("flag"):
		_toggle_flag(_hover)
	else:
		return
	if step != Vector2i.ZERO:
		_move_cursor(step)
	get_viewport().set_input_as_handled()


func _move_cursor(step: Vector2i) -> void:
	if _hover == NO_CELL:
		# The first key press puts the cursor in the middle of the board.
		@warning_ignore("integer_division")
		_set_hover(Vector2i(model.width / 2, model.height / 2))
		return
	var target := _hover + step
	_set_hover(target.clamp(Vector2i.ZERO, Vector2i(model.width - 1, model.height - 1)))


func _set_hover(pos: Vector2i) -> void:
	if pos != _hover:
		_hover = pos
		queue_redraw()


func _set_held(held: bool) -> void:
	if held != _held:
		_held = held
		held_changed.emit(held)


# --- Moves -----------------------------------------------------------------

## Reveal a covered cell, or chord a revealed number.
func _reveal(pos: Vector2i) -> void:
	if pos == NO_CELL:
		return
	var revealed: Array[Vector2i]
	if model.get_cell(pos).state == BoardModel.CellState.REVEALED:
		revealed = model.chord(pos)
	else:
		revealed = model.reveal(pos)
	if revealed.is_empty():
		return
	_animate(revealed, pos)
	match model.state:
		BoardModel.GameState.LOST:
			_animate(_hidden_mines(), model.exploded)
			game_lost.emit(model.exploded)
		BoardModel.GameState.WON:
			flags_changed.emit(model.flags_left())
			game_won.emit()
		_:
			cells_revealed.emit(revealed.size())
	queue_redraw()


func _toggle_flag(pos: Vector2i) -> void:
	if pos == NO_CELL:
		return
	if model.toggle_flag(pos, Settings.question_marks):
		flags_changed.emit(model.flags_left())
		queue_redraw()


## Mines the player never saw; they pop open one by one when the game is lost.
func _hidden_mines() -> Array[Vector2i]:
	var mines: Array[Vector2i] = []
	for y in model.height:
		for x in model.width:
			var cell := model.get_cell(Vector2i(x, y))
			if cell.is_mine and cell.can_reveal():
				mines.append(Vector2i(x, y))
	return mines


# --- Animation -------------------------------------------------------------

## Pop cells open in a ripple that spreads out from `origin`.
func _animate(cells: Array[Vector2i], origin: Vector2i) -> void:
	var end := _anim_clock
	for pos in cells:
		var start := _anim_clock + Vector2(pos - origin).length() * RIPPLE_DELAY
		_anim_start[pos] = start
		end = maxf(end, start + REVEAL_TIME)
	if _anim_tween:
		_anim_tween.kill()
	_anim_tween = create_tween()
	_anim_tween.tween_method(_set_anim_clock, _anim_clock, end, end - _anim_clock)


func _set_anim_clock(value: float) -> void:
	_anim_clock = value
	queue_redraw()


## 0 when a cell's animation hasn't started, 1 when it's done (or it never had one).
func _anim_progress(pos: Vector2i) -> float:
	if not _anim_start.has(pos):
		return 1.0
	return clampf((_anim_clock - _anim_start[pos]) / REVEAL_TIME, 0.0, 1.0)


# --- Drawing ---------------------------------------------------------------

func _draw() -> void:
	if model == null:
		return
	for y in model.height:
		for x in model.width:
			_draw_cell(Vector2i(x, y))
	if _hover != NO_CELL and not model.is_finished():
		draw_rect(_cell_rect(_hover).grow(1), COLOR_CURSOR, false, 2.0)


## The visible square of a cell, leaving a 1px gap on every side.
func _cell_rect(pos: Vector2i) -> Rect2:
	return Rect2(Vector2(pos) * cell_size, Vector2(cell_size, cell_size)).grow(-1)


func _draw_cell(pos: Vector2i) -> void:
	var cell := model.get_cell(pos)
	var rect := _cell_rect(pos)
	var lost := model.state == BoardModel.GameState.LOST
	var face_up := cell.state == BoardModel.CellState.REVEALED
	# When the game is lost, unflagged mines are shown too.
	if lost and cell.is_mine and cell.state != BoardModel.CellState.FLAGGED:
		face_up = true
	if not face_up:
		_draw_covered(rect)
		if cell.state == BoardModel.CellState.FLAGGED:
			_draw_flag(rect)
			if lost and not cell.is_mine:
				_draw_cross(rect) # This flag was wrong.
		elif cell.state == BoardModel.CellState.QUESTIONED:
			_draw_text(rect, "?", COLOR_POLE)
		return
	draw_rect(rect, COLOR_EXPLODED if pos == model.exploded else COLOR_REVEALED)
	if cell.is_mine:
		_draw_mine(rect)
	elif cell.adjacent > 0:
		_draw_text(rect, str(cell.adjacent), NUMBER_COLORS[cell.adjacent])
	# While animating, a shrinking cover sits on top of the revealed cell.
	var progress := _anim_progress(pos)
	if progress < 1.0:
		_draw_covered(rect.grow(-rect.size.x * 0.5 * progress))


func _draw_covered(rect: Rect2) -> void:
	draw_rect(rect, COLOR_HIDDEN)
	# A lighter strip along the top makes the cell look raised.
	draw_rect(Rect2(rect.position, Vector2(rect.size.x, rect.size.y * 0.12)), COLOR_HIDDEN_EDGE)


func _draw_text(rect: Rect2, text: String, color: Color) -> void:
	var font := get_theme_default_font()
	var font_size := int(cell_size * 0.7)
	# draw_string positions the baseline, so centre the font's ascent and descent around the middle.
	var baseline := rect.get_center().y + (font.get_ascent(font_size) - font.get_descent(font_size)) / 2
	var origin := Vector2(rect.position.x, baseline)
	draw_string(font, origin, text, HORIZONTAL_ALIGNMENT_CENTER, rect.size.x, font_size, color)


## A point inside `rect`, given in fractions of its size: (0, 0) is top-left, (1, 1) bottom-right.
func _at(rect: Rect2, x: float, y: float) -> Vector2:
	return rect.position + rect.size * Vector2(x, y)


func _draw_flag(rect: Rect2) -> void:
	var line_width := maxf(1.0, cell_size * 0.08)
	draw_line(_at(rect, 0.4, 0.2), _at(rect, 0.4, 0.8), COLOR_POLE, line_width)
	draw_line(_at(rect, 0.25, 0.8), _at(rect, 0.65, 0.8), COLOR_POLE, line_width)
	var cloth := PackedVector2Array([_at(rect, 0.4, 0.2), _at(rect, 0.78, 0.35), _at(rect, 0.4, 0.5)])
	draw_colored_polygon(cloth, COLOR_FLAG)


func _draw_mine(rect: Rect2) -> void:
	var center := rect.get_center()
	var radius := rect.size.x * 0.22
	var line_width := maxf(1.0, cell_size * 0.07)
	for angle in [0.0, PI / 4, PI / 2, PI * 3 / 4]:
		var spike := Vector2.from_angle(angle) * radius * 1.5
		draw_line(center - spike, center + spike, COLOR_MINE, line_width)
	draw_circle(center, radius, COLOR_MINE)
	draw_circle(center - Vector2(radius, radius) * 0.35, radius * 0.25, Color.WHITE)


func _draw_cross(rect: Rect2) -> void:
	var line_width := maxf(1.0, cell_size * 0.08)
	draw_line(_at(rect, 0.2, 0.2), _at(rect, 0.8, 0.8), COLOR_EXPLODED, line_width)
	draw_line(_at(rect, 0.8, 0.2), _at(rect, 0.2, 0.8), COLOR_EXPLODED, line_width)
