class_name BoardModel
extends RefCounted
## The rules of Minesweeper: a grid of cells, with no nodes and no drawing.

enum GameState { READY, PLAYING, WON, LOST }
enum CellState { HIDDEN, REVEALED, FLAGGED, QUESTIONED }

## The eight steps from a cell to its neighbours.
const NEIGHBOUR_OFFSETS: Array[Vector2i] = [
	Vector2i(-1, -1), Vector2i(0, -1), Vector2i(1, -1),
	Vector2i(-1, 0), Vector2i(1, 0),
	Vector2i(-1, 1), Vector2i(0, 1), Vector2i(1, 1),
]

var width: int
var height: int
var mine_count: int
var state := GameState.READY
var flags_placed := 0
var revealed_count := 0
## The mine that ended the game, or (-1, -1).
var exploded := Vector2i(-1, -1)
## The grid, row by row: cells[y][x].
var cells: Array[Array] = []


class Cell:
	var state := CellState.HIDDEN
	var is_mine := false
	## How many of the eight neighbours are mines.
	var adjacent := 0

	## Hidden and question-marked cells can be revealed; flagged ones are protected.
	func can_reveal() -> bool:
		return state == CellState.HIDDEN or state == CellState.QUESTIONED


func _init(board_width: int, board_height: int, mines: int) -> void:
	width = board_width
	height = board_height
	mine_count = mines
	for y in height:
		var row: Array[Cell] = []
		for x in width:
			row.append(Cell.new())
		cells.append(row)


func get_cell(pos: Vector2i) -> Cell:
	return cells[pos.y][pos.x]


func is_inside(pos: Vector2i) -> bool:
	return pos.x >= 0 and pos.x < width and pos.y >= 0 and pos.y < height


## The (up to eight) cells around `pos` that are on the board.
func neighbours(pos: Vector2i) -> Array[Vector2i]:
	var result: Array[Vector2i] = []
	for offset in NEIGHBOUR_OFFSETS:
		var next := pos + offset
		if is_inside(next):
			result.append(next)
	return result


func flags_left() -> int:
	return mine_count - flags_placed


func is_finished() -> bool:
	return state == GameState.WON or state == GameState.LOST


## Scatter the mines anywhere except `safe` and the cells around it.
func place_mines(safe: Vector2i) -> void:
	var keep_clear := neighbours(safe)
	keep_clear.append(safe)
	var candidates: Array[Vector2i] = []
	for y in height:
		for x in width:
			var pos := Vector2i(x, y)
			if pos not in keep_clear:
				candidates.append(pos)
	assert(candidates.size() >= mine_count, "Too many mines for this board")
	candidates.shuffle()
	for i in mine_count:
		get_cell(candidates[i]).is_mine = true
	_count_adjacent()


func _count_adjacent() -> void:
	for y in height:
		for x in width:
			var pos := Vector2i(x, y)
			var count := 0
			for next in neighbours(pos):
				if get_cell(next).is_mine:
					count += 1
			get_cell(pos).adjacent = count


## Reveal a covered cell. Returns every cell that was revealed, in order.
func reveal(pos: Vector2i) -> Array[Vector2i]:
	var revealed: Array[Vector2i] = []
	if is_finished() or not get_cell(pos).can_reveal():
		return revealed
	if state == GameState.READY:
		place_mines(pos)
		state = GameState.PLAYING
	_open(pos, revealed)
	_check_win()
	return revealed


## Clicking a number whose mines are all flagged reveals its other neighbours.
func chord(pos: Vector2i) -> Array[Vector2i]:
	var revealed: Array[Vector2i] = []
	var cell := get_cell(pos)
	if state != GameState.PLAYING or cell.state != CellState.REVEALED or cell.adjacent == 0:
		return revealed
	var flags := 0
	for next in neighbours(pos):
		if get_cell(next).state == CellState.FLAGGED:
			flags += 1
	if flags != cell.adjacent:
		return revealed
	for next in neighbours(pos):
		# Check again inside the loop: an earlier flood fill may have revealed it.
		if get_cell(next).can_reveal():
			_open(next, revealed)
	_check_win()
	return revealed


## Cycle a covered cell: hidden → flagged → question mark (optional) → hidden.
func toggle_flag(pos: Vector2i, use_question_marks: bool) -> bool:
	if is_finished():
		return false
	var cell := get_cell(pos)
	match cell.state:
		CellState.HIDDEN:
			cell.state = CellState.FLAGGED
			flags_placed += 1
		CellState.FLAGGED:
			cell.state = CellState.QUESTIONED if use_question_marks else CellState.HIDDEN
			flags_placed -= 1
		CellState.QUESTIONED:
			cell.state = CellState.HIDDEN
		_:
			return false # Revealed cells can't be flagged.
	return true


## Reveal one cell the player chose. A mine ends the game; an empty cell floods.
func _open(pos: Vector2i, revealed: Array[Vector2i]) -> void:
	var cell := get_cell(pos)
	if cell.is_mine:
		cell.state = CellState.REVEALED
		revealed.append(pos)
		exploded = pos
		state = GameState.LOST
		return
	_flood_reveal(pos, revealed)


## Breadth-first flood fill: reveal `start`, and keep going through empty cells.
func _flood_reveal(start: Vector2i, revealed: Array[Vector2i]) -> void:
	var queue: Array[Vector2i] = [start]
	_reveal_one(start, revealed)
	while not queue.is_empty():
		var pos: Vector2i = queue.pop_front()
		if get_cell(pos).adjacent > 0:
			continue # A number is the edge of the region.
		for next in neighbours(pos):
			if get_cell(next).can_reveal():
				_reveal_one(next, revealed) # Reveal when queued, so no cell is queued twice.
				queue.append(next)


func _reveal_one(pos: Vector2i, revealed: Array[Vector2i]) -> void:
	get_cell(pos).state = CellState.REVEALED
	revealed_count += 1
	revealed.append(pos)


func _check_win() -> void:
	if state != GameState.PLAYING or revealed_count < width * height - mine_count:
		return
	state = GameState.WON
	# Flag the remaining mines, like the classic game does.
	for y in height:
		for x in width:
			var cell := get_cell(Vector2i(x, y))
			if cell.is_mine and cell.state != CellState.FLAGGED:
				cell.state = CellState.FLAGGED
				flags_placed += 1
