extends Node
## Global game settings. Registered as the "Settings" autoload.

const SAVE_PATH := "user://settings.cfg"
const PRESETS := {
	"beginner": {"name": "Beginner", "width": 9, "height": 9, "mines": 10},
	"intermediate": {"name": "Intermediate", "width": 16, "height": 16, "mines": 40},
	"expert": {"name": "Expert", "width": 30, "height": 16, "mines": 99},
}
const CUSTOM_MIN_SIZE := Vector2i(5, 5)
const CUSTOM_MAX_SIZE := Vector2i(40, 20)
const REBINDABLE_ACTIONS: Array[StringName] = [
	&"cursor_up", &"cursor_down", &"cursor_left", &"cursor_right", &"reveal", &"flag", &"restart",
]

## A key of PRESETS, or "custom".
var difficulty := "beginner"
var custom_width := 20
var custom_height := 12
var custom_mines := 40
var master_volume := 0.8
var sfx_volume := 0.8
var fullscreen := false
var question_marks := false


func _ready() -> void:
	load_settings()
	apply()


## The size and mine count of the board to play next.
func board_config() -> Dictionary:
	if difficulty == "custom":
		return {"name": "Custom", "width": custom_width, "height": custom_height, "mines": custom_mines}
	return PRESETS[difficulty]


## Leave room for the 3×3 opening around the first click.
func max_mines(width: int, height: int) -> int:
	return width * height - 9


## Push the current values to the audio server and the window.
func apply() -> void:
	_set_bus_volume(&"Master", master_volume)
	_set_bus_volume(&"SFX", sfx_volume)
	var mode := DisplayServer.WINDOW_MODE_FULLSCREEN if fullscreen else DisplayServer.WINDOW_MODE_WINDOWED
	DisplayServer.window_set_mode(mode)


func _set_bus_volume(bus_name: StringName, value: float) -> void:
	var index := AudioServer.get_bus_index(bus_name)
	AudioServer.set_bus_volume_db(index, linear_to_db(value))
	AudioServer.set_bus_mute(index, value <= 0.0)


func get_key(action: StringName) -> Key:
	for event in InputMap.action_get_events(action):
		if event is InputEventKey:
			return event.physical_keycode
	return KEY_NONE


func set_key(action: StringName, keycode: Key) -> void:
	InputMap.action_erase_events(action)
	var event := InputEventKey.new()
	event.physical_keycode = keycode
	InputMap.action_add_event(action, event)


func key_name(action: StringName) -> String:
	return OS.get_keycode_string(get_key(action))


func save_settings() -> void:
	var config := ConfigFile.new()
	config.set_value("game", "difficulty", difficulty)
	config.set_value("game", "custom_width", custom_width)
	config.set_value("game", "custom_height", custom_height)
	config.set_value("game", "custom_mines", custom_mines)
	config.set_value("game", "question_marks", question_marks)
	config.set_value("audio", "master_volume", master_volume)
	config.set_value("audio", "sfx_volume", sfx_volume)
	config.set_value("video", "fullscreen", fullscreen)
	for action in REBINDABLE_ACTIONS:
		config.set_value("controls", action, get_key(action))
	config.save(SAVE_PATH)


func load_settings() -> void:
	var config := ConfigFile.new()
	if config.load(SAVE_PATH) != OK:
		return # First launch: keep the defaults.
	difficulty = config.get_value("game", "difficulty", difficulty)
	if difficulty != "custom" and not PRESETS.has(difficulty):
		difficulty = "beginner" # A preset from an older version of the game.
	custom_width = clampi(config.get_value("game", "custom_width", custom_width), CUSTOM_MIN_SIZE.x, CUSTOM_MAX_SIZE.x)
	custom_height = clampi(config.get_value("game", "custom_height", custom_height), CUSTOM_MIN_SIZE.y, CUSTOM_MAX_SIZE.y)
	custom_mines = clampi(config.get_value("game", "custom_mines", custom_mines), 1, max_mines(custom_width, custom_height))
	question_marks = config.get_value("game", "question_marks", question_marks)
	master_volume = config.get_value("audio", "master_volume", master_volume)
	sfx_volume = config.get_value("audio", "sfx_volume", sfx_volume)
	fullscreen = config.get_value("video", "fullscreen", fullscreen)
	for action in REBINDABLE_ACTIONS:
		var keycode: Key = config.get_value("controls", action, KEY_NONE)
		if keycode != KEY_NONE:
			set_key(action, keycode)
