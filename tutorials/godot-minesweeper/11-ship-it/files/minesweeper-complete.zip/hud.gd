extends CanvasLayer
## The bar at the top: mines left, the restart smiley, and the clock.

signal restart_pressed

@onready var mine_counter: Label = %MineCounter
@onready var time_label: Label = %TimeLabel
@onready var smiley: SmileyButton = %Smiley


func set_mines_left(count: int) -> void:
	mine_counter.text = "%03d" % clampi(count, -99, 999)


func set_time(seconds: float) -> void:
	time_label.text = "%03d" % mini(int(seconds), 999)


func set_face(face: SmileyButton.Face) -> void:
	smiley.face = face


func _on_smiley_pressed() -> void:
	restart_pressed.emit()
