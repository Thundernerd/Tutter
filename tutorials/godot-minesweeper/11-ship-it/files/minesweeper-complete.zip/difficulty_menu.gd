extends Control
## Pick a preset or set up a custom board, then start the game.

@onready var preset_grid: GridContainer = %PresetGrid
@onready var width_spin: SpinBox = %WidthSpin
@onready var height_spin: SpinBox = %HeightSpin
@onready var mines_spin: SpinBox = %MinesSpin


func _ready() -> void:
	_build_presets()
	width_spin.min_value = Settings.CUSTOM_MIN_SIZE.x
	width_spin.max_value = Settings.CUSTOM_MAX_SIZE.x
	height_spin.min_value = Settings.CUSTOM_MIN_SIZE.y
	height_spin.max_value = Settings.CUSTOM_MAX_SIZE.y
	width_spin.set_value_no_signal(Settings.custom_width)
	height_spin.set_value_no_signal(Settings.custom_height)
	_update_mine_limit()
	mines_spin.set_value_no_signal(Settings.custom_mines)


func _build_presets() -> void:
	for difficulty in Settings.PRESETS:
		var preset: Dictionary = Settings.PRESETS[difficulty]
		var button := Button.new()
		button.text = preset.name
		button.custom_minimum_size.x = 120
		button.pressed.connect(_start.bind(difficulty))
		var size_label := Label.new()
		size_label.text = "%d × %d, %d mines" % [preset.width, preset.height, preset.mines]
		var best_label := Label.new()
		var best := Records.get_best(difficulty)
		best_label.text = "Best: " + (Records.format_time(best) if best >= 0.0 else "–")
		preset_grid.add_child(button)
		preset_grid.add_child(size_label)
		preset_grid.add_child(best_label)
		if difficulty == Settings.difficulty:
			button.grab_focus()


func _update_mine_limit() -> void:
	mines_spin.max_value = Settings.max_mines(int(width_spin.value), int(height_spin.value))


func _on_size_spin_value_changed(_value: float) -> void:
	_update_mine_limit()


func _on_custom_button_pressed() -> void:
	Settings.custom_width = int(width_spin.value)
	Settings.custom_height = int(height_spin.value)
	Settings.custom_mines = int(mines_spin.value)
	_start("custom")


func _start(difficulty: String) -> void:
	Settings.difficulty = difficulty
	Settings.save_settings()
	get_tree().change_scene_to_file("res://game.tscn")


func _on_back_button_pressed() -> void:
	get_tree().change_scene_to_file("res://main_menu.tscn")
