extends CanvasLayer

## Seconds to wait before showing the screen, so a player still mashing
## hard drop doesn't press a button by accident.
const SHOW_DELAY := 0.8

@onready var score_label: Label = %ScoreLabel
@onready var rank_label: Label = %RankLabel
@onready var high_score_table: GridContainer = %HighScoreTable
@onready var play_again_button: Button = %PlayAgainButton


func _ready() -> void:
	hide()


## `rank` is the place in the high score table, or -1 if the score didn't make it.
func show_result(score: int, rank: int) -> void:
	score_label.text = "Score: %d" % score
	rank_label.visible = rank >= 0
	rank_label.text = "New high score!" if rank == 0 else "#%d in the high scores!" % (rank + 1)
	high_score_table.refresh(rank)
	await get_tree().create_timer(SHOW_DELAY).timeout
	show()
	play_again_button.grab_focus()


func _on_play_again_button_pressed() -> void:
	get_tree().reload_current_scene()


func _on_main_menu_button_pressed() -> void:
	get_tree().change_scene_to_file("res://main_menu.tscn")
