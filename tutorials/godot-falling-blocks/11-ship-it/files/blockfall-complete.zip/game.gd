extends Node2D

signal piece_moved
signal piece_rotated
signal piece_held
signal piece_locked
signal hard_dropped(distance: int)
signal lines_cleared(count: int)
signal leveled_up(level: int)
signal topped_out

## Points for clearing 0, 1, 2, 3 or 4 lines at once, before multiplying by the level.
const LINE_SCORES: Array[int] = [0, 100, 300, 500, 800]
const LINES_PER_LEVEL := 10
## Gravity stops speeding up after this level.
const MAX_SPEED_LEVEL := 15
## Seconds per row while soft drop is held.
const SOFT_DROP_INTERVAL := 0.05
## How often moving or rotating on the ground may restart the lock delay.
const MAX_LOCK_RESETS := 15
## How many upcoming pieces the HUD shows.
const NEXT_COUNT := 3

## The falling piece, or null between pieces and after game over.
var piece: Tetromino
var bag := PieceBag.new()
## The Tetromino.Type in the hold box, or -1 when it's empty.
var hold_type := -1
var can_hold := true
var score := 0
var lines := 0
var level := 1

var _soft_dropping := false
var _lock_resets := 0
var _lowest_row := 0
## -1 while left is held, 1 for right, 0 for neither.
var _shift_direction := 0
## Counts down to the next automatic sideways step.
var _shift_timer := 0.0
var _shake_tween: Tween

@onready var board: Board = $Board
@onready var hud: CanvasLayer = $HUD
@onready var camera: Camera2D = $Camera2D
@onready var gravity_timer: Timer = $GravityTimer
@onready var lock_timer: Timer = $LockTimer
@onready var pause_menu: CanvasLayer = $PauseMenu
@onready var game_over: CanvasLayer = $GameOver


func _ready() -> void:
	piece_moved.connect($Sounds/Move.play)
	piece_rotated.connect($Sounds/Rotate.play)
	piece_held.connect($Sounds/Hold.play)
	piece_locked.connect($Sounds/Lock.play)
	hard_dropped.connect(_on_hard_dropped)
	lines_cleared.connect(_on_lines_cleared)
	leveled_up.connect($Sounds/LevelUp.play.unbind(1))
	topped_out.connect($Sounds/TopOut.play)

	board.show_ghost = Settings.ghost_piece
	hud.update_stats(score, level, lines)
	hud.update_hold(hold_type, can_hold)
	_spawn(bag.next())


## Seconds per row at `for_level`. Level 1 is one row per second.
static func fall_interval(for_level: int) -> float:
	var steps := mini(for_level, MAX_SPEED_LEVEL) - 1
	return pow(0.8 - steps * 0.007, steps)


func _process(delta: float) -> void:
	if piece == null:
		return
	_update_soft_drop()
	_auto_shift(delta)


func _unhandled_input(event: InputEvent) -> void:
	if piece == null:
		return
	if event.is_action_pressed(&"rotate_cw"):
		_rotate(1)
	elif event.is_action_pressed(&"rotate_ccw"):
		_rotate(-1)
	elif event.is_action_pressed(&"hard_drop"):
		hard_drop()
	elif event.is_action_pressed(&"hold"):
		hold()


func _spawn(piece_type: int) -> void:
	piece = Tetromino.spawn(piece_type, Board.COLUMNS)
	board.piece = piece
	_lowest_row = piece.position.y
	_lock_resets = 0
	lock_timer.stop()
	hud.update_next(bag.peek(NEXT_COUNT))
	if not board.fits(piece):
		_game_over() # Blocked right at the top: the stack is too high.
		return
	_update_lock_timer()
	_restart_gravity()


## Move the piece by `offset` if it fits there. Returns whether it moved.
func _try_move(offset: Vector2i) -> bool:
	var moved := piece.moved(offset)
	if not board.fits(moved):
		return false
	_set_piece(moved)
	if offset.x != 0:
		piece_moved.emit()
	return true


## Turn the piece, trying each wall kick in turn until one fits.
func _rotate(direction: int) -> void:
	var turned := piece.rotated(direction)
	for kick in piece.kicks(direction):
		var kicked := turned.moved(kick)
		if board.fits(kicked):
			_set_piece(kicked)
			piece_rotated.emit()
			return


func _set_piece(new_piece: Tetromino) -> void:
	piece = new_piece
	board.piece = piece
	if piece.position.y > _lowest_row:
		# A new lowest point earns a fresh set of lock delay resets.
		_lowest_row = piece.position.y
		_lock_resets = 0
	_update_lock_timer()


## Start, restart or stop the lock delay depending on whether the piece is resting on something.
func _update_lock_timer() -> void:
	if board.fits(piece.moved(Vector2i.DOWN)):
		lock_timer.stop() # In the air: nothing to lock onto.
	elif lock_timer.is_stopped():
		lock_timer.start() # Just landed.
	elif _lock_resets < MAX_LOCK_RESETS:
		_lock_resets += 1
		lock_timer.start() # Moved while on the ground: start the countdown again.


func _on_gravity_timer_timeout() -> void:
	if piece and _try_move(Vector2i.DOWN) and _soft_dropping:
		_add_score(1)


func _on_lock_timer_timeout() -> void:
	if piece:
		_lock_piece()


func _restart_gravity() -> void:
	var interval := fall_interval(level)
	if _soft_dropping:
		interval = minf(interval, SOFT_DROP_INTERVAL)
	gravity_timer.start(interval)


func _update_soft_drop() -> void:
	var pressed := Input.is_action_pressed(&"soft_drop")
	if pressed == _soft_dropping:
		return
	_soft_dropping = pressed
	_restart_gravity()
	if pressed:
		_on_gravity_timer_timeout() # React on the first frame, not one interval later.


## Move sideways on the first frame a direction is held, then wait for the
## auto-repeat delay (DAS), then keep stepping at the auto-repeat rate (ARR).
func _auto_shift(delta: float) -> void:
	var direction := roundi(Input.get_axis(&"move_left", &"move_right"))
	if direction != _shift_direction:
		_shift_direction = direction
		_shift_timer = Settings.das_ms / 1000.0
		if direction != 0:
			_try_move(Vector2i(direction, 0))
		return
	if direction == 0:
		return
	_shift_timer -= delta
	while _shift_timer <= 0.0:
		if not _try_move(Vector2i(direction, 0)):
			_shift_timer = 0.0 # Against a wall: stay charged, but don't build up moves.
			return
		if Settings.arr_ms <= 0:
			continue # An ARR of 0 slides all the way in a single frame.
		_shift_timer += Settings.arr_ms / 1000.0


func hard_drop() -> void:
	var distance := board.drop_distance(piece)
	piece = piece.moved(Vector2i(0, distance))
	_add_score(distance * 2)
	hard_dropped.emit(distance)
	_lock_piece()


## Swap the falling piece with the hold box. Allowed once per piece.
func hold() -> void:
	if not can_hold:
		return
	can_hold = false
	var held := piece.type
	if hold_type == -1:
		_spawn(bag.next())
	else:
		_spawn(hold_type)
	hold_type = held
	hud.update_hold(hold_type, can_hold)
	piece_held.emit()


func _lock_piece() -> void:
	lock_timer.stop()
	gravity_timer.stop()
	var locked := piece
	piece = null
	var inside := board.lock_piece(locked)
	piece_locked.emit()
	if not inside:
		_game_over() # Locked partly above the board.
		return
	can_hold = true
	hud.update_hold(hold_type, can_hold)
	var full := board.full_rows()
	if not full.is_empty():
		await board.clear_rows(full)
		_score_lines(full.size())
	_spawn(bag.next())


func _score_lines(count: int) -> void:
	lines += count
	score += LINE_SCORES[count] * level
	lines_cleared.emit(count)
	@warning_ignore("integer_division")
	var new_level := lines / LINES_PER_LEVEL + 1
	if new_level > level:
		level = new_level
		leveled_up.emit(level)
	hud.update_stats(score, level, lines)


func _add_score(points: int) -> void:
	score += points
	hud.update_stats(score, level, lines)


func _game_over() -> void:
	piece = null
	gravity_timer.stop()
	lock_timer.stop()
	board.modulate = Color(0.5, 0.5, 0.55) # Grey out the stack.
	topped_out.emit()
	pause_menu.set_process_unhandled_input(false)
	var rank := HighScores.submit(score, lines, level)
	game_over.show_result(score, rank)


func _on_hard_dropped(distance: int) -> void:
	_shake(clampf(distance / 3.0, 1.0, 4.0))


func _on_lines_cleared(count: int) -> void:
	# Same sound, higher pitch for bigger clears.
	$Sounds/Clear.pitch_scale = 1.0 + 0.15 * (count - 1)
	$Sounds/Clear.play()


## Jolt the camera down by `strength` pixels, then wobble back into place.
func _shake(strength: float) -> void:
	if _shake_tween:
		_shake_tween.kill()
	_shake_tween = create_tween()
	_shake_tween.tween_property(camera, "offset", Vector2(0, strength), 0.03)
	for i in 3:
		var wobble := strength * 0.5 / (i + 1)
		_shake_tween.tween_property(camera, "offset", Vector2(randf_range(-wobble, wobble), randf_range(-wobble, wobble)), 0.03)
	_shake_tween.tween_property(camera, "offset", Vector2.ZERO, 0.05)
