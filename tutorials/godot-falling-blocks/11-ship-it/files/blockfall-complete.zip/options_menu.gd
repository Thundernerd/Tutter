extends Control

const ACTION_LABELS := {
	&"move_left": "Move left",
	&"move_right": "Move right",
	&"soft_drop": "Soft drop",
	&"hard_drop": "Hard drop",
	&"rotate_cw": "Rotate right",
	&"rotate_ccw": "Rotate left",
	&"hold": "Hold",
}

## The action waiting for a new key, or &"" when not rebinding.
var _rebinding := &""
## One button per action, so a swap can update both buttons involved.
var _key_buttons := {}

@onready var master_slider: HSlider = %MasterSlider
@onready var sfx_slider: HSlider = %SfxSlider
@onready var fullscreen_check: CheckButton = %FullscreenCheck
@onready var ghost_check: CheckButton = %GhostCheck
@onready var das_spin: SpinBox = %DasSpin
@onready var arr_spin: SpinBox = %ArrSpin
@onready var controls_grid: GridContainer = %ControlsGrid


func _ready() -> void:
	# The *_no_signal setters avoid triggering our change handlers (and the test sound).
	master_slider.set_value_no_signal(Settings.master_volume)
	sfx_slider.set_value_no_signal(Settings.sfx_volume)
	fullscreen_check.set_pressed_no_signal(Settings.fullscreen)
	ghost_check.set_pressed_no_signal(Settings.ghost_piece)
	das_spin.set_value_no_signal(Settings.das_ms)
	arr_spin.set_value_no_signal(Settings.arr_ms)
	_build_controls()
	master_slider.grab_focus()


func _build_controls() -> void:
	for action in Settings.REBINDABLE_ACTIONS:
		var label := Label.new()
		label.text = ACTION_LABELS[action]
		var button := Button.new()
		button.custom_minimum_size.x = 100
		button.pressed.connect(_start_rebind.bind(action))
		controls_grid.add_child(label)
		controls_grid.add_child(button)
		_key_buttons[action] = button
	_update_key_buttons()


func _update_key_buttons() -> void:
	for action in _key_buttons:
		_key_buttons[action].text = Settings.key_name(action)


func _start_rebind(action: StringName) -> void:
	_rebinding = action
	_key_buttons[action].text = "Press a key…"


func _input(event: InputEvent) -> void:
	if _rebinding == &"" or not (event is InputEventKey and event.pressed and not event.echo):
		return
	get_viewport().set_input_as_handled()
	# The pause keys (Esc and P) cancel instead of being bound.
	if not event.is_action(&"pause"):
		Settings.set_key(_rebinding, event.physical_keycode)
	_rebinding = &""
	_update_key_buttons()


func _on_master_slider_value_changed(value: float) -> void:
	Settings.master_volume = value
	Settings.apply()


func _on_sfx_slider_value_changed(value: float) -> void:
	Settings.sfx_volume = value
	Settings.apply()
	$TestSound.play() # Let the player hear the new volume.


func _on_fullscreen_check_toggled(toggled_on: bool) -> void:
	Settings.fullscreen = toggled_on
	Settings.apply()


func _on_ghost_check_toggled(toggled_on: bool) -> void:
	Settings.ghost_piece = toggled_on


func _on_das_spin_value_changed(value: float) -> void:
	Settings.das_ms = int(value)


func _on_arr_spin_value_changed(value: float) -> void:
	Settings.arr_ms = int(value)


func _on_back_button_pressed() -> void:
	Settings.save_settings()
	get_tree().change_scene_to_file("res://main_menu.tscn")
