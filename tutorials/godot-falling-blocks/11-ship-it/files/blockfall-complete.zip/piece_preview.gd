class_name PiecePreview
extends Control
## Draws a single piece centred in this control. Used for the hold and next boxes.

const BACKGROUND_COLOR := Color(0.07, 0.08, 0.11)
const DIMMED_COLOR := Color(0.35, 0.36, 0.42)

@export var cell_size := 12.0

## The Tetromino.Type to show, or -1 to show nothing.
var piece_type := -1:
	set(value):
		piece_type = value
		queue_redraw()
## Draw the piece in grey, for a hold that can't be used right now.
var dimmed := false:
	set(value):
		dimmed = value
		queue_redraw()


func _draw() -> void:
	draw_rect(Rect2(Vector2.ZERO, size), BACKGROUND_COLOR)
	if piece_type < 0:
		return
	var cells: Array = Tetromino.SHAPES[piece_type]
	# Find the shape's bounding box so we can centre it.
	var top_left := Vector2i(99, 99)
	var bottom_right := Vector2i(-99, -99)
	for cell: Vector2i in cells:
		top_left = top_left.min(cell)
		bottom_right = bottom_right.max(cell)
	var shape_size := Vector2(bottom_right - top_left + Vector2i.ONE) * cell_size
	var origin := (size - shape_size) / 2.0
	var color := DIMMED_COLOR if dimmed else Tetromino.COLORS[piece_type]
	for cell: Vector2i in cells:
		var rect := Rect2(origin + Vector2(cell - top_left) * cell_size, Vector2(cell_size, cell_size))
		Tetromino.draw_block(self, rect, color)
