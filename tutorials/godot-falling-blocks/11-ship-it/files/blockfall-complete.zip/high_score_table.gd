extends GridContainer
## A table of the saved high scores. Used by the main menu and the game over screen.

const HEADER_COLOR := Color(0.6, 0.62, 0.72)
const HIGHLIGHT_COLOR := Color(0.95, 0.83, 0.23)


func _ready() -> void:
	refresh()


## Rebuild the rows. The row at index `highlight` is drawn in a highlight colour.
func refresh(highlight := -1) -> void:
	for child in get_children():
		child.free()
	_add_row(["", "Score", "Lines", "Level"], HEADER_COLOR)
	for i in HighScores.MAX_ENTRIES:
		var color := HIGHLIGHT_COLOR if i == highlight else Color.WHITE
		if i < HighScores.entries.size():
			var entry: Dictionary = HighScores.entries[i]
			_add_row(["%d." % (i + 1), str(entry["score"]), str(entry["lines"]), str(entry["level"])], color)
		else:
			_add_row(["%d." % (i + 1), "-", "-", "-"], color)


func _add_row(texts: Array, color: Color) -> void:
	for text in texts:
		var label := Label.new()
		label.text = text
		label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
		label.modulate = color
		add_child(label)
