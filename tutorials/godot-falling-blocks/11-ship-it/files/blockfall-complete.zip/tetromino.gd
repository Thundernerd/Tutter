class_name Tetromino
extends RefCounted
## One piece: its type, rotation and position on the board.
## Also holds the shape, colour and wall kick data for all seven types.

enum Type { I, O, T, S, Z, J, L }

const COLORS: Array[Color] = [
	Color(0.25, 0.82, 0.88), # I: cyan
	Color(0.95, 0.83, 0.23), # O: yellow
	Color(0.65, 0.37, 0.88), # T: purple
	Color(0.36, 0.84, 0.36), # S: green
	Color(0.91, 0.32, 0.29), # Z: red
	Color(0.29, 0.49, 0.91), # J: blue
	Color(0.94, 0.6, 0.23), # L: orange
]

## The cells of each type in its spawn rotation, inside a square box
## SIZES[type] cells wide. x grows to the right, y grows downwards.
const SHAPES: Array = [
	[Vector2i(0, 1), Vector2i(1, 1), Vector2i(2, 1), Vector2i(3, 1)], # I
	[Vector2i(0, 0), Vector2i(1, 0), Vector2i(0, 1), Vector2i(1, 1)], # O
	[Vector2i(1, 0), Vector2i(0, 1), Vector2i(1, 1), Vector2i(2, 1)], # T
	[Vector2i(1, 0), Vector2i(2, 0), Vector2i(0, 1), Vector2i(1, 1)], # S
	[Vector2i(0, 0), Vector2i(1, 0), Vector2i(1, 1), Vector2i(2, 1)], # Z
	[Vector2i(0, 0), Vector2i(0, 1), Vector2i(1, 1), Vector2i(2, 1)], # J
	[Vector2i(2, 0), Vector2i(0, 1), Vector2i(1, 1), Vector2i(2, 1)], # L
]
const SIZES: Array[int] = [4, 2, 3, 3, 3, 3, 3]

## Super Rotation System wall kicks for a clockwise turn, indexed by the
## rotation the piece turns *from*. Each turn tries these offsets in order.
## y points down in Godot, so these are the usual SRS tables with y flipped.
const KICKS_JLSTZ: Array = [
	[Vector2i(0, 0), Vector2i(-1, 0), Vector2i(-1, -1), Vector2i(0, 2), Vector2i(-1, 2)], # 0 -> 1
	[Vector2i(0, 0), Vector2i(1, 0), Vector2i(1, 1), Vector2i(0, -2), Vector2i(1, -2)], # 1 -> 2
	[Vector2i(0, 0), Vector2i(1, 0), Vector2i(1, -1), Vector2i(0, 2), Vector2i(1, 2)], # 2 -> 3
	[Vector2i(0, 0), Vector2i(-1, 0), Vector2i(-1, 1), Vector2i(0, -2), Vector2i(-1, -2)], # 3 -> 0
]
const KICKS_I: Array = [
	[Vector2i(0, 0), Vector2i(-2, 0), Vector2i(1, 0), Vector2i(-2, 1), Vector2i(1, -2)], # 0 -> 1
	[Vector2i(0, 0), Vector2i(-1, 0), Vector2i(2, 0), Vector2i(-1, -2), Vector2i(2, 1)], # 1 -> 2
	[Vector2i(0, 0), Vector2i(2, 0), Vector2i(-1, 0), Vector2i(2, -1), Vector2i(-1, 2)], # 2 -> 3
	[Vector2i(0, 0), Vector2i(1, 0), Vector2i(-2, 0), Vector2i(1, 2), Vector2i(-2, -1)], # 3 -> 0
]

## One of the Type values.
var type: int = Type.I
## 0 is the spawn rotation; 1, 2 and 3 are each a further quarter turn clockwise.
var rotation := 0
## The top-left corner of the piece's box, in board cells.
var position := Vector2i.ZERO


func _init(piece_type: int, piece_rotation := 0, piece_position := Vector2i.ZERO) -> void:
	type = piece_type
	rotation = piece_rotation
	position = piece_position


## A new piece in spawn rotation, centred at the top of a board `columns` wide.
static func spawn(piece_type: int, columns: int) -> Tetromino:
	var size := SIZES[piece_type]
	# The I piece sits in the second row of its box: lift it so it starts on row 0.
	var top := -1 if piece_type == Type.I else 0
	return Tetromino.new(piece_type, 0, Vector2i(floori((columns - size) / 2.0), top))


## The board cells this piece covers.
func cells() -> Array[Vector2i]:
	var size := SIZES[type]
	var result: Array[Vector2i] = []
	for cell: Vector2i in SHAPES[type]:
		for turn in rotation:
			cell = Vector2i(size - 1 - cell.y, cell.x) # A quarter turn clockwise.
		result.append(position + cell)
	return result


## A copy of this piece, moved by `offset` cells.
func moved(offset: Vector2i) -> Tetromino:
	return Tetromino.new(type, rotation, position + offset)


## A copy of this piece, turned clockwise (1) or counter-clockwise (-1).
func rotated(direction: int) -> Tetromino:
	return Tetromino.new(type, wrapi(rotation + direction, 0, 4), position)


## The offsets to try, in order, when turning this piece in `direction`.
func kicks(direction: int) -> Array[Vector2i]:
	var result: Array[Vector2i] = []
	if type == Type.O:
		result.append(Vector2i.ZERO) # The O piece looks the same in every rotation.
		return result
	var table: Array = KICKS_I if type == Type.I else KICKS_JLSTZ
	if direction == 1:
		result.assign(table[rotation])
	else:
		# A counter-clockwise turn undoes the clockwise turn into this rotation,
		# so it uses that turn's offsets, reversed.
		for kick: Vector2i in table[wrapi(rotation - 1, 0, 4)]:
			result.append(-kick)
	return result


## Draw one block with a darker edge and a highlight. Shared by the board and
## the preview boxes.
static func draw_block(canvas: CanvasItem, rect: Rect2, color: Color) -> void:
	canvas.draw_rect(rect, color.darkened(0.45))
	canvas.draw_rect(rect.grow(-1), color)
	canvas.draw_rect(Rect2(rect.position + Vector2(1, 1), Vector2(rect.size.x - 2, 2)), color.lightened(0.4))
