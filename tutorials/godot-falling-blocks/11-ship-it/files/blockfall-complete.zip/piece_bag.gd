class_name PieceBag
extends RefCounted
## The "7-bag" randomizer: deals all seven pieces in a random order,
## then shuffles a fresh bag. Never more than 12 pieces between two of a kind.

var _queue: Array[int] = []


## Take the next piece type out of the bag.
func next() -> int:
	_fill(1)
	return _queue.pop_front()


## The next `count` piece types, without taking them out.
func peek(count: int) -> Array[int]:
	_fill(count)
	return _queue.slice(0, count)


func _fill(count: int) -> void:
	while _queue.size() < count:
		var bag: Array[int] = []
		bag.assign(Tetromino.Type.values())
		bag.shuffle()
		_queue.append_array(bag)
