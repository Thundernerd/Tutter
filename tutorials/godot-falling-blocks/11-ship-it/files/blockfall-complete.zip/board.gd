class_name Board
extends Node2D
## The playfield: which cells are filled, and drawing everything on it.

const COLUMNS := 10
const ROWS := 20
const CELL_SIZE := 16
const EMPTY := -1
## How long the line clear animation takes, in seconds.
const CLEAR_TIME := 0.3

const BACKGROUND_COLOR := Color(0.07, 0.08, 0.11)
const GRID_COLOR := Color(1, 1, 1, 0.04)
const FRAME_COLOR := Color(0.29, 0.31, 0.44)

## rows[y][x] is EMPTY or the Tetromino.Type that filled the cell. Row 0 is the top.
var rows: Array[Array] = []
## The falling piece, drawn on top of the locked blocks. null between pieces.
var piece: Tetromino:
	set(value):
		piece = value
		queue_redraw()
## Draw a preview of where the falling piece will land.
var show_ghost := true

## Rows being cleared, and how far along their animation is (0 to 1).
var _clearing: Array[int] = []
var _clear_progress := 0.0:
	set(value):
		_clear_progress = value
		queue_redraw()


func _ready() -> void:
	for y in ROWS:
		rows.append(_empty_row())


func _empty_row() -> Array:
	var row := []
	row.resize(COLUMNS)
	row.fill(EMPTY)
	return row


## True if `cell` is inside the walls and not filled. Above the top is open space.
func is_free(cell: Vector2i) -> bool:
	if cell.x < 0 or cell.x >= COLUMNS or cell.y >= ROWS:
		return false
	if cell.y < 0:
		return true
	return rows[cell.y][cell.x] == EMPTY


## True if every cell of `test` is free.
func fits(test: Tetromino) -> bool:
	for cell in test.cells():
		if not is_free(cell):
			return false
	return true


## How many rows `test` can fall before it lands.
func drop_distance(test: Tetromino) -> int:
	var distance := 0
	while fits(test.moved(Vector2i(0, distance + 1))):
		distance += 1
	return distance


## Copy the piece's cells into the grid. Returns false if any cell
## stuck out above the top of the board, which ends the game.
func lock_piece(locked: Tetromino) -> bool:
	var inside := true
	for cell in locked.cells():
		if cell.y < 0:
			inside = false
		else:
			rows[cell.y][cell.x] = locked.type
	piece = null
	return inside


## The indices of all completely filled rows, top to bottom.
func full_rows() -> Array[int]:
	var result: Array[int] = []
	for y in ROWS:
		if not rows[y].has(EMPTY):
			result.append(y)
	return result


## Flash the rows, then remove them and let everything above fall down.
func clear_rows(full: Array[int]) -> void:
	_clearing = full
	var tween := create_tween()
	tween.tween_property(self, "_clear_progress", 1.0, CLEAR_TIME).from(0.0)
	await tween.finished
	_clearing = []
	# Going top to bottom keeps the remaining indices valid: removing a row
	# and adding an empty one at the top leaves every row below in place.
	for y in full:
		rows.remove_at(y)
		rows.push_front(_empty_row())
	queue_redraw()


func _draw() -> void:
	var well := Rect2(0, 0, COLUMNS * CELL_SIZE, ROWS * CELL_SIZE)
	draw_rect(well.grow(2), FRAME_COLOR)
	draw_rect(well, BACKGROUND_COLOR)
	for x in range(1, COLUMNS):
		draw_line(Vector2(x * CELL_SIZE, 0), Vector2(x * CELL_SIZE, well.size.y), GRID_COLOR)
	for y in range(1, ROWS):
		draw_line(Vector2(0, y * CELL_SIZE), Vector2(well.size.x, y * CELL_SIZE), GRID_COLOR)

	for y in ROWS:
		for x in COLUMNS:
			if rows[y][x] != EMPTY:
				_draw_cell(Vector2i(x, y), Tetromino.COLORS[rows[y][x]])

	if piece:
		var color := Tetromino.COLORS[piece.type]
		if show_ghost:
			var ghost := piece.moved(Vector2i(0, drop_distance(piece)))
			for cell in ghost.cells():
				_draw_ghost_cell(cell, color)
		for cell in piece.cells():
			_draw_cell(cell, color)

	for y in _clearing:
		_draw_clearing_row(y)


func _cell_rect(cell: Vector2i) -> Rect2:
	return Rect2(Vector2(cell * CELL_SIZE), Vector2(CELL_SIZE, CELL_SIZE))


func _draw_cell(cell: Vector2i, color: Color) -> void:
	if cell.y >= 0: # Cells above the board stay hidden.
		Tetromino.draw_block(self, _cell_rect(cell), color)


func _draw_ghost_cell(cell: Vector2i, color: Color) -> void:
	if cell.y >= 0:
		var rect := _cell_rect(cell).grow(-1)
		draw_rect(rect, Color(color, 0.15))
		draw_rect(rect, Color(color, 0.6), false, 1.0)


## First half: the row fades to white. Second half: the white bar shrinks to nothing.
func _draw_clearing_row(y: int) -> void:
	var row := Rect2(0, y * CELL_SIZE, COLUMNS * CELL_SIZE, CELL_SIZE)
	if _clear_progress < 0.5:
		draw_rect(row, Color(1, 1, 1, _clear_progress * 2.0))
	else:
		draw_rect(row, BACKGROUND_COLOR)
		var shrink := (_clear_progress - 0.5) * 2.0 * row.size.x / 2.0
		draw_rect(row.grow_individual(-shrink, 0, -shrink, 0), Color.WHITE)
