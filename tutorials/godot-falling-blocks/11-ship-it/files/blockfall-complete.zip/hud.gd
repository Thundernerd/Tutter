extends CanvasLayer

@onready var score_label: Label = %ScoreLabel
@onready var level_label: Label = %LevelLabel
@onready var lines_label: Label = %LinesLabel
@onready var hold_preview: PiecePreview = %HoldPreview
@onready var next_previews: Array[PiecePreview] = [%Next1, %Next2, %Next3]


func update_stats(score: int, level: int, lines: int) -> void:
	score_label.text = str(score)
	level_label.text = str(level)
	lines_label.text = str(lines)


func update_hold(piece_type: int, can_hold: bool) -> void:
	hold_preview.piece_type = piece_type
	hold_preview.dimmed = not can_hold


func update_next(piece_types: Array[int]) -> void:
	for i in next_previews.size():
		next_previews[i].piece_type = piece_types[i]
