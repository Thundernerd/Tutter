extends Node
## The best scores, kept between sessions. Registered as the "HighScores" autoload.

const SAVE_PATH := "user://high_scores.cfg"
const MAX_ENTRIES := 5

## Best first. Each entry looks like {"score": 1200, "lines": 14, "level": 2}.
var entries: Array[Dictionary] = []


func _ready() -> void:
	load_scores()


## Record a finished game. Returns its place in the table (0 is the best),
## or -1 if it didn't make the table.
func submit(score: int, lines: int, level: int) -> int:
	if score <= 0:
		return -1
	var rank := 0
	while rank < entries.size() and entries[rank]["score"] >= score:
		rank += 1
	if rank >= MAX_ENTRIES:
		return -1
	entries.insert(rank, {"score": score, "lines": lines, "level": level})
	if entries.size() > MAX_ENTRIES:
		entries.resize(MAX_ENTRIES)
	save_scores()
	return rank


func save_scores() -> void:
	var config := ConfigFile.new()
	config.set_value("scores", "entries", entries)
	config.save(SAVE_PATH)


func load_scores() -> void:
	var config := ConfigFile.new()
	if config.load(SAVE_PATH) != OK:
		return
	entries.assign(config.get_value("scores", "entries", []))
