extends Node
## Global game settings. Registered as the "Settings" autoload.

const SAVE_PATH := "user://settings.cfg"
const REBINDABLE_ACTIONS: Array[StringName] = [
	&"move_left", &"move_right", &"soft_drop", &"hard_drop", &"rotate_cw", &"rotate_ccw", &"hold",
]

var master_volume := 0.8
var sfx_volume := 0.8
var fullscreen := false
var ghost_piece := true
## Delayed auto shift: how long left or right must be held before the piece slides, in ms.
var das_ms := 170
## Auto repeat rate: the time between steps while sliding, in ms. 0 slides instantly.
var arr_ms := 50


func _ready() -> void:
	load_settings()
	apply()


## Push the current values to the audio server and the window.
func apply() -> void:
	_set_bus_volume(&"Master", master_volume)
	_set_bus_volume(&"SFX", sfx_volume)
	var mode := DisplayServer.WINDOW_MODE_FULLSCREEN if fullscreen else DisplayServer.WINDOW_MODE_WINDOWED
	DisplayServer.window_set_mode(mode)


func _set_bus_volume(bus_name: StringName, value: float) -> void:
	var index := AudioServer.get_bus_index(bus_name)
	AudioServer.set_bus_volume_db(index, linear_to_db(value))
	AudioServer.set_bus_mute(index, value <= 0.0)


func get_key(action: StringName) -> Key:
	for event in InputMap.action_get_events(action):
		if event is InputEventKey:
			return event.physical_keycode
	return KEY_NONE


## Bind `keycode` to `action`. An action that already used that key gets
## `action`'s old key instead, so two actions never share a key.
func set_key(action: StringName, keycode: Key) -> void:
	var old_key := get_key(action)
	for other in REBINDABLE_ACTIONS:
		if other != action and get_key(other) == keycode:
			_bind(other, old_key)
	_bind(action, keycode)


func _bind(action: StringName, keycode: Key) -> void:
	InputMap.action_erase_events(action)
	var event := InputEventKey.new()
	event.physical_keycode = keycode
	InputMap.action_add_event(action, event)


func key_name(action: StringName) -> String:
	return OS.get_keycode_string(get_key(action))


func save_settings() -> void:
	var config := ConfigFile.new()
	config.set_value("audio", "master_volume", master_volume)
	config.set_value("audio", "sfx_volume", sfx_volume)
	config.set_value("video", "fullscreen", fullscreen)
	config.set_value("game", "ghost_piece", ghost_piece)
	config.set_value("game", "das_ms", das_ms)
	config.set_value("game", "arr_ms", arr_ms)
	for action in REBINDABLE_ACTIONS:
		config.set_value("controls", action, get_key(action))
	config.save(SAVE_PATH)


func load_settings() -> void:
	var config := ConfigFile.new()
	if config.load(SAVE_PATH) != OK:
		return # First launch: keep the defaults.
	master_volume = config.get_value("audio", "master_volume", master_volume)
	sfx_volume = config.get_value("audio", "sfx_volume", sfx_volume)
	fullscreen = config.get_value("video", "fullscreen", fullscreen)
	ghost_piece = config.get_value("game", "ghost_piece", ghost_piece)
	das_ms = config.get_value("game", "das_ms", das_ms)
	arr_ms = config.get_value("game", "arr_ms", arr_ms)
	for action in REBINDABLE_ACTIONS:
		var keycode: Key = config.get_value("controls", action, KEY_NONE)
		if keycode != KEY_NONE:
			_bind(action, keycode)
